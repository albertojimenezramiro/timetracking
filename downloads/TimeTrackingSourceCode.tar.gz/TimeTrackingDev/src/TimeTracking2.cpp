/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 7 oct 2018
**
****************************************************************************/

#include <QGuiApplication>
#include "Application.h"
#include <QDateTime>
#include <QDebug>

FILE *logFile = nullptr;
char *userDataDir = nullptr;

void logHandler(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
    QByteArray localMsg = msg.toLocal8Bit();
    QByteArray time = QDateTime::currentDateTime().toString("dd/MM/yyyy hh:mm:ss.zzz").toLocal8Bit();
    switch (type) {
    case QtDebugMsg:
        fprintf(stderr, "%s [DEBUG] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        fprintf(logFile, "%s [DEBUG] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        break;
    case QtInfoMsg:
        fprintf(stderr, "%s [INFO] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        fprintf(logFile, "%s [INFO] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        break;
    case QtWarningMsg:
        fprintf(stderr, "%s [WARNING] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        fprintf(logFile, "%s [WARNING] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        break;
    case QtCriticalMsg:
        fprintf(stderr, "%s [CRITICAL] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        fprintf(logFile, "%s [CRITICAL] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        break;
    case QtFatalMsg:
        fprintf(stderr, "%s [FATAL] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        fprintf(logFile, "%s [FATAL] [%s@%u]: %s\n", time.data(), context.function, context.line, localMsg.constData());
        abort();
    }
    fflush(logFile);
}

void parseParameters(int argc, char *argv[])
{
    for (int ind = 0; ind < argc; ind++) {
        if (strcmp("-f", argv[ind]) == 0) {
            ind++;
            if (ind < argc) {
                logFile = fopen(argv[ind], "a");
                qInstallMessageHandler(logHandler);
            }
        } else if (strcmp("-u", argv[ind]) == 0) {
            ind++;
            if (ind < argc) {
                userDataDir = argv[ind];
            }
        }
    }
}

int main(int argc, char *argv[])
{
    //QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    parseParameters(argc, argv);
    QGuiApplication app(argc, argv);
    QString userD = QString(userDataDir);
    qDebug() << "main. userDataDir parametro -u " << userD;
    Application* applicationLogic = new Application(userD);
    applicationLogic->initializeApp();

    return app.exec();
}
