/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 6 oct 2023
**
****************************************************************************/

#ifndef SRC_SCHEMA4UPDATE_H_
#define SRC_SCHEMA4UPDATE_H_

#include <QString>
#include <qglobal.h>

class Schema4Update
{
    public:
        Schema4Update();
        virtual ~Schema4Update();

        void checkWorkOrders();

    private:
        void extractWorkOrderData(const QString &workOrder, qint64 &workOrderCreationTime, qint64 &workOrderArchiveDate);
        void extractTaskData(int taskId, qint64 &taskCreationTime, qint64 &taskArchiveDate);
        void modifyWoEntry(int id, int idWorkOrder);
        int tryCreateWorkOrderEntry(const QString &woCode, bool &created);

};

#endif /* SRC_SCHEMA4UPDATE_H_ */
