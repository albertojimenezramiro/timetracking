/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 7 oct. 2018
**
****************************************************************************/

#include "Application.h"
#include <QSqlQuery>
#include <QQmlApplicationEngine>
#include <QQmlEngine>
#include <QObject>
#include "Contexto.h"
#include <QQmlContext>
#include <QTimer>
#include "TTSettings.h"
#include <QSqlTableModel>
#include "workorders/WorkOrdersViewModel.h"
#include "DatabaseMaintenance.h"
#include "tareas/TasksViewModel.h"
#include "tiempo/TimeViewModel.h"
#include "reportes/ReportViewModel.h"
#include <QDebug>
#include <QMetaObject>
#include "projects/ProjectsViewModel.h"
#include "clockingIn/ClockingInViewModel.h"
#include <QDir>
#include <QFileInfo>
#include <QFile>
#include <QDirIterator>
#include "Features.h"

Application::Application(const QString &userDataDir) :
    _engine(0),
    _contexto(0)
{
    if (userDataDir.isEmpty()) {
        _userDataDirectory = QDir::homePath() + "/.timetracking/";
    } else {
        _userDataDirectory = userDataDir + (userDataDir.endsWith("/") ? "" : "/");
    }
    qDebug() << "Application::Application: userDataDirectory " << _userDataDirectory << ". asignando a settings y DatabaseMaintenance";
    DatabaseMaintenance::_userDataDirectory = _userDataDirectory;
    TTSettings::_userDataDirectory = _userDataDirectory;
    checkUserData();
    _databaseMaintenance = new DatabaseMaintenance(this);
}

Application::~Application()
{
    if (_databaseMaintenance) {
        delete _databaseMaintenance;
    }
}

void Application::checkUserData()
{
    QString personalDataDir = QDir::toNativeSeparators(_userDataDirectory + "data");
    // viendo si hay que crear el nuevo directorio personal
    if (QFileInfo::exists(personalDataDir)) {
        qDebug() << "Application::checkUserData: personal data dir "  << personalDataDir << "ya existe";
        if (QFileInfo::exists(TTSettings::filePath()) && QFileInfo::exists(DatabaseMaintenance::sqlPath()) && QFileInfo::exists("olddata")) {
            QDir oldDir("olddata");
            bool b = oldDir.removeRecursively();
            qDebug() << "Application::checkUserData: existen los ficheros de base de datos y settings: " << TTSettings::filePath() << ", " << DatabaseMaintenance::sqlPath()
                     << ". Borrando directorio obsoleto olddata: " << b;

        } else {
            qDebug() << "Application::checkUserData: exists settingspath " << TTSettings::filePath() << " " << QFileInfo::exists(TTSettings::filePath());
            qDebug() << "Application::checkUserData: exists sqlpath " << DatabaseMaintenance::sqlPath() << " " << QFileInfo::exists(DatabaseMaintenance::sqlPath());
            qDebug() << "Application::checkUserData: exists olddata" << " " << QFileInfo::exists("olddata");
        }
    } else {
        QDir d;
        bool b = d.mkpath(personalDataDir); // creamos el directorio de datos personales
        qDebug() << "Application::checkUserData: no existe directorio de datos personales. creando en " << personalDataDir << ": " << b;
        if (b) {
            if (QFileInfo::exists("data")) {
                qDebug() << "Application::checkUserData: detectado directorio de datos de usuario en ubicación antigua";
                // si existe el viejo directorio de datos de usuario, copiamos todo su contenido al
                // nuevo en la ubicación correcta
                QDirIterator it("data");
                while (it.hasNext() && b) {
                    it.next();
                    if (it.fileName() != "." && it.fileName() != "..") {
                        QString newPath = QDir::toNativeSeparators(_userDataDirectory + "data/" + it.fileName());
                        b = QFile::copy(it.filePath(), newPath);
                        qDebug() << "Application::checkUserData: copiando datos de usuario " << it.filePath() << " -> " << newPath << ": " << b;
                    }
                }
                if (b) {
                    qDebug() << "Application::checkUserData: renombrando a olddata";
                    QFile::rename("data", "olddata");
                } else {
                    qCritical() << "Error copiando ficheros desde el viejo directorio de datos al nuevo";
                }
            }
        } else {
            qCritical() << "Error creando el directorio de datos personales";
        }
    }

}

void Application::initializeApp()
{
    buildBasicObjects();
    initializeQmlEnvironment();
    qDebug() << "Application::initializeApp";
    // cuando _databaseMaintenance haya terminado su trabajo (es muy asíncrono), emitirá una señal
}

void Application::slotDatabaseInitialized()
{
    if (_databaseMaintenance->isInitialized()) {
        qDebug() << "Application::slotDatabaseInitialized: cargando interfaz...";
        _contexto->initialize();
        _contexto->setSplash(false);
    }
}

void Application::buildBasicObjects()
{
    _features = new Features(this);
    _contexto = new Contexto();
    _databaseMaintenance->setVersion(_contexto->version());
    connect(_databaseMaintenance, &DatabaseMaintenance::newMessage, _contexto, &Contexto::setInfoTextForSplash);
    connect(_databaseMaintenance, &DatabaseMaintenance::initialized, this, &Application::slotDatabaseInitialized, Qt::QueuedConnection);
}

void Application::initializeQmlEnvironment()
{
    _engine = new QQmlApplicationEngine();
    connect(_contexto, &Contexto::splashLoaded, this, &Application::slotSplashLoaded);
    qmlRegisterUncreatableType<TTSettings>("TimeTracking",1,0,"TTSettings", "TTSettings cannot be instantiated");
    qDebug() << "Application::initializeQmlEnvironment";
    _engine->rootContext()->setContextProperty("features", _features);
    _engine->rootContext()->setContextProperty("contexto", _contexto);
    QObject * m = dynamic_cast<QObject*>(_contexto->workOrdersViewModel());
    _engine->rootContext()->setContextProperty("WorkOrdersViewModel", m);
    m = dynamic_cast<QObject*>(_contexto->projectsViewModel());
    _engine->rootContext()->setContextProperty("ProjectsViewModel", m);
    m = dynamic_cast<QObject*>(_contexto->tasksViewModel());
    _engine->rootContext()->setContextProperty("TasksViewModel", m);
    m = dynamic_cast<QObject*>(_contexto->timeViewModel());
    _engine->rootContext()->setContextProperty("TimeViewModel", m);
    m = dynamic_cast<QObject*>(_contexto->reportViewModel());
    _engine->rootContext()->setContextProperty("ReportViewModel", m);
    m = dynamic_cast<QObject*>(_contexto->clockingInViewModel());
    _engine->rootContext()->setContextProperty("ClockingInViewModel", m);

    _engine->load(QUrl(QLatin1String("qrc:/qml/WindowContainer.qml")));
    qDebug() << "Application::initializeQmlEnvironment";
}

void Application::slotSplashLoaded()
{
    _databaseMaintenance->initialize();
}


