/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 19 nov. 2018
**
****************************************************************************/
/*
 * Reloj.cpp
 *
 *  Created on: 19 nov. 2018
 *      Author: alberto
 */

#include "Reloj.h"

Reloj *Reloj::_instance = 0;

Reloj *Reloj::instance()
{
    if (!_instance) {
        _instance = new Reloj();
        /*QDate fecha(2018, 12, 9);
        QTime hora(16, 00, 0, 0);
        _instance = new Reloj(QDateTime(fecha, hora), 60, 15);*/
    }
    return _instance;
}

Reloj::Reloj() :
    _programSecsPerRealSec(1)
{
    connect(&_timer, &QTimer::timeout, this, &Reloj::currentTimeChanged);
    _timer.setSingleShot(false);
    _timer.start(30*1000);
    _pollFreq = 30;
}

Reloj::Reloj(const QDateTime &base, const int &intervalo, const int &frecuencia)
{
    _currentTime = base;
    _startup = QDateTime::currentDateTime();
    _programSecsPerRealSec = intervalo;
    connect(&_timer, &QTimer::timeout, this, &Reloj::processTimeChange);
    _timer.setSingleShot(false);
    _timer.start(frecuencia*1000);
    _pollFreq = frecuencia;
}

Reloj::~Reloj()
{
}

QDateTime Reloj::currentTime() const
{

    return currentFakedTime();
}

QDateTime Reloj::currentDateSlot() const
{
    return QDateTime(currentDate(), QTime(0, 0, 0, 0));
}

QDateTime Reloj::currentDateTime()
{
    return instance()->currentFakedTime();
}

QDate Reloj::currentDate()
{
    return instance()->currentFakedTime().date();
}

void Reloj::processTimeChange()
{
    Q_EMIT(currentTimeChanged());
}

QDateTime Reloj::currentFakedTime() const
{
    QDateTime res = QDateTime::currentDateTime();
    if (!_currentTime.isNull() && _currentTime.isValid()) {
        qint64 elapsed = _startup.msecsTo(QDateTime::currentDateTime());
        res = _currentTime.addMSecs(elapsed * _programSecsPerRealSec);
    }
    return res;
}
