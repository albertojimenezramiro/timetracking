/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 28 sep. 2023
**
****************************************************************************/

#ifndef SRC_WORKORDERS_WORKORDERSTORE_H_
#define SRC_WORKORDERS_WORKORDERSTORE_H_

#include <QString>
#include <QList>

class QSqlTableModel;
class WorkOrder;

class WorkOrderStore : public QObject {
Q_OBJECT
public:
    // fields for browsing into the db model resultset
    enum WoFields {
        WO_ID = 0,
        WO_NAME,
        WO_CODE,
        WO_CREATIONTIME,
        WO_PARENT,
        WO_DESCRIPTION,
        WO_ARCHIVEDATE
    };

    typedef enum WorkOrderNotifications {
        WONOTIF_NONE = 0,
        WONOTIF_NEWWO,
        WONOTIF_ARCHIVED,
        WONOTIF_REOPEN,
        WONOTIF_UPDATEDATA,
        WONOTIF_UPDATEPARENT,
        WONOTIF_IMPORTED
    } WorkOrderNotifications;
    Q_ENUM(WorkOrderNotifications)

    WorkOrderStore(QObject* parent);
    virtual ~WorkOrderStore();

    void initialize();

    WorkOrder *wo(int id, bool loadFromDb);
    WorkOrder *woByCode(const QString &code);
    WorkOrder *last() const;
    void createWorkOrderFromData(const QString &name, const QString &code, const QString &description, int parentId, qint64 creationTime, qint64 archiveTime);
    /**
     * @brief Creates a new work order into the database using default fields and loads it into
     *        memory.
     *
     * This will be notified with the WONOTIF_NEWWO notification. The new work order can be get using
     * the last() method.
     *
     * @return
     */
    void createNewWorkOrder();
    void importWorkOrder(const QString &code);
    void archiveWorkOrder(int id);
    void reopenWorkOrder(int id);
    bool updateWorkOrderDataInDb(int id, const QString &name, const QString &description, const QString &code);
    bool updateParentInDb(int id, int parentId);
    QList<WorkOrder*> suggestionsFor(const QString &pattern, bool includeArchived, bool canBeParent, int excludeId);
    bool canHaveParent(int id);

Q_SIGNALS:
    // sends a notification
    void woNotification(WorkOrderStore::WorkOrderNotifications notification, int workOrderId);

private:
    WorkOrder *workOrderFactoryMethod(int id, const QString &nombre, const QString &desc, const QString &codigo);
    // extracts a piece of data from the resultset of the db model, using a row number for the resultset and a column field
    QVariant sqlData(int rowIndex, WorkOrderStore::WoFields column);
    // this loads the db model with a select based on work order id
    void selectWo(int id);
    void selectWos(const QString &pattern, bool includeArchived, bool canBeParent, int excludeId);

    // this caches the first work order that is in the resultset of the db model into memory
    WorkOrder *cacheSelected();
    WorkOrder *cacheSelected(int rowIndex);

    //select the work order into the db model and updates just the archive date (for archive and reopen operations)
    bool updateArchiveDateInDb(int id, const QDateTime &archiveDate);


    QSqlTableModel* _woModelDb;
    QMap<int, WorkOrder*> _woByIndex;

    // this will hold the last work order that received a changed or was notified about
    WorkOrder *_last;

    static const qint64 _defaultArchiveTimestamp;
};

#endif /* SRC_WORKORDERS_WORKORDERSTORE_H_ */
