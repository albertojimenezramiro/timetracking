/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 28 sep. 2023
**
****************************************************************************/

#include <QDebug>
#include "WorkOrder.h"
#include "../Reloj.h"

WorkOrder::WorkOrder(QObject* parent) :
    QObject(parent),
    _id(-1),
    _parentId(-1),
    _isArchived(false)
{
}

WorkOrder::WorkOrder(const WorkOrder& w) :
    QObject(w.parent()),
    _id(w._id),
    _name(w._name),
    _description(w._description),
    _code(w._code),
    _parentId(w._parentId),
    _isArchived(w._isArchived),
    _archiveDate(w._archiveDate)
{
}

WorkOrder::WorkOrder(QObject* parent, int id, QString nombre, QString desc) :
    QObject(parent),
    _id(id),
    _name(nombre),
    _description(desc),
    _parentId(-1),
    _isArchived(false)
{
}

WorkOrder::~WorkOrder()
{
}

QString WorkOrder::name() const
{
    return _name;
}
QString WorkOrder::description() const
{
    return _description;
}
QString WorkOrder::code() const
{
    return _code;
}

int WorkOrder::id() const
{
    return _id;
}

bool WorkOrder::isArchived() const
{
    return _isArchived;
}

int WorkOrder::parentWo() const
{
    return _parentId;
}

void WorkOrder::setName(const QString &name)
{
    if (_name != name) {
        _name = name;
        //Q_EMIT(nombreChanged());
    }
}
void WorkOrder::setDescription(const QString &desc)
{
    if (_description != desc) {
        _description = desc;
        //Q_EMIT(descripcionChanged());
    }
}

void WorkOrder::setArchiveDate(const QDateTime &archiveDate)
{
    _archiveDate = archiveDate;
    _isArchived = (Reloj::currentDateTime() > archiveDate);
}

void WorkOrder::setCode(const QString &code)
{
    _code = code;
}

void WorkOrder::setParentWo(int parentId)
{
    _parentId = parentId;
}

QDateTime WorkOrder::archiveDate() const
{
    return _archiveDate;
}
