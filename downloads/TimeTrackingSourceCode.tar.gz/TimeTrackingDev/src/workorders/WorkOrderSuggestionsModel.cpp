/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 28 sep. 2023
**
****************************************************************************/

#include <QDebug>
#include "WorkOrder.h"
#include <workorders/WorkOrderSuggestionsModel.h>

WorkOrderSuggestionsModel::WorkOrderSuggestionsModel(QObject *parent) :
    QAbstractListModel(parent)
{
}

WorkOrderSuggestionsModel::~WorkOrderSuggestionsModel()
{
}

int WorkOrderSuggestionsModel::rowCount(const QModelIndex &) const
{
    return _list.size();
}

QVariant WorkOrderSuggestionsModel::data(const QModelIndex &modelIndex, int role) const
{
    int nrow = modelIndex.row();
    WorkOrder *w = _list.size() > nrow ? _list.value(nrow) : nullptr;
    if (w) {
        if (role == SUGGESTION_ID) {
            return QVariant::fromValue(w->id());
        } else if (role == SUGGESTION_NAME) {
            QString name = w->name().trimmed().isEmpty() ? "<orden sin nombre>" : w->name().trimmed();
            return QVariant::fromValue(name);
        } else if (role == SUGGESTION_CODE) {
            return QVariant::fromValue(w->code());
        } else {
            return QVariant();
        }
    }
    return QVariant();
}

QHash<int, QByteArray> WorkOrderSuggestionsModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[SUGGESTION_ID] = "woid";
        roles[SUGGESTION_NAME] = "name";
        roles[SUGGESTION_CODE] = "code";
    }
    return roles;
}

bool WorkOrderSuggestionsModel::canFetchMore(const QModelIndex &) const
{
    return false;
}

void WorkOrderSuggestionsModel::fetchMore(const QModelIndex &)
{}

void WorkOrderSuggestionsModel::clearModel()
{
    beginResetModel();
    _list.clear();
    endResetModel();
    Q_EMIT(sizeChanged());
}

void WorkOrderSuggestionsModel::loadModel(QList<WorkOrder*> list)
{
    beginResetModel();
    _list = list;
    endResetModel();
    qDebug() << "WorkOrderSuggestionsModel::loadModel: cargando nueva lista de" << list.size() << " sugerencias";
    Q_EMIT(sizeChanged());
}

WorkOrder *WorkOrderSuggestionsModel::suggestionAt(int index)
{
    WorkOrder *res = nullptr;
    if (index < _list.size()) {
        res = _list.value(index);
    }
    return res;
}

WorkOrder * WorkOrderSuggestionsModel::suggestionWithCode(const QString &pattern)
{
    int index = 0;
    WorkOrder * found = nullptr;
    while (!found && index < _list.size()) {
        WorkOrder *w = _list.value(index);
        found = (w->code() == pattern) ? w : nullptr;
        if (found) {
            qDebug() << "WorkOrderSuggestionsModel::suggestionWithCode: encontrada sugerencia con codigo " << w->code();
        }
        index++;
    }
    return found;
}

int WorkOrderSuggestionsModel::size() const
{
    return _list.size();
}

