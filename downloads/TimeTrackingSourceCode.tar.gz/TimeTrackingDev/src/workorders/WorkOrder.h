/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 28 sep. 2023
**
****************************************************************************/

#ifndef SRC_WORKORDERS_WORKORDER_H_
#define SRC_WORKORDERS_WORKORDER_H_

#include <QObject>
#include <QString>
#include <QDateTime>

class WorkOrder: public QObject {
public:
    WorkOrder(QObject* parent = 0);
    WorkOrder(const WorkOrder& w);
    WorkOrder(QObject* parent, int id, QString name, QString desc);
    virtual ~WorkOrder();

    QString name() const;
    QString description() const;
    QString code() const;
    bool isArchived() const;
    int id() const;
    int parentWo() const;
    QDateTime archiveDate() const;

    void setName(const QString &name);
    void setDescription(const QString &desc);
    void setCode(const QString &code);
    void setArchiveDate(const QDateTime &archiveDate);
    void setParentWo(int parentId);

private:
    int _id;
    QString _name;
    QString _description;
    QString _code;
    int _parentId;
    bool _isArchived;
    QDateTime _archiveDate;
};

#endif /* SRC_WORKORDERS_WORKORDER_H_ */
