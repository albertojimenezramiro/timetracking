/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 28 sep. 2023
**
****************************************************************************/

#include <QSqlTableModel>
#include <QDebug>
#include <QSqlRecord>
#include <QSqlError>
#include "WorkOrder.h"
#include "Reloj.h"
#include <qalgorithms.h>
#include <workorders/WorkOrderListModel.h>

WorkOrderListModel::WorkOrderListModel(QObject *parent, WorkOrderStore *store) :
    QAbstractListModel(parent),
    _databaseModel(nullptr),
    _store(store),
    _dbPageSize(50),
    _archiveThreshold(0)
{
}

WorkOrderListModel::~WorkOrderListModel()
{
    _databaseModel->clear();
    _databaseModel->deleteLater();
}

void WorkOrderListModel::initialize()
{
    _databaseModel = new QSqlTableModel();
}

int WorkOrderListModel::rowCount(const QModelIndex &) const
{
    return _wosByIndex.size();
}

QVariant WorkOrderListModel::data(const QModelIndex &modelIndex, int role) const
{
    int nrow = modelIndex.row();
    WorkOrder *w = _wosByIndex.value(nrow, nullptr);
    if (w) {
        if (role == WOID) {
            return QVariant::fromValue(w->id());
        } else if (role == NAME) {
            return QVariant::fromValue(w->name());
        } else if (role == CODE) {
            return QVariant::fromValue(w->code());
        } else if (role == ARCHIVED) {
            int value = w->isArchived() ? 1 : 0;
            return QVariant::fromValue(value);
        } else {
            return QVariant();
        }
    }
    return QVariant();
}

QHash<int, QByteArray> WorkOrderListModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[WOID] = "woid";
        roles[NAME] = "name";
        roles[CODE] = "code";
        roles[ARCHIVED] = "isArchived";
    }
    return roles;
}

bool WorkOrderListModel::canFetchMore(const QModelIndex &) const
{
    // si el modelo de db tiene más elementos fetcheados, claramente true
    // si tiene igual, le tendremos que preguntar si canFetchMore
    int numElems = _wosByIndex.size();
    bool can = false;
    qDebug() << "WorkOrderListModel::canFetchMore: numElems " << numElems
             << ", rowCount del modelo de db " << _databaseModel->rowCount();
    if (numElems < _databaseModel->rowCount()) {
        can = true;
    } else {
        if (numElems == _databaseModel->rowCount()) {
            can = _databaseModel->canFetchMore();
        } else {
            qCritical() << "El modelo de wos no está alineado";
        }
    }
    qDebug() << "WorkOrderListModel::canFetchMore: " << can << ", " << this;
    return can;
}

void WorkOrderListModel::fetchMore(const QModelIndex &)
{
    int first = maxIndex() + 1;
    int last = first + (_dbPageSize-1);
    qDebug() << "WorkOrderListModel::canFetchMore: " << this << "; numElems "
             << first << ", rowCount db " << _databaseModel->rowCount();
    if (first < _databaseModel->rowCount()) {
        insertIntoListModel(first, last, true);
    } else {
        if (first == _databaseModel->rowCount()) {
            _databaseModel->fetchMore();
            insertIntoListModel(first, last, true);
        } else {
            qCritical() << "El modelo de tareas no está alineado";
        }
    }
    qDebug() << "WorkOrderListModel::canFetchMore: fetchMore terminado. fetcheados "
             << first << " -- " << last;
}

int WorkOrderListModel::maxIndex() const
{
    int maxIndex = -1;
    QList<int> indexes = _wosByIndex.keys();
    if (indexes.size() > 0) {
        qSort(indexes);
        maxIndex = indexes.last();
    }
    return maxIndex;
}

QVariant WorkOrderListModel::sqlData(int i, WorkOrderStore::WoFields field)
{
    QModelIndex ind = _databaseModel->index(i, field, QModelIndex());
    return _databaseModel->data(ind);
}

void WorkOrderListModel::sqlSelect()
{
    _databaseModel->setTable("workorders");
    _databaseModel->setSort(WorkOrderStore::WO_ARCHIVEDATE, Qt::DescendingOrder);
    QDateTime threshold = Reloj::currentDateTime().addDays(-_archiveThreshold);
    qint64 llthreshold = threshold.toMSecsSinceEpoch();
    _databaseModel->setFilter("archivetimestamp > " + QString::number(llthreshold));
    _databaseModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _databaseModel->select();
}

void WorkOrderListModel::shiftModelForInsertion(const int firstIndex, const int numElems)
{
    // todas las entradas de este modelo que ocupen los índices dados se desplazan hacia índices
    // superiores para que los índices dados puedan ser ocupados por nuevas entradas
    int woMaxIndex = maxIndex();
    qDebug() << "WorkOrderListModel::shiftModelForInsertion: firstIndex " << firstIndex << ", numElems " << numElems << ", maxIndex " << woMaxIndex;
    if (woMaxIndex >= firstIndex) {
        for (int currIndex = woMaxIndex; currIndex >= firstIndex; currIndex--) {
            WorkOrder *currWo = _wosByIndex.value(currIndex, nullptr);
            if (currWo) {
                qDebug() << "WorkOrderListModel::shiftModelForInsertion: desplazando indice " << currIndex << " al indice " << (currIndex + numElems);
                _wosByIndex[currIndex + numElems] = currWo;
                _wosByIndex.remove(currIndex);
                _indexesById[currWo->id()] = currIndex + numElems;
            }

        }
    }
}

void WorkOrderListModel::clearModel()
{
    beginResetModel();
    _indexesById.clear();
    _wosByIndex.clear();
    _databaseModel->clear();
    endResetModel();
}

void WorkOrderListModel::loadModel(int archiveThreshold)
{
    qDebug() << "WorkOrderListModel::loadModel";
    clearModel();
    _archiveThreshold = archiveThreshold;
    // cargamos el modelo de sql y metemos las primeras en este modelo
    qDebug() << "WorkOrderListModel::loadModel: comenzando carga del modelo de wos. ";
    sqlSelect();
    qDebug() << "cargado modelo DB de work orders. count " << _databaseModel->rowCount() << ", " << this;
    if (_databaseModel->rowCount() > 0) {
        insertIntoListModel(0, _dbPageSize-1, true);
    }
}

void WorkOrderListModel::insertIntoListModel(int first, int last, bool signalInsertions)
{
    // como last nos quedamos con el más restrictivo entre el dado y el del modelo de sql
    int lastDef = last <= (_databaseModel->rowCount()-1) ? last : (_databaseModel->rowCount()-1);
    qDebug() << "WorkOrderListModel::insertIntoListModel: signalInsertions " << signalInsertions<<", beginInsertRows "
             << first << " " << lastDef;
    if (signalInsertions) {
        beginInsertRows(QModelIndex(), first, lastDef);
    }
    // si los indices están ocupados, los desplazamos
    int numHuecos = lastDef - first + 1;
    shiftModelForInsertion(first, numHuecos);
    // insertamos nuestros nuevos elementos, se los pedimos al store
    for (int i = first; i <= lastDef; i++) {
        int id = sqlData(i, WorkOrderStore::WO_ID).toInt();
        WorkOrder *wo = _store->wo(id, true);
        qDebug() << "WorkOrderListModel::insertIntoListModel: index "<<i<<", id "<<id<<", "<<wo;
        if (wo) {
            _wosByIndex.insert(i, wo);
            _indexesById.insert(wo->id(), i);
        }
    }
    if (signalInsertions) {
        endInsertRows();
    }
}

void WorkOrderListModel::removeFromListModel(int first, int last)
{
    int lastIndex = last;
    int maxIndexBefore = maxIndex();
    if (last  > maxIndexBefore) {
        lastIndex = maxIndexBefore;
    }
    // vamos a borrar el intervalo first - lastIndex. Todo lo que haya detrás de lastIndex nos lo
    // traemos a first en adelante. Los índices que sobren se tienen que quedar borrados.
    int newIndex = first;
    int oldIndex = lastIndex + 1;
    // true if there are items at [last+1,..) that must be moved
    bool forwardItemsToMove = true;
    qDebug() << "WorkOrderListModel::removeFromListModel: first " << first << ", last " << lastIndex;
    qDebug() << "WorkOrderListModel::removeFromListModel: wosByIndex "<<_wosByIndex<<"; indexesById " << _indexesById;
    beginRemoveRows(QModelIndex(), first, lastIndex);
    while (newIndex <= lastIndex || forwardItemsToMove) {
        if (oldIndex <= maxIndexBefore) {
            // existe algo en oldIndex, así que nos lo traemos a newIndex
            WorkOrder *wo = _wosByIndex.value(oldIndex);
            _wosByIndex.insert(newIndex, wo);
            _wosByIndex.remove(oldIndex);
            _indexesById.insert(wo->id(), newIndex);
            qDebug() << "llevando tarea de id " << wo->id() << " desde el index " << oldIndex << " hasta el index " << newIndex;
        } else {
            // no hay nada en oldIndex, así que dejamos borrado newIndex
            WorkOrder *wo = _wosByIndex.value(newIndex);
            _wosByIndex.remove(newIndex);
            _indexesById.remove(wo->id());
            qDebug() << "borrando index " << newIndex;
            forwardItemsToMove = false;
        }
        newIndex++; oldIndex++;
    }
    endRemoveRows();
    qDebug() << "WorkOrderListModel::removeFromListModel: wosByIndex "<<_wosByIndex<<"; indexesById " << _indexesById;
}

void WorkOrderListModel::insertNewWorkOrder(int id)
{
    // primero cargamos de nuevo el modelo de base de datos y lo fetcheamos
    sqlSelect();
    int maxIndexInModel = maxIndex();
    fetchDbModelUntil(maxIndexInModel + 1); // vamos a insertar una nueva, que estará de las primeras
    qDebug() << "WorkOrderListModel::insertNewWorkOrder: id " << id << ", maxIndex " << maxIndexInModel
             << ", dbmodel tiene " << _databaseModel->rowCount();
    int index = searchForIndex(id, maxIndexInModel + 1);
    if (index >= 0) {
        insertIntoListModel(index, index, true);
    } else {
        qDebug() << "WorkOrderListModel::insertNewWorkOrder: no se insertará porque no está fetcheada";
    }

}

void WorkOrderListModel::fetchDbModelUntil(int rowIndex)
{
    while (_databaseModel->rowCount() < (rowIndex + 1) && _databaseModel->canFetchMore()) {
        qDebug() << "WorkOrderListModel::fetchDbModelUntil: dbModel " << _databaseModel->rowCount()
                 << " rows, indMaximo " << rowIndex << " entradas; fetcheando dbModel";
        _databaseModel->fetchMore();
    }
}

int WorkOrderListModel::searchForIndex(int id, int maxIndex)
{
    // buscaremos en el modelo de db (debe estar fetcheado) qué índice ocupa la work order dada
    // maxIndex es un tope, por seguridad
    int result = -1;
    int ind = 0;
    qDebug() << "WorkOrderListModel::searchForIndex: id buscado "<<id<<", indice maximo " << maxIndex;
    while (ind <= maxIndex && result == -1) {
        int currid = sqlData(ind, WorkOrderStore::WO_ID).toInt();
        if (id == currid) {
            result = ind;
        }
        ind++;
    }
    return result;
}

void WorkOrderListModel::changeWorkOrderState(int id)
{
    // parece que no se puede borrar e insertar debido a las secciones. Por tanto, hacemos un reset
    int maxIndexInModel = maxIndex();
    int index = _indexesById.value(id, -1);
    if (index >= 0) {
        // hacemos un select para tener el nuevo orden y fetcheamos en el modelo de db lo mismo que teníamos
        sqlSelect();
        fetchDbModelUntil(maxIndexInModel);
        // y ahora hacemos el reset y cargamos de nuevo
        beginResetModel();
        _indexesById.clear();
        _wosByIndex.clear();
        insertIntoListModel(0, maxIndexInModel, false);
        endResetModel();
    }
}

void WorkOrderListModel::updateData(int id)
{
    int woIndex = _indexesById.value(id, -1);
    qDebug() << "WorkOrderListModel::updateData: id " << id << " esta en el indice " << woIndex;
    if (woIndex >= 0) {
        Q_EMIT(dataChanged(index(woIndex, 0), index(woIndex, 0)));
    }
}

int WorkOrderListModel::indexOf(int id) const
{
    return _indexesById.value(id, -1);
}

