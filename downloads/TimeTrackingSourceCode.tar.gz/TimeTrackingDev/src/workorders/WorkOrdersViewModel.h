/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 29 sep. 2023
**
****************************************************************************/

#ifndef SRC_WORKORDERS_WORKORDERSVIEWMODEL_H_
#define SRC_WORKORDERS_WORKORDERSVIEWMODEL_H_

#include <QObject>
#include "WorkOrder.h"
#include "WorkOrderStore.h"

class WorkOrderListModel;
class QTimer;
class WorkOrderSuggestionsModel;
class TTSettings;

class WorkOrdersViewModel : public QObject
{
    Q_OBJECT

    // data from loaded work order
    Q_PROPERTY(QString name READ name NOTIFY nameChanged)
    Q_PROPERTY(QString desc READ desc NOTIFY descChanged)
    Q_PROPERTY(QString code READ code NOTIFY codeChanged)
    Q_PROPERTY(QString parentCode READ parentCode NOTIFY parentCodeChanged)
    Q_PROPERTY(bool archived READ archived NOTIFY archivedChanged)
    Q_PROPERTY(int id READ id NOTIFY idChanged)
    Q_PROPERTY(bool canHaveParent READ canHaveParent NOTIFY canHaveParentChanged)

    // editable fields
    Q_PROPERTY(QString nameEdited READ nameEdited WRITE setNameEdited NOTIFY nameEditedChanged)
    Q_PROPERTY(QString descEdited READ descEdited WRITE setDescEdited NOTIFY descEditedChanged)
    Q_PROPERTY(QString codeEdited READ codeEdited WRITE setCodeEdited NOTIFY codeEditedChanged)
    Q_PROPERTY(QString parentTextEdited READ parentTextEdited WRITE setParentTextEdited NOTIFY parentTextEditedChanged)

    Q_PROPERTY(WorkOrderListModel* listModel READ listModel CONSTANT)
	Q_PROPERTY(WorkOrderSuggestionsModel *parentTextSuggestionsModel READ parentTextSuggestionsModel CONSTANT)

    public:
        WorkOrdersViewModel(QObject* parent, WorkOrderStore *store, TTSettings *settings);
        virtual ~WorkOrdersViewModel();

        void initialize();

        // properties

        // editable fields content
        QString nameEdited() const;
        void setNameEdited(const QString &newValue);
        QString descEdited() const;
        void setDescEdited(const QString &newValue);
        QString codeEdited() const;
        void setCodeEdited(const QString &newValue);
        QString parentTextEdited() const;
        void setParentTextEdited(const QString &newValue);

        // loaded work order data
        QString name() const;
        QString desc() const;
        QString code() const;
        QString parentCode() const;
        bool archived() const;
        int id() const;
        bool canHaveParent() const;

        WorkOrderListModel *listModel() const;
        WorkOrderSuggestionsModel *parentTextSuggestionsModel() const;

        //business-logic
        Q_INVOKABLE void loadWorkOrder(int id);
        Q_INVOKABLE void createNewWorkOrder();
        Q_INVOKABLE void archiveWorkOrder();
        Q_INVOKABLE void reopenWorkOrder();
        Q_INVOKABLE void selectParentTextSuggestion(int index);

    Q_SIGNALS:
        // properties
        void nameEditedChanged();
        void descEditedChanged();
        void codeEditedChanged();
        void parentTextEditedChanged();
        void nameChanged();
        void descChanged();
        void codeChanged();
        void parentCodeChanged();
        void idChanged();
        void archivedChanged();
        void canHaveParentChanged();

        // algunas acciones hacen que el indice de la work order con foco en la lista cambie.
        // con esto lo señalizamos para que la lista cambie su foco
        void workOrderIndexChanged(int newIndex);

    private Q_SLOTS:
        void slotNotifications(WorkOrderStore::WorkOrderNotifications notification, int workOrderId);
        void saveChanges();
        void saveParentChanges();
        void slotArchivedWorkOrderThresholdChanged();

    private:

        void emitLoadedWorkOrderSignals();
        void cleanEditedFields();
        void calculateParentTextSuggestions();
        bool checkIfIsSuggestedWorkOrder(const QString &pattern);

        WorkOrder *_workOrderLoaded;
        WorkOrder *_parentWorkOrder;
        WorkOrder *_parentWorkOrderEdited;
        QString _nameEdited;
        QString _descEdited;
        QString _codeEdited;
        QString _parentTextEdited;
        bool _canHaveParent;

        WorkOrderStore *_store;
        WorkOrderListModel *_listModel;
        bool _editorIsDirty;
        QTimer *_saveDelay;
        QTimer *_saveParentDelay;
        WorkOrderSuggestionsModel *_parentTextSuggestionsModel;
        TTSettings *_settings;
        bool _descriptionIsResetting;

};

#endif /* SRC_WORKORDERS_WORKORDERSVIEWMODEL_H_ */
