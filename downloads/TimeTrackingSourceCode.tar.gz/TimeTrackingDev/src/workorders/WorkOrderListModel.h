/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 28 sep. 2023
**
****************************************************************************/

#ifndef WORKORDERS_WORKORDERLISTMODEL_H_
#define WORKORDERS_WORKORDERLISTMODEL_H_

#include <QAbstractListModel>
#include <QMap>

#include "WorkOrderStore.h"

class QSqlTableModel;
class WorkOrder;

class WorkOrderListModel: public QAbstractListModel {
Q_OBJECT
public:
    WorkOrderListModel(QObject *parent, WorkOrderStore *store);
    virtual ~WorkOrderListModel();

    void initialize();

    int rowCount(const QModelIndex& = QModelIndex()) const override;
    QVariant data(const QModelIndex &, int = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    bool canFetchMore(const QModelIndex &) const override;
    void fetchMore(const QModelIndex &) override;

    void loadModel(int archiveThreshold);
    void clearModel();
    void insertNewWorkOrder(int id);
    void changeWorkOrderState(int id);
    void updateData(int id);
    int indexOf(int id) const;


private:

    enum RoleEnum {
        WOID = Qt::UserRole + 1,
        NAME,
        CODE,
        ARCHIVED
    };

    QVariant sqlData(int i, WorkOrderStore::WoFields field);
    int maxIndex() const;
    void sqlSelect();
    void fetchDbModelUntil(int rowIndex);
    int searchForIndex(int id, int maxIndex);
    void insertIntoListModel(int first, int last, bool signalInsertions);
    void shiftModelForInsertion(const int indicePrimero, const int numHuecos);
    void removeFromListModel(int first, int last);
    /*void loadDbModel();
    void alinearModelos();
    void insertarTareas(int first, int last, bool signalInsertions);
    void borrarTareas(int first, int last);
    int indiceInsercion(const QString &id) const;
    int indiceMaximo() const;
    */

    QSqlTableModel* _databaseModel;
    QMap<int, int> _indexesById;
    QMap<int, WorkOrder*> _wosByIndex;
    WorkOrderStore *_store;
    /*QMap<int, Tarea*> _dataMap;
    QMap<QString, int> _indexMap;
    bool _soloAbiertas;
    GestionTiempo *_gestionTiempo;
    int _indiceTareaActiva;
    TTSettings *_settings;*/
    int _dbPageSize;
    int _archiveThreshold;
};
Q_DECLARE_METATYPE(WorkOrderListModel*);
#endif /* WORKORDERS_WORKORDERLISTMODEL_H_ */
