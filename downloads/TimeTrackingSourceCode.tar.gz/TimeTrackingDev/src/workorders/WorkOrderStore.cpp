/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 28 sep. 2023
**
****************************************************************************/

#include <workorders/WorkOrderStore.h>
#include <QDebug>
#include <QSqlTableModel>
#include <QSqlRecord>
#include "WorkOrder.h"
#include "Reloj.h"
#include <QVariant>

const qint64 WorkOrderStore::_defaultArchiveTimestamp = 9999999999999;

WorkOrderStore::WorkOrderStore(QObject* parent) :
    QObject(parent),
    _woModelDb(nullptr),
    _last(nullptr)
{
    qRegisterMetaType<WorkOrderStore::WorkOrderNotifications>();
}

WorkOrderStore::~WorkOrderStore()
{
    if (_woModelDb) {
        _woModelDb->deleteLater();
    }
}

void WorkOrderStore::initialize()
{
    _woModelDb = new QSqlTableModel(this);
    _woModelDb->setTable("workorders");
}

WorkOrder *WorkOrderStore::workOrderFactoryMethod(int id, const QString &name, const QString &desc, const QString &code)
{
    WorkOrder *wo = new WorkOrder(this, id, name, desc);
    wo->setCode(code);
    return wo;
}

WorkOrder *WorkOrderStore::wo(int id, bool loadFromDb)
{
    WorkOrder *wo = _woByIndex.value(id, nullptr);
    if (loadFromDb && wo == nullptr) {
        qDebug() << "WorkOrderStore::wo: haciendo select con id " << id;
        selectWo(id);
        wo = cacheSelected();
    }
    return wo;
}

WorkOrder *WorkOrderStore::woByCode(const QString &code)
{
    _woModelDb->setFilter("code = '" + code + "'");
    _woModelDb->select();
    int id = sqlData(0, WO_ID).toInt();
    qDebug() << "WorkOrderStore::woByCode: haciendo select con code " << code << ": " << _woModelDb->rowCount() << " rows. first id " << id;
    return id > 0 ? wo(id, true) : nullptr;
}

WorkOrder *WorkOrderStore::last() const
{
    return _last;
}

void WorkOrderStore::selectWo(int id)
{
    _woModelDb->setFilter("id = " + QString::number(id));
    _woModelDb->select();
}

void WorkOrderStore::selectWos(const QString &pattern, bool includeArchived, bool canBeParent, int excludeId)
{
    QString filterClause = "id != " + QString::number(excludeId) + " AND ( name LIKE '%"+pattern+"%' OR code LIKE '%"+pattern+"%' )";
    if (!includeArchived) {
        filterClause = "archivetimestamp = " + QString::number(_defaultArchiveTimestamp) + " AND " + filterClause;
    }
    if (canBeParent) {
        filterClause = "parent = " + QString::number(-1) + " AND " + filterClause;
    }
    _woModelDb->setFilter(filterClause);
    _woModelDb->select();
}

WorkOrder *WorkOrderStore::cacheSelected()
{
    return cacheSelected(0);
}

WorkOrder *WorkOrderStore::cacheSelected(int rowIndex)
{
    WorkOrder *wo = nullptr;
    if (_woModelDb->rowCount() > 0) {
        int id = sqlData(rowIndex, WO_ID).toInt();
        int parentId = sqlData(rowIndex, WO_PARENT).toInt();
        QString name = sqlData(rowIndex, WO_NAME).toString();
        QString desc = sqlData(rowIndex, WO_DESCRIPTION).toString();
        QString cod = sqlData(rowIndex, WO_CODE).toString();
        qlonglong llarchived = sqlData(rowIndex, WO_ARCHIVEDATE).toLongLong();
        QDateTime archived = QDateTime::fromMSecsSinceEpoch(llarchived);
        wo = workOrderFactoryMethod(id, name, desc, cod);
        wo->setArchiveDate(archived);
        wo->setParentWo(parentId);
        qDebug() << "WorkOrderStore::cacheSelected: index " << rowIndex << ", wo: "<< id << " " << name << " "
                << cod << " " << archived << " " << llarchived << " " << desc;
        _woByIndex.insert(id, wo);
    } else {
        qCritical() << "WoStore::cacheSelected: error al parsear. el modelo solo tiene "
                    << _woModelDb->rowCount();
    }
    return wo;
}

QVariant WorkOrderStore::sqlData(int rowIndex, WorkOrderStore::WoFields column)
{
    QModelIndex ind = _woModelDb->index(rowIndex, column, QModelIndex());
    return _woModelDb->data(ind);
}

void WorkOrderStore::createWorkOrderFromData(const QString &name, const QString &code, const QString &description, int parentId, qint64 creationTime, qint64 archiveTime)
{
    QSqlRecord newRecord = _woModelDb->record();
    newRecord.setValue(WO_NAME, name);
    newRecord.setValue(WO_CODE, code);
    newRecord.setValue(WO_CREATIONTIME, creationTime);
    newRecord.setValue(WO_PARENT, parentId);
    newRecord.setValue(WO_DESCRIPTION, description);
    newRecord.setValue(WO_ARCHIVEDATE, QVariant(archiveTime));
    _woModelDb->insertRecord(-1, newRecord);
    qDebug()<< "WorkOrderStore::createNewWorkOrder: "<<newRecord;
    _woModelDb->submitAll();
    // already created in db. Now, we select it and build into memory, with the correct id
    _woModelDb->setFilter("creationtime = " + QString::number(creationTime));
    _woModelDb->select();
    qDebug() << "WorkOrderStore::createNewWorkOrder: count del select " << _woModelDb->rowCount();
    _last = cacheSelected();
}
void WorkOrderStore::createNewWorkOrder()
{
    qint64 creationTime = Reloj::instance()->currentTime().toMSecsSinceEpoch();
    int lastIndex = _woByIndex.isEmpty() ? 1 : (_woByIndex.keys().last() + 1);
    QString name = QString("Nueva work order ") + QString::number(lastIndex);
    createWorkOrderFromData(name, "", "", -1, creationTime, _defaultArchiveTimestamp);
    Q_EMIT(woNotification(WONOTIF_NEWWO, _last->id()));
}

void WorkOrderStore::importWorkOrder(const QString &code)
{
    qint64 creationTime = Reloj::instance()->currentTime().toMSecsSinceEpoch();
    int lastIndex = _woByIndex.isEmpty() ? 1 : (_woByIndex.keys().last() + 1);
    QString name = QString("Nueva work order ") + QString::number(lastIndex);
    createWorkOrderFromData(name, code, "", -1, creationTime, _defaultArchiveTimestamp);
    Q_EMIT(woNotification(WONOTIF_IMPORTED, _last->id()));
}

void WorkOrderStore::archiveWorkOrder(int id)
{
    // asignamos fecha de cierre, hacemos el select en el modelo de db y entonces cambiamos el
    // campo y hacemos submit
    WorkOrder *workOrder = wo(id, false);
    qDebug() << "WorkOrderStore::archiveWorkOrder: id " << id << ", workOrder " << workOrder;
    if (workOrder) {
        QDateTime archiveDate = Reloj::currentDateTime();
        if (updateArchiveDateInDb(id, archiveDate)) {
            _last = workOrder;
            workOrder->setArchiveDate(archiveDate);
            Q_EMIT(woNotification(WONOTIF_ARCHIVED, id));
        } else {
            qCritical() << "Error al actualizar el archiveDate de la wo con id " << id;
        }
    }
}

void WorkOrderStore::reopenWorkOrder(int id)
{
    // asignamos fecha de cierre, hacemos el select en el modelo de db y entonces cambiamos el
    // campo y hacemos submit
    WorkOrder *workOrder = wo(id, false);
    if (workOrder) {
        QDateTime defaultArchiveDate = QDateTime::fromMSecsSinceEpoch(_defaultArchiveTimestamp);
        if (updateArchiveDateInDb(id, defaultArchiveDate)) {
            _last = workOrder;
            workOrder->setArchiveDate(defaultArchiveDate);
            Q_EMIT(woNotification(WONOTIF_REOPEN, id));
        } else {
            qCritical() << "Error al actualizar el archiveDate de la wo con id " << id;
        }
    }
}

bool WorkOrderStore::updateArchiveDateInDb(int id, const QDateTime &archiveDate)
{
    selectWo(id);
    QVariant newField = QVariant::fromValue<qint64>(archiveDate.toMSecsSinceEpoch());
    qDebug() << "WorkOrderStore::updateArchiveDateInDb: id " << id << ", db rowcount " << _woModelDb->rowCount() << "; field " << newField << ", date " << archiveDate;
    QModelIndex index = _woModelDb->index(0, WO_ARCHIVEDATE);
    _woModelDb->setData(index, newField, Qt::EditRole);
    return _woModelDb->submitAll();
}

bool WorkOrderStore::updateWorkOrderDataInDb(int id, const QString &name, const QString &description, const QString &code)
{
    selectWo(id); //cargamos en el modelo de db la work order a editar
    qDebug() << "WorkOrderStore::updateWorkOrderDataInDb: name " << name << ", code " << code << ", desc " << description;
    _woModelDb->setData(_woModelDb->index(0, WO_NAME), QVariant::fromValue(name), Qt::EditRole);
    //_woModelDb->setData(_woModelDb->index(0, WO_PARENT), QVariant::fromValue(parentId), Qt::EditRole);
    _woModelDb->setData(_woModelDb->index(0, WO_DESCRIPTION), QVariant::fromValue(description), Qt::EditRole);
    _woModelDb->setData(_woModelDb->index(0, WO_CODE), QVariant::fromValue(code), Qt::EditRole);
     bool res = _woModelDb->submitAll(); // guardamos los nuevos datos
     if (res) {
         // si se han guardado bien, cargamos los nuevos datos en memoria y notificamos
         WorkOrder *workOrder = wo(id, true);
         if (workOrder) {
             workOrder->setName(name);
             //workOrder->setParentWo(parentId);
             workOrder->setDescription(description);
             workOrder->setCode(code);
             _last = workOrder;
         }
         Q_EMIT(woNotification(WONOTIF_UPDATEDATA, id));
     }
    return res;
}

bool WorkOrderStore::updateParentInDb(int id, int parentId)
{
    selectWo(id); //cargamos en el modelo de db la work order a editar
    qDebug() << "WorkOrderStore::updateParentInDb: id " << id << " nuevo parent " << parentId;
    _woModelDb->setData(_woModelDb->index(0, WO_PARENT), QVariant::fromValue(parentId), Qt::EditRole);
     bool res = _woModelDb->submitAll(); // guardamos los nuevos datos
     if (res) {
         // si se han guardado bien, cargamos los nuevos datos en memoria y notificamos
         WorkOrder *workOrder = wo(id, true);
         if (workOrder) {
             workOrder->setParentWo(parentId);
             _last = workOrder;
         }
         Q_EMIT(woNotification(WONOTIF_UPDATEPARENT, id));
     }
    return res;
}

QList<WorkOrder*> WorkOrderStore::suggestionsFor(const QString &pattern, bool includeArchived, bool canBeParent, int excludeId)
{
    QList<WorkOrder*> results;
    selectWos(pattern, includeArchived, canBeParent, excludeId);
    int currentIndex = 0;
    while (currentIndex < _woModelDb->rowCount()) {
        int currentId = sqlData(currentIndex, WO_ID).toInt();
        if (_woByIndex.contains(currentId)) {
            results.append(wo(currentId, false));
        } else {
            results.append(cacheSelected(currentIndex));
        }
        if (currentIndex == _woModelDb->rowCount() - 1 && _woModelDb->canFetchMore()) {
            _woModelDb->fetchMore();
        }
        currentIndex++;
    }
    return results;
}

bool WorkOrderStore::canHaveParent(int id)
{
    QString filterClause = "parent = " + QString::number(id);
    _woModelDb->setFilter(filterClause);
    _woModelDb->select();
    return _woModelDb->rowCount() == 0;
}



