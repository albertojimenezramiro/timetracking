/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 29 sep. 2023
**
****************************************************************************/

#include "WorkOrdersViewModel.h"
#include <QDebug>
#include "WorkOrderListModel.h"
#include <qqml.h>
#include <QTimer>
#include "WorkOrderSuggestionsModel.h"
#include "../TTSettings.h"

WorkOrdersViewModel::WorkOrdersViewModel(QObject* parent, WorkOrderStore *store, TTSettings *settings) :
    QObject(parent),
    _workOrderLoaded(nullptr),
    _parentWorkOrder(nullptr),
    _parentWorkOrderEdited(nullptr),
    _canHaveParent(false),
    _store(store),
    _editorIsDirty(false),
    _settings(settings),
    _descriptionIsResetting(false)
{
    qmlRegisterUncreatableType<WorkOrderListModel>("TimeTracking.models", 1, 0, "WorkOrderListModel", "No se puede crear un WorkOrderListModel");
    qmlRegisterUncreatableType<WorkOrderSuggestionsModel>("TimeTracking.models", 1, 0, "WorkOrderSuggestionsModel", "No se puede crear un WorkOrderSuggestionsModel");
    connect(_store, &WorkOrderStore::woNotification, this, &WorkOrdersViewModel::slotNotifications, Qt::QueuedConnection);
    connect(_settings, &TTSettings::archivedWorkOrderThresholdChanged, this, &WorkOrdersViewModel::slotArchivedWorkOrderThresholdChanged);
    _listModel = new WorkOrderListModel(this, store);
    _saveDelay = new QTimer();
    connect(_saveDelay, &QTimer::timeout, this, &WorkOrdersViewModel::saveChanges);
    _saveDelay->setInterval(1500);
    _parentTextSuggestionsModel = new WorkOrderSuggestionsModel(this);
    _saveParentDelay = new QTimer();
    _saveParentDelay->setInterval(1000);
    connect(_saveParentDelay, &QTimer::timeout, this, &WorkOrdersViewModel::saveParentChanges);
}

WorkOrdersViewModel::~WorkOrdersViewModel()
{
}

void WorkOrdersViewModel::initialize()
{
    _listModel->initialize();
    _listModel->loadModel(_settings->archivedWorkOrderThreshold());
}

// properties

QString WorkOrdersViewModel::nameEdited() const
{
    return _nameEdited;
}
void WorkOrdersViewModel::setNameEdited(const QString &newValue)
{
    if (_nameEdited != newValue) {
        _nameEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
        qDebug() << "nombre editado " << _nameEdited;
    }
}
QString WorkOrdersViewModel::descEdited() const
{
    return _descEdited;
}
void WorkOrdersViewModel::setDescEdited(const QString &newValue)
{
    if (_descEdited != newValue && !_descriptionIsResetting) {
        _descEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
    }
}
QString WorkOrdersViewModel::codeEdited() const
{
    return _codeEdited;
}
void WorkOrdersViewModel::setCodeEdited(const QString &newValue)
{
    if (_codeEdited != newValue) {
        _codeEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
    }
}
QString WorkOrdersViewModel::parentTextEdited() const
{
    return _parentTextEdited;
}
void WorkOrdersViewModel::setParentTextEdited(const QString &newValue)
{
    if (_parentTextEdited != newValue) {
        _parentTextEdited = newValue;
        qDebug() << "WorkOrdersViewModel::setParentTextEdited: parent text " << newValue;
        calculateParentTextSuggestions();
        checkIfIsSuggestedWorkOrder(newValue);
    }
}

QString WorkOrdersViewModel::name() const
{
    return _workOrderLoaded ? _workOrderLoaded->name() : "";
}

QString WorkOrdersViewModel::desc() const
{
    return _workOrderLoaded ? _workOrderLoaded->description() : "";
}

QString WorkOrdersViewModel::code() const
{
    return _workOrderLoaded ? _workOrderLoaded->code() : "";
}

QString WorkOrdersViewModel::parentCode() const
{
    QString parentCode = "";
    if (_workOrderLoaded) {
        int parentId = _workOrderLoaded->parentWo();
        if (parentId > 0) {
            WorkOrder *parent = _store->wo(parentId, false);
            if (parent) {
                parentCode = parent->code();
            }
        }
    }
    return parentCode;
}

bool WorkOrdersViewModel::archived() const
{
    return _workOrderLoaded && _workOrderLoaded->isArchived();
}

int WorkOrdersViewModel::id() const
{
    return _workOrderLoaded ? _workOrderLoaded->id() : -1;
}

WorkOrderListModel *WorkOrdersViewModel::listModel() const
{
    return _listModel;
}

bool WorkOrdersViewModel::canHaveParent() const
{
    return _canHaveParent;
}

///////////////////////
///                 ///
/// BUSINESS-LOGIC  ///
///                 ///
///////////////////////

void WorkOrdersViewModel::loadWorkOrder(int id)
{
    WorkOrder *wo = id > 0 ? _store->wo(id, false) : nullptr;
    qDebug() << "WorkOrdersViewModel::loadWorkOrder: id " << id << ", wo " << wo << ", loaded " << _workOrderLoaded;
    if (wo != _workOrderLoaded) {
        saveChanges();
        _workOrderLoaded = wo;
        if (wo && wo->parentWo() > 0) {
            _parentWorkOrder = _store->wo(wo->parentWo(), true);
        } else {
            _parentWorkOrder = nullptr;
        }
        _canHaveParent = _store->canHaveParent(id);
        qDebug() << "WorkOrdersViewModel::loadWorkOrder: ahora loaded es " << (_workOrderLoaded ? _workOrderLoaded->id() : -1);
        emitLoadedWorkOrderSignals();
        cleanEditedFields();
    }
}

void WorkOrdersViewModel::createNewWorkOrder()
{
    saveChanges();
    _store->createNewWorkOrder();
}

void WorkOrdersViewModel::archiveWorkOrder()
{
    saveChanges();
    if (_workOrderLoaded && !_workOrderLoaded->isArchived()) {
        _store->archiveWorkOrder(_workOrderLoaded->id());
    }
}

void WorkOrdersViewModel::reopenWorkOrder()
{
    saveChanges();
    if (_workOrderLoaded && _workOrderLoaded->isArchived()) {
        _store->reopenWorkOrder(_workOrderLoaded->id());
    }
}

void WorkOrdersViewModel::saveChanges()
{
    qDebug() << "WorkOrdersViewModel::saveChanges: dirty " << _editorIsDirty;
    _saveDelay->stop();
    if (_workOrderLoaded && _editorIsDirty) {
        _store->updateWorkOrderDataInDb(_workOrderLoaded->id(), _nameEdited, _descEdited, _codeEdited);
        _editorIsDirty = false;
    }
    qDebug() << "WorkOrdersViewModel::saveChanges: final";
}

void WorkOrdersViewModel::saveParentChanges()
{
    qDebug() << "WorkOrdersViewModel::saveParentChanges: loaded "<<(_workOrderLoaded?_workOrderLoaded->id():-1)<<"; parent "
             << (_parentWorkOrder?_parentWorkOrder->id():-1)<<", parentEdited "<<(_parentWorkOrderEdited?_parentWorkOrderEdited->id():-1);
    _saveParentDelay->stop();
    if (_workOrderLoaded && _parentWorkOrder != _parentWorkOrderEdited) {
        int parentId = _parentWorkOrderEdited ? _parentWorkOrderEdited->id() : -1;
        qDebug() << "WorkOrdersViewModel::saveParentChanges: se guarda como nuevo padre " << parentId;
        _store->updateParentInDb(_workOrderLoaded->id(), parentId);
    }
    qDebug() << "WorkOrdersViewModel::saveParentChanges: final";
}

void WorkOrdersViewModel::emitLoadedWorkOrderSignals()
{
    Q_EMIT(nameChanged());
    _descriptionIsResetting = true;
    Q_EMIT(descChanged());
    _descriptionIsResetting = false;
    Q_EMIT(codeChanged());
    Q_EMIT(parentCodeChanged());
    Q_EMIT(idChanged());
    Q_EMIT(archivedChanged());
    Q_EMIT(canHaveParentChanged());
}

void WorkOrdersViewModel::cleanEditedFields()
{
    qDebug() << "WorkOrdersViewModel::cleanEditedFields";
    // esto no es un cambio que haya que guardar, por lo que no debe lanzar el timer ni actualizar
    // el flag de dirty. Por eso no uso setters.

    _nameEdited = name();
    _descEdited = desc();
    _codeEdited = code();
    _parentTextEdited = parentCode();
    calculateParentTextSuggestions();
    _parentWorkOrderEdited = _parentWorkOrder;
}

void WorkOrdersViewModel::slotNotifications(WorkOrderStore::WorkOrderNotifications notification, int workOrderId)
{
    switch (notification) {
        case WorkOrderStore::WONOTIF_NEWWO:
        case WorkOrderStore::WONOTIF_IMPORTED: {
            qDebug() << "WorkOrdersViewModel::slotNotifications: nueva o importada. insertando notif en listmodel";
            WorkOrder *n = _store->wo(workOrderId, false);
            _listModel->insertNewWorkOrder(n->id());
            Q_EMIT(workOrderIndexChanged(_listModel->indexOf(n->id())));
            break;
        }
        case WorkOrderStore::WONOTIF_ARCHIVED:
        case WorkOrderStore::WONOTIF_REOPEN: {
            WorkOrder *n = _store->wo(workOrderId, false);
            _listModel->changeWorkOrderState(n->id());
            if (notification == WorkOrderStore::WONOTIF_REOPEN) {
                qDebug() << "WorkOrdersViewModel::slotNotifications: notification reopen, enviando workOrderIndexChanged()";
                Q_EMIT(workOrderIndexChanged(_listModel->indexOf(n->id())));
            }
            break;
        }
        case WorkOrderStore::WONOTIF_UPDATEDATA: {
            WorkOrder *n = _store->wo(workOrderId, false);
            if (_workOrderLoaded->id() == n->id()) {
                emitLoadedWorkOrderSignals();
                cleanEditedFields();
            }
            qDebug() << "WorkOrdersViewModel::slotNotifications: updatedata, id " << n->id() << ", actualizando modelo de lista";
            _listModel->updateData(n->id());
            break;
        }
        case WorkOrderStore::WONOTIF_UPDATEPARENT: {
            WorkOrder *n = _store->wo(workOrderId, false);
            if (_workOrderLoaded->id() == n->id()) {
                qDebug() << "WorkOrdersViewModel::slotNotifications: updateparent";
                emitLoadedWorkOrderSignals();
                if (n->parentWo() > 0) {
                    _parentWorkOrder = _store->wo(n->parentWo(), true);
                } else {
                    _parentWorkOrder = nullptr;
                }
                cleanEditedFields();
            }

            break;
        }
        default:
            break;
    }
}
void WorkOrdersViewModel::calculateParentTextSuggestions()
{
    int excludeId = _workOrderLoaded ? _workOrderLoaded->id() : -1;
    qDebug() << "WorkOrdersViewModel::calculateParentTextSuggestions: calculando sugerencias para texto '"
             << _parentTextEdited << "' excluyendo id " << excludeId;
    _parentTextSuggestionsModel->loadModel(_store->suggestionsFor(_parentTextEdited, false, true, excludeId));
}

WorkOrderSuggestionsModel *WorkOrdersViewModel::parentTextSuggestionsModel() const
{
    return _parentTextSuggestionsModel;
}

void WorkOrdersViewModel::selectParentTextSuggestion(int index)
{
    WorkOrder *suggestion = _parentTextSuggestionsModel->suggestionAt(index);
    qDebug() << "WorkOrdersViewModel::selectParentTextSuggestion: index " << index << ", suggestion " << (suggestion?suggestion->id():-1);
    if (suggestion) {
        _parentWorkOrderEdited = suggestion;
        saveParentChanges();
    }
}

bool WorkOrdersViewModel::checkIfIsSuggestedWorkOrder(const QString &pattern)
{
    QString trimmed = pattern.trimmed();
    WorkOrder *found = trimmed.isEmpty() ? nullptr : _parentTextSuggestionsModel->suggestionWithCode(trimmed);
    if (found || pattern.trimmed().isEmpty()) {
        _parentWorkOrderEdited = found;
        _saveParentDelay->start();
    }
    return (found != nullptr);
}

void WorkOrdersViewModel::slotArchivedWorkOrderThresholdChanged()
{
    qDebug() << "WorkOrdersViewModel::slotArchivedWorkOrderThresholdChanged";
    _listModel->loadModel(_settings->archivedWorkOrderThreshold());
    Q_EMIT(workOrderIndexChanged(0));
}
