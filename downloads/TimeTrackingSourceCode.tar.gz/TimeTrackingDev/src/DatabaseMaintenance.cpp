/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 6 oct 2023
**
****************************************************************************/

#include "DatabaseMaintenance.h"
#include <QTimer>
#include <QSqlRecord>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QFile>
#include "TTSettings.h"
#include "Reloj.h"
#include <QDebug>
#include "Schema4Update.h"
#include <QMetaObject>
#include <QDir>

QString DatabaseMaintenance::_userDataDirectory = "";

const QString DatabaseMaintenance::_oldSqlPath = "data/db.sqlite";
const QString DatabaseMaintenance::_oldSqlBackupPath = "data/db%1.sqlite";

const QString DatabaseMaintenance::_sqlTareas = "CREATE TABLE \"tareas\" ( \
 `id`    INTEGER PRIMARY KEY AUTOINCREMENT, \
 `nombre`    TEXT NOT NULL, \
 `desc`  TEXT, \
 `wo`    TEXT, \
 `cerrado`   INTEGER DEFAULT 9999999999999, \
 `creacion`   INTEGER, \
 `borrado`   INTEGER DEFAULT 0, \
 `jiraId`  TEXT \
)";

const QString DatabaseMaintenance::_sqlTiempo = "CREATE TABLE `tiempo` ( \
 `id`    INTEGER PRIMARY KEY AUTOINCREMENT, \
 `idTarea`   INTEGER NOT NULL, \
 `timestamp` NUMERIC \
)";

const QString DatabaseMaintenance::_sqlWos = "CREATE TABLE \"wos\" ( \
 `id`    INTEGER PRIMARY KEY AUTOINCREMENT, \
 `idTarea`    INTEGER NOT NULL, \
 `wo`  TEXT, \
 `perc`    INTEGER, \
 `idWorkOrder`  INTEGER \
)";

const QString DatabaseMaintenance::_sqlWorkOrders = "CREATE TABLE \"workorders\" ( \
 `id`    INTEGER PRIMARY KEY AUTOINCREMENT, \
 `name`    TEXT NOT NULL, \
 `code`  TEXT, \
 `creationtime` INTEGER, \
 `parent`    INTEGER, \
 `desc`  TEXT, \
 `archivetimestamp` INTEGER DEFAULT 9999999999999 \
)";

const QString DatabaseMaintenance::_sqlSettings = "CREATE TABLE \"settings\" ( \
`id`    INTEGER PRIMARY KEY AUTOINCREMENT, \
`name`    TEXT NOT NULL, \
`value`  TEXT \
)";

const QString DatabaseMaintenance::_sqlProjects = "CREATE TABLE \"projects\" ( \
 `id`    INTEGER PRIMARY KEY AUTOINCREMENT, \
 `name`    TEXT NOT NULL, \
 `code`  TEXT, \
 `creationtime` INTEGER, \
 `client`    TEXT, \
 `desc`  TEXT, \
 `archivetimestamp` INTEGER DEFAULT 9999999999999 \
)";

const QString DatabaseMaintenance::_sqlProjectTask = "CREATE TABLE \"projecttask\" ( \
 `id`    INTEGER PRIMARY KEY AUTOINCREMENT, \
 `taskid`    INTEGER NOT NULL, \
 `projectid`  INTEGER \
)";

const QString DatabaseMaintenance::_sqlAlterJiraId = "ALTER TABLE \"tareas\" \
 ADD COLUMN `jiraId`  TEXT";

const QString DatabaseMaintenance::_sqlAlterIdWorkOrder = "ALTER TABLE \"wos\" \
 ADD COLUMN `idWorkOrder`  INTEGER";


QString DatabaseMaintenance::sqlPath()
{
    QString filename = QDir::toNativeSeparators(_userDataDirectory + _oldSqlPath);
    return filename;
}

QString DatabaseMaintenance::sqlBackupPath()
{
    QString filename = QDir::toNativeSeparators(_userDataDirectory + _oldSqlBackupPath);
    return filename;
}

DatabaseMaintenance::DatabaseMaintenance(QObject *parent) :
    QObject(parent),
    _isInitialized(false)
{
    qDebug() << "DatabaseMaintenance::DatabaseMaintenance: user data dir " << _userDataDirectory;

}

DatabaseMaintenance::~DatabaseMaintenance()
{

}

void DatabaseMaintenance::setVersion(const QString &version)
{
    _version = version;
}

bool DatabaseMaintenance::initialize()
{
    bool res = false;
    // abre la base de datos y crea las tablas que no estén creadas
    Q_EMIT(newMessage("Comprobando base de datos..."));
    createDatabase();
    res = true;
    return res;
}

bool DatabaseMaintenance::createDatabase()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    QString filename = sqlPath();
    qDebug() << "Inicializando base de datos: " << filename;
    db.setDatabaseName(sqlPath());


    bool res = false;
    if (db.open()) {
        QSqlQuery query;
        bool wos = query.exec(_sqlWos);
        bool tareas = query.exec(_sqlTareas);
        bool tiempo = query.exec(_sqlTiempo);
        bool workorders = query.exec(_sqlWorkOrders);
        bool settings = query.exec(_sqlSettings);
        bool projects = query.exec(_sqlProjects);
        bool projecttask = query.exec(_sqlProjectTask);
        qDebug() << "creacion de tablas: wos " << wos << ", tareas " << tareas << ", tiempo " << tiempo
                << ", workorders " << workorders << ", settings " << settings << ", projects " << projects
                << ", projecttask " << projecttask;
        db.close();
        res = true;
        QMetaObject::invokeMethod(this, &DatabaseMaintenance::applySchemaUpdates, Qt::QueuedConnection);
    } else {
        Q_EMIT(newMessage("Error al crear/abrir base de datos en "+sqlPath()));
        qDebug() << "Error con la base de datos: " << sqlPath();
    }
    return res;
}

bool DatabaseMaintenance::isInitialized() const
{
    return _isInitialized;
}

void DatabaseMaintenance::applySchemaUpdates()
{
    QSqlDatabase db = QSqlDatabase::database();
    int schVersion = schemaVersion();
    qDebug() << "schema version " << schVersion;
    // cada versión debe aplicar las actualizaciones a versiones
    // posteriores de una en una
    switch (schVersion) {
        case 1: {
            Q_EMIT(newMessage("Aplicando actualización de base de datos (v2)..."));
            QMetaObject::invokeMethod(this, &DatabaseMaintenance::updateSchemaToVersion2, Qt::QueuedConnection);
            break;
        }
        case 2: {
            Q_EMIT(newMessage("Aplicando actualización de base de datos (v3)..."));
            QMetaObject::invokeMethod(this, &DatabaseMaintenance::updateSchemaToVersion3, Qt::QueuedConnection);
            break;
        }
        case 3 : {
            Q_EMIT(newMessage("Aplicando actualización de base de datos (v4)..."));
            QMetaObject::invokeMethod(this, &DatabaseMaintenance::updateSchemaToVersion4, Qt::QueuedConnection);
            break;
        }
        case 4 : {
            _isInitialized = true;
            Q_EMIT(initialized());
            // backups cada 5 minutos
            QTimer::singleShot(5*60*1000, this, &DatabaseMaintenance::slotUserBackup);
        }
    }
}

int DatabaseMaintenance::schemaVersion()
{
    QSqlTableModel tmodel;
    tmodel.setTable("settings");
    tmodel.setFilter("name LIKE 'schemaversion'");
    tmodel.select();
    int schemaVersion = 0;
    if (tmodel.rowCount() == 0) {
        QSqlRecord record = tmodel.record();
        record.setValue(SETTINGSFIELDS_NAME, "schemaversion");
        record.setValue(SETTINGSFIELDS_VALUE, QString::number(1));
        tmodel.insertRecord(-1, record);
        tmodel.submitAll();
        schemaVersion = 1;
    } else {
        schemaVersion = tmodel.data(tmodel.index(0, SETTINGSFIELDS_VALUE, QModelIndex())).toString().toInt();
    }
    return schemaVersion;
}

void DatabaseMaintenance::saveSchemaVersion(int newVersion)
{
    QSqlTableModel tmodel;
    tmodel.setTable("settings");
    tmodel.setFilter("name LIKE 'schemaversion'");
    tmodel.select();
    tmodel.setData(tmodel.index(0, SETTINGSFIELDS_VALUE), QString::number(newVersion), Qt::EditRole);
    tmodel.submitAll();
}

void DatabaseMaintenance::slotUserBackup()
{
    createUserBackup();
    QTimer::singleShot(5*60*1000, this, &DatabaseMaintenance::slotUserBackup);
}

void DatabaseMaintenance::createUserBackup()
{
    // hace backup de base de datos y settings
    QString fileName = sqlBackupPath().arg(_version);
    qDebug() << "haciendo backup de base de datos " << fileName;
    if (QFile::exists(fileName)) {
        QFile::remove(fileName);
    }
    QFile::copy(sqlPath(), fileName);

    fileName = TTSettings::backupPath().arg(_version);
    qDebug() << "haciendo backup de settings " << fileName;
    if (QFile::exists(fileName)) {
        QFile::remove(fileName);
    }
    QFile::copy(TTSettings::filePath(), fileName);
}

void DatabaseMaintenance::updateSchemaToVersion2()
{
    // se agrega una columna a la tabla de tareas. no hay que cambiar las filas
    QSqlDatabase db = QSqlDatabase::database();
    QSqlTableModel tmodel;
    tmodel.setTable("tareas");
    if (tmodel.fieldIndex("jiraId") == -1) {
        db.exec(_sqlAlterJiraId);
    }

    tmodel.select();
    int index = 0;
    int fixed = 0;
    bool end = false;
    bool canFetch = true;
    while (canFetch && !end) {
        while (!end && index < tmodel.rowCount()) {
            qint64 creation = tmodel.data(tmodel.index(index, 5, QModelIndex())).toLongLong();
            qint64 archive = tmodel.data(tmodel.index(index, 4, QModelIndex())).toLongLong();
            if (creation == 0) {
                if (archive == 9999999999999) {
                    // tarea abierta, ponemos una creación al azar
                    creation = 1504764625790;
                } else {
                    // tarea cerrada, ponemos de creación un segundo antes del cierre
                    creation = archive - 1000;
                }
                tmodel.setData(tmodel.index(index, 5), creation);
                tmodel.submitAll();
                fixed++;
            } else {
                end = true;
            }
            index++;
        }
        if (tmodel.canFetchMore()) {
            tmodel.fetchMore();
            canFetch = true;
        } else {
            canFetch = false;
        }
    }
    qDebug() << "updateSchemaToVersion2: asignadas " << fixed << " creaciones a tareas existentes";
    saveSchemaVersion(2);
    QMetaObject::invokeMethod(this, &DatabaseMaintenance::applySchemaUpdates, Qt::QueuedConnection);

}

void DatabaseMaintenance::updateSchemaToVersion3()
{
    // se agrega soporte para múltiples wos por tarea, con porcentajes. Se crea la tabla wos
    // y la work order de la tarea se guarda en esta nueva tabla en lugar de la tabla de tareas.
    // debemos revisar la tabla de tareas: cualquier tarea con el campo wo no vacío, debe crear
    // una entrada en la nueva tabla wos con 100% de porcentaje
    QSqlTableModel tareasModel;
    tareasModel.setTable("tareas");
    tareasModel.setFilter("wo != ''"); // tareas con wo antigua
    tareasModel.select();
    QSqlTableModel woModel;
    woModel.setTable("wos");
    int index = 0;
    bool canFetch = true;
    while (canFetch) {
        while (index < tareasModel.rowCount()) {
            int idTarea = tareasModel.data(tareasModel.index(index, 0, QModelIndex())).toInt();
            QString oldWo = tareasModel.data(tareasModel.index(index, 3, QModelIndex())).toString();
            qDebug() << "updateSchemaToVersion3: tarea "<<idTarea<<", old wo '"<<oldWo<<"'";
            QSqlRecord newWo = woModel.record();
            // por cada wo vieja insertamos un nuevo registro en la tabla wos, con 100%
            newWo.setValue(1, idTarea);
            newWo.setValue(2,oldWo);
            newWo.setValue(3, 100);
            woModel.insertRecord(-1, newWo);
            woModel.submitAll();
            // y borramos el valor antiguo en la tabla de tareas
            tareasModel.setData(tareasModel.index(index, 3), "");
            tareasModel.submitAll();
            index++;
        }
        if (tareasModel.canFetchMore()) {
            tareasModel.fetchMore();
            canFetch = true;
        } else {
            canFetch = false;
        }
    }
    qDebug() << "updateSchemaToVersion3: convertidas " << index << " tareas";
    saveSchemaVersion(3);
    QMetaObject::invokeMethod(this, &DatabaseMaintenance::applySchemaUpdates, Qt::QueuedConnection);
}

void DatabaseMaintenance::updateSchemaToVersion4()
{
    Q_EMIT(newMessage("Aplicando actualización de base de datos (v4)..."));
    // las work orders tienen entidad y tabla propia. la tabla wos deja de contener el código de
    // work order y pasa a tener el id de la work order
    QSqlDatabase db = QSqlDatabase::database();
    QSqlTableModel tmodel;
    tmodel.setTable("wos");
    // se agrega nueva columna idWorkOrder a tabla wos
    if (tmodel.fieldIndex("idWorkOrder") == -1) {
        db.exec(_sqlAlterIdWorkOrder);
    }

    Schema4Update *update = new Schema4Update();
    update->checkWorkOrders(); // corregirá la tabla wos para que apunte a ids reales de la tabla work orders
    saveSchemaVersion(4);
    QMetaObject::invokeMethod(this, &DatabaseMaintenance::applySchemaUpdates, Qt::QueuedConnection);
}

