/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 2 feb. 2019
**
****************************************************************************/

#ifndef SRC_TIEMPO_WORKINGDAYMANAGEMENT_H_
#define SRC_TIEMPO_WORKINGDAYMANAGEMENT_H_

#include <QObject>
#include "TimeStore.h"
#include <QDateTime>

class Task;
class TTSettings;
class TaskStore;

class WorkingDayManagement : public QObject
{
Q_OBJECT
    public:
        WorkingDayManagement(QObject *parent, TimeStore *timeStore, TaskStore *taskStore, TTSettings *settings);
        virtual ~WorkingDayManagement();

        QDateTime workingDayDuration() const;
        void initialize();

    Q_SIGNALS:
        void workingDayDurationChanged();

    private Q_SLOTS:
        void slotNotifications(TimeStore::TimeNotifications notification, qint64 entryId);

        qint64 calculateWorkingDayDuration();
        void adjustWorkingDayDuration();

    private:
        Task *calculateNewActiveTask();

        void adjustWorkingDayDurationWithNewTask(Task* newActiveTask);
        void setWorkingDayDuration(qint64 newduration);

        TimeStore *_timeStore;
        TaskStore *_taskStore;
        qint64 _workingDayDuration;
        QDateTime _lastWorkingDayDurationRefresh;
        Task *_lastActiveTask;
        TTSettings *_settings;
};

#endif /* SRC_TIEMPO_WORKINGDAYMANAGEMENT_H_ */
