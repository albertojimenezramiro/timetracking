/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 19 jan. 2019
**
****************************************************************************/

#ifndef SRC_TIEMPO_TIMESTORE_H_
#define SRC_TIEMPO_TIMESTORE_H_

#include <QObject>
#include <QHash>

class TimeEntry;
class QSqlTableModel;
class TaskStore;

class TimeStore : public QObject {
    Q_OBJECT
public:
    enum TableFields {
        FIELD_ID = 0,
        FIELD_TASKID,
        FIELD_TSTAMP
    };
    typedef enum TimeNotifications {
        TIMENOTIF_NONE = 0,
        TIMENOTIF_NEWENTRY,
        TIMENOTIF_UPDATEDATA
    } TimeNotifications;
    Q_ENUM(TimeNotifications)


    TimeStore(QObject* parent, TaskStore *taskStore);
    virtual ~TimeStore();

    void initialize();

    TimeEntry *timeEntry(const qint64 idEntrada) const;
    TimeEntry *mostRecentEntry() const;

    QList<TimeEntry*> loadRecentEntries();
    QList<TimeEntry*> loadTimeRange(const QDateTime &begin, const QDateTime &end);
    QList<TimeEntry*> loadPreviousTo(const TimeEntry *entry, const int numEntries);
    QList<TimeEntry*> loadEntriesForDate(const QDate &date);


    void editEntry(const qint64 entryId, const QDateTime &newTime);
    void createEntry(int taskId);

Q_SIGNALS:
    // sends a notification
    void timeNotification(TimeStore::TimeNotifications notification, qint64 entryId);

private:
    QList<TimeEntry*> parseDbModel(const int first, const int last);
    TimeEntry* timeEntryFactoryMethod(qint64 idEntrada, qint64 idTarea, const QDateTime &tiempo);

    QSqlTableModel* _timeDbModel;
    QHash<qint64, TimeEntry*> _entriesById;
    TimeEntry *_mostRecentEntry;
    TaskStore *_taskStore;
};

#endif /* SRC_TIEMPO_TIMESTORE_H_ */
