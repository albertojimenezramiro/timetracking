/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 12 oct. 2018
**
****************************************************************************/

#ifndef TIEMPO_TIMEENTRY_H_
#define TIEMPO_TIMEENTRY_H_

#include <QDateTime>

class Task;

class TimeEntry {

public:
    TimeEntry();
    TimeEntry(qint64 id, int taskId, const QDateTime &time);
    virtual ~TimeEntry();

    QDateTime time() const;
    qint64 id() const;
    int taskId() const;
    Task *task() const;

    void setTime(const QDateTime &value);
    void setTaskId(int id);
    void setTask(Task *task);

private:
    qint64 _id;
    int _taskId;
    QDateTime _time;
    Task *_task;
};

#endif /* TIEMPO_TIMEENTRY_H_ */
