/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 9 oct 2023
**
****************************************************************************/

#ifndef SRC_TIME_TIMEVIEWMODEL_H_
#define SRC_TIME_TIMEVIEWMODEL_H_

#include <QObject>
#include <QDateTime>
#include <QString>
#include "TimeStore.h"

class TimeListModel;
class TTSettings;
class TaskStore;
class TimeEntry;
class WorkingDayManagement;

class TimeViewModel : public QObject
{
    Q_OBJECT

    // data from loaded task

    Q_PROPERTY(TimeListModel* listModel READ listModel CONSTANT)
    Q_PROPERTY(QDateTime entryTime READ entryTime NOTIFY entryTimeChanged)
    Q_PROPERTY(QDateTime timeEdited READ timeEdited WRITE setTimeEdited NOTIFY timeEditedChanged)
    Q_PROPERTY(QString errorStr READ errorStr NOTIFY errorStrChanged)

    Q_PROPERTY (QDateTime workingDayDuration READ workingDayDuration NOTIFY workingDayDurationChanged)
    Q_PROPERTY (bool isActiveTask READ isActiveTask NOTIFY isActiveTaskChanged)

    public:
        TimeViewModel(QObject* parent, TimeStore *timeStore, TaskStore *taskStore, TTSettings *settings);
        virtual ~TimeViewModel();

        void initialize();

        TimeListModel *listModel() const;
        QDateTime entryTime() const;
        QDateTime timeEdited() const;
        void setTimeEdited(QDateTime datetime);
        QString errorStr() const;
        void setErrorStr(const QString &error);
        QDateTime workingDayDuration() const;
        bool isActiveTask() const;

        //business-logic
        Q_INVOKABLE void loadTimeEntry(qint64 id);
        Q_INVOKABLE void saveChanges();
        Q_INVOKABLE void restartTimeEdited();
        Q_INVOKABLE void createNewEntry(int taskId);

    Q_SIGNALS:
        void entryTimeChanged();
        void timeEditedChanged();
        void errorStrChanged();
        void workingDayDurationChanged();
        void isActiveTaskChanged();

    private Q_SLOTS:
        void slotNotifications(TimeStore::TimeNotifications notification, qint64 entryId);

    private:
        void calculateError();

        TimeStore *_timeStore;
        TaskStore *_taskStore;
        TimeListModel *_listModel;
        bool _editorIsDirty;
        TTSettings *_settings;
        TimeEntry *_timeEntry;
        QDateTime _timeEdited;
        QString _errorStr;
        WorkingDayManagement *_workingDayManagement;
};

#endif /* SRC_TIME_TIMEVIEWMODEL_H_ */
