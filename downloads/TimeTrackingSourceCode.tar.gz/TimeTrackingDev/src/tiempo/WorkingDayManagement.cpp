/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 2 feb. 2019
**
****************************************************************************/

#include "WorkingDayManagement.h"
#include "Reloj.h"
#include "TTSettings.h"
#include "TimeEntry.h"
#include "../tareas/TaskStore.h"
#include "../tareas/Task.h"
#include <QDebug>

WorkingDayManagement::WorkingDayManagement(QObject *parent, TimeStore *timeStore, TaskStore *taskStore, TTSettings *settings) :
    QObject(parent),
    _timeStore(timeStore),
    _taskStore(taskStore),
    _workingDayDuration(0),
    _lastActiveTask(nullptr),
    _settings(settings)
{
    connect(_timeStore, &TimeStore::timeNotification, this, &WorkingDayManagement::slotNotifications, Qt::QueuedConnection);
}

WorkingDayManagement::~WorkingDayManagement()
{

}

void WorkingDayManagement::initialize()
{
    if (_settings) {
        connect(_settings, &TTSettings::limitesJornadaChanged, this, &WorkingDayManagement::calculateWorkingDayDuration);
    }
    connect(Reloj::instance(), &Reloj::currentTimeChanged, this, &WorkingDayManagement::adjustWorkingDayDuration);
    _lastActiveTask = calculateNewActiveTask();
    calculateWorkingDayDuration();
}

QDateTime WorkingDayManagement::workingDayDuration() const
{
    QDateTime res = Reloj::currentDateTime();
    res.setTime(QTime(0, 0, 0, 0));
    return res.addMSecs(_workingDayDuration);
}

void WorkingDayManagement::setWorkingDayDuration(qint64 newduration)
{
    if (newduration != _workingDayDuration) {
        _workingDayDuration = newduration;
        Q_EMIT(workingDayDurationChanged());
    }
}

void WorkingDayManagement::slotNotifications(TimeStore::TimeNotifications notification, qint64 entryId)
{
    Q_UNUSED(entryId)
    Task *newActiveTask = calculateNewActiveTask();
    switch (notification) {
        case TimeStore::TIMENOTIF_NEWENTRY: {
            qDebug() << "WorkingDayManagement::slotNotifications: nueva entrada de tiempo " << entryId<<", lastActiveTask " << _lastActiveTask;
            adjustWorkingDayDurationWithNewTask(newActiveTask);
            _lastActiveTask = newActiveTask;
            break;
        }
        case TimeStore::TIMENOTIF_UPDATEDATA:{
            // cuando se edita un registro, como no tenemos demasiado detalle del valor anterior,
            // no nos complicamos y volvemos a calcular la duración de la jornada desde cero
            calculateWorkingDayDuration();
            _lastActiveTask = calculateNewActiveTask();
            break;
        }
        default:
            break;
    }
}

Task *WorkingDayManagement::calculateNewActiveTask()
{
    TimeEntry *lastEntry = _timeStore->mostRecentEntry();
    return lastEntry ? lastEntry->task() : nullptr;
}

qint64 WorkingDayManagement::calculateWorkingDayDuration()
{
    /*
     * Calcula la duración de la jornada actual, el tiempo reportado a tareas. Carga la lista de
     * todos los registros de tiempo de hoy (podría venir alguno de ayer) y busca el más tempranero.
     * A partir de ahí, comienza a recorrer los registros y a sumar en los tramos correspondientes a
     * tareas.
     *
     * Tiene en cuenta los límites de comienzo y final de jornada configurados en settings, para no
     * contar fuera de estos límites salvo que haya un registro fuera de ellos.
     */
    QDateTime current = Reloj::currentDateTime();
    qint64 mseconds = 0;
    QTime comienzo = _settings->comienzoJornada();
    QTime final = _settings->finalJornada();
    qDebug() << "WorkingDayManagement::calculateWorkingDayDuration: current "<<current<<", comienzo "<<comienzo
             << ", final "<<final;
    bool found = false;
    QList<TimeEntry*> tmp = _timeStore->loadEntriesForDate(current.date());
    int currIndex = 0;
    //buscamos la muestra más tempranera dentro del día actual
    while (currIndex < tmp.size() - 1 && !found) {
        TimeEntry *entrada = tmp.at(currIndex);
        if (entrada->time().date() != current.date()) {
            found = true;
        } else {
            ++currIndex;
        }
    }
    if (!found) {
        currIndex = tmp.size() - 1;
    }
    bool tareaActiva = false;
    QDateTime lastts = QDateTime();//momento hasta el que hay contado y confirmado en mseconds
    QDateTime lastEntryTime = QDateTime();
    //como invariante, lastts es null o pertenece al día actual; nunca puede ser de otro día
    while (currIndex >= 0) {
        TimeEntry *entrada = tmp.at(currIndex);
        QDateTime entradaTiempo = entrada->time();
        Task *task = entrada->task();
        qDebug()<<"WorkingDayManagement::calculateWorkingDayDuration: entrada "<<entradaTiempo<<", tarea "<<(task ? task->id() : -1);
        if (entradaTiempo.date() == current.date()) {
            if (tareaActiva) {//si había tarea activa, hay que contar y sumar siempre
                if (lastts.isNull()) {//si lastts es null, es el primer intervalo de tarea activa
                    //a sumar, y hay que calcular el momento inicial
                    QTime start = QTime(0,0,0,0);
                    if (entradaTiempo.time() > comienzo) {
                        start = comienzo;
                    }
                    lastts = QDateTime(Reloj::currentDate(), start);
                    qDebug() << "WorkingDayManagement::calculateWorkingDayDuration: sumando el primer intervalo, con lastts null. poniendo en lastts "<<lastts;
                }
                qint64 diff = lastts.msecsTo(entradaTiempo);
                qDebug()<<"WorkingDayManagement::calculateWorkingDayDuration: "<<lastts<<" -- "<<entradaTiempo<<" == "<<diff<<" "<<(QTime(0,0,0,0).addMSecs(diff));
                mseconds += diff;
                lastts = entradaTiempo;
                _lastWorkingDayDurationRefresh = entradaTiempo;
            } else { //si no había una tarea activa no hay que contar nada
                if (task) {
                    //si se activa una tarea, grabamos lastts para que cuando sumemos el tiempo de esta
                    //nueva tarea, empiece por aquí. Como es comienzo de una tarea, no hay posibilidad
                    //de saltarse el comienzo, hay qeu evaluar desde este momento sí o sí.
                    //también da igual el final de jornada.
                    lastts = entradaTiempo;
                    _lastWorkingDayDurationRefresh = entradaTiempo;
                    qDebug()<<"WorkingDayManagement::calculateWorkingDayDuration: se vuelve a activar tarea, poniendo lastts a "<<lastts;
                }
                //si viene un final de tarea aun no habiendo tarea activada, entonces ni sumamos ni grabamos
                //lastts porque este último intervalo no se tiene que tener en cuenta, y el siguiente hasta el
                //comienzo de la sig tarea tampoco.
            }
        }
        tareaActiva = task != 0;
        lastEntryTime = entradaTiempo;
        --currIndex;
    }
    if (tareaActiva) {
        if (lastts.isNull()) { //no se ha sumado nada del día actual
            if (lastEntryTime.isValid() && lastEntryTime.time() > final && lastEntryTime.date() == current.date().addDays(-1)) {
                // si hay un registro del día anterior más allá del límite de final de jornada, entonces hay que contar este
                // tiempo aunque no se haya llegado al límite de comienzo de jornada
                lastts = QDateTime(Reloj::currentDate(), QTime(0, 0, 0, 0));
                qDebug() << "WorkingDayManagement::calculateWorkingDayDuration: último registro fuera de límite de jornada. contando desde las 00 horas: "<<lastts;
            } else if (current.time() > comienzo) {
                lastts = QDateTime(Reloj::currentDate(), comienzo);
                qDebug() << "WorkingDayManagement::calculateWorkingDayDuration: recalculamos el comienzo de la última tarea activa: "<<lastts;
            } else {
                qDebug() << "WorkingDayManagement::calculateWorkingDayDuration: No hemos pasado el comienzo de jornada; no se suma";
            }
            //si aún no hemos pasado la hora de comienzo de jornada, no hay que sumar
            //así que dejamos lastts como null. antes de sumar comprobaremos si es null.
        }
        if (!lastts.isNull()) {
            QDateTime finald = current;
            if (lastts.time() < final && current.time() > final) {
                finald.setTime(final);
                qDebug() << "WorkingDayManagement::calculateWorkingDayDuration: hemos pasado el final de jornada, recalculamos el final de la última tarea activa: "<<finald;
            }
            qint64 diff = lastts.msecsTo(finald);
            qDebug()<<"WorkingDayManagement::calculateWorkingDayDuration: última actividad "<<lastts<<" -- "<<finald<<" == "<<diff<<" "<<(QTime(0,0,0,0).addMSecs(diff));
            mseconds += diff;
            _lastWorkingDayDurationRefresh = finald;
        }
    }
    qDebug()<<"WorkingDayManagement::calculateWorkingDayDuration: duracion total jornada calculada: "<<mseconds<<" msecs; "<<(QTime(0,0,0,0).addMSecs(mseconds));
    setWorkingDayDuration(mseconds);
    return mseconds;
}

void WorkingDayManagement::adjustWorkingDayDurationWithNewTask(Task* newActiveTask)
{
    /*
     * Habiéndose producido un nuevo registro de tiempo, se calcula el intervalo desde el último
     * refresco producido en _lastWorkingDayDurationRefresh hasta el momento actual, y se actualiza.
     * como esto se llama por acción del usuario, no hay que tener en cuenta el comienzo
     * de jornada ni el final.
     *
     */
    //
    QDateTime now = Reloj::currentDateTime();
    if (_lastActiveTask) {
        //si había una activa, hay que tener en cuenta este último intervalo hasta ahora.
        // da igual si estamos activando otra tarea o desactivando la anterior.
        if (now.date() == _lastWorkingDayDurationRefresh.date()) {
            //si es del mismo día, sumamos el tiempo del último intervalo y punto.
            qint64 diff = _lastWorkingDayDurationRefresh.msecsTo(now);
            setWorkingDayDuration(_workingDayDuration + diff);
            qDebug() << "WorkingDayManagement::adjustWorkingDayDurationWithNewTask: cambio de tarea activa. sumamos el último "
                     << "intervalo " << _lastWorkingDayDurationRefresh << " -- " << now << " = " << diff << " msecs a jornada";
        } else {
            //si es un dia distinto, ya no hay que sumar. Ponemos como duración el tiempo
            // transcurrido hasta el momento actual en el día de hoy
            qint64 diff = QTime(0,0,0,0).msecsTo(now.time());
            setWorkingDayDuration(diff);
            qDebug() << "WorkingDayManagement::adjustWorkingDayDurationWithNewTask: cambio de tarea activa, y de día. "
                     << "Nueva jornada hasta " << now << " de " << diff << " msecs";
        }
        _lastWorkingDayDurationRefresh = now;
    } else {
        //si no había tarea activa, guardamos el momento para que los siguientes reajustes empiecen
        //a sumar desde este momento porque estamos activando una. No hay que sumar nada.
        if (now.date() != _lastWorkingDayDurationRefresh.date()) {
            //si hemos cambiado de fecha, lo que sí hay que hacer es poner a 0 el contador.
            qDebug() << "cambio en tarea activa, comenzando tarea. poniendo jornada a 0";
            setWorkingDayDuration(0);
        }
        if (newActiveTask) {
            // una última comprobación de seguridad. si no había tarea activa es imposible llegar aquí
            // desactivando tarea. pero por si acaso... solo guardamos el momento cuando realmente
            // activamos una nueva tarea.
            _lastWorkingDayDurationRefresh = now;
        }
    }
    qDebug() << "WorkingDayManagement::adjustWorkingDayDurationWithNewTask: nueva jornada " << _workingDayDuration
             << " msecs, " << (QTime(0,0,0,0).addMSecs(_workingDayDuration));
}

void WorkingDayManagement::adjustWorkingDayDuration()
{
    /*
     * Se procesa el último intervalo de tiempo pasado desde _lastWorkingDayDurationRefresh, sin que
     * haya ocurrido ningún nuevo registro.
     * Hay que tener en cuenta los límites de jornada configurados en settings, porque no ha habido
     * acción de usuario (esta actualización se activa con el reloj).
     */
    QDateTime current = Reloj::currentDateTime();
    qDebug()<<"WorkingDayManagement::adjustWorkingDayDuration: current "<<current<<", ultimo "<<_lastWorkingDayDurationRefresh;
    if (_lastActiveTask) {
        // habia una tarea activa (y sigue estando activa)
        QTime comienzoJornada = _settings->comienzoJornada();
        QTime finalJornada = _settings->finalJornada();
        if (_lastWorkingDayDurationRefresh.isNull()) {
            //si es null, es que no hemos sumado nada hoy, hay que comprobar el comienzo de jornada
            if (current.time() > comienzoJornada) {
                //si ya hemos pasado el comienzo, hay que sumar el trocito
                QDateTime base = QDateTime(current.date(), comienzoJornada);
                qint64 diff = base.msecsTo(current);
                qDebug()<<"WorkingDayManagement::adjustWorkingDayDuration: hemos pasado el comienzo de jornada con "
                        <<"tarea activa, empezamos a contar "<<diff<<" msecs";
                setWorkingDayDuration(_workingDayDuration + diff);
                _lastWorkingDayDurationRefresh = current;
            }
            //si no hemos pasado el comienzo, seguimos sin sumar, y todo queda igual
        } else {//si no es null, eso es que ya hemos sumado hasta ese momento.
            if (current.date() == _lastWorkingDayDurationRefresh.date()) {
                //si es el mismo dia, no hay que tener en cuenta el comienzo de jornada:
                //o bien ya lo hemos saltado, o no y hemos contado parte de él o todo ya.
                //lo que sí hay que vigilar es el paso del final de jornada:
                if (_lastWorkingDayDurationRefresh.time() < finalJornada) {
                    // si no hemos llegado al final de la jornada, hay que contar, como máximo,
                    //hasta el final de jornada
                    QDateTime intervaloEnd = current;
                    if (current.time() > finalJornada) {
                        // como hemos rebasado el final de jornada, ajustamos el final del intervalo
                        // a contar
                        intervaloEnd.setTime(finalJornada);
                        qDebug()<<"WorkingDayManagement::adjustWorkingDayDuration: pasamos ahora el final de jornada: solo contamos "
                                <<"hasta el final";
                    }
                    //y contamos, hasta el final de jornada o hasta el momento actual, lo que toque
                    qint64 diff = _lastWorkingDayDurationRefresh.msecsTo(intervaloEnd);
                    qDebug()<<"WorkingDayManagement::adjustWorkingDayDuration: sumamos "<<_lastWorkingDayDurationRefresh<<" -- "
                            <<intervaloEnd<<" == "<<diff<<" msecs";
                    setWorkingDayDuration(_workingDayDuration + diff);
                    _lastWorkingDayDurationRefresh = intervaloEnd;
                } else if (_lastWorkingDayDurationRefresh.time() > finalJornada) {
                    //si tenemos confirmado más allá del final de jornada, es que no hay que tenerlo en cuenta,
                    // y sumamos de manera normal.
                    qint64 diff = _lastWorkingDayDurationRefresh.msecsTo(current);
                    qDebug()<<"WorkingDayManagement::adjustWorkingDayDuration: el final de jornada ya estaba pasado; sumamos "
                            <<_lastWorkingDayDurationRefresh<<" -- "<<current<<" == "<<diff<<" msecs";
                    setWorkingDayDuration(_workingDayDuration + diff);
                    _lastWorkingDayDurationRefresh = current;
                }
                //lo que queda es si el último calculo es == finalJornada. Eso es que ya está contado hasta el
                //final de jornada y no hay que contar nada de nada, hasta que el usuario haga algo. No se trata.
            } else {
                //si habiendo tarea activa ha cambiado el dia, ya no suma, el valor cambia por completo
                qint64 nuevoValor = 0;
                if (current.time() > comienzoJornada) {
                    //si hemos superado el comienzo de jornada, sumamos desde él
                    if (current.time() > finalJornada) {
                        nuevoValor = comienzoJornada.msecsTo(finalJornada);
                        _lastWorkingDayDurationRefresh = QDateTime(current.date(), finalJornada);
                        qDebug()<<"WorkingDayManagement::adjustWorkingDayDuration: hemos cambiado de día con tarea activa, y "
                                <<"hemos pasado del comienzo y del final de jornada, contamos desde "<<comienzoJornada
                                <<" hasta "<<finalJornada<<" = "<<nuevoValor<<" msecs";
                    } else {
                        nuevoValor = comienzoJornada.msecsTo(current.time());
                        _lastWorkingDayDurationRefresh = current;
                        qDebug()<<"WorkingDayManagement::adjustWorkingDayDuration: hemos cambiado de día con tarea activa, y "
                                <<"hemos pasado del comienzo de jornada pero no del final, contamos desde "<<comienzoJornada
                                <<" hasta ahora = "<<nuevoValor<<" msecs";
                    }
                } else {
                    _lastWorkingDayDurationRefresh = QDateTime();
                    qDebug()<<"WorkingDayManagement::adjustWorkingDayDuration: hemos cambiado de dia con una tarea activa, pero "
                            <<"no se ha llegado al comienzo de jornada, no sumamos";
                }
                setWorkingDayDuration(nuevoValor);
            }
        }
    } else {
        //si no hay tarea activa no hay que sumar nada.
        //si cambiamos de día, se pone a 0.
        if (current.date() != _lastWorkingDayDurationRefresh.date()) {
            qDebug() << "WorkingDayManagement::adjustWorkingDayDuration: no hay activa, y hemos cambiado de dia; poniendo jornada a 0";
            setWorkingDayDuration(0);
            _lastWorkingDayDurationRefresh = QDateTime();
        }
    }
}
