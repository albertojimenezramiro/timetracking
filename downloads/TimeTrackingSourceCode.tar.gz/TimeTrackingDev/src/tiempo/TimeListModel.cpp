/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 19 jan. 2019
**
****************************************************************************/

#include "TimeListModel.h"
#include <QSqlTableModel>
#include "TimeEntry.h"
#include <QDebug>
#include <QSqlError>
#include <QSqlRecord>
#include "TTSettings.h"
#include "Reloj.h"
#include "Funciones.h"
#include "TimeStore.h"
#include <QList>
#include "../tareas/Task.h"
#include "../tareas/TaskStore.h"

TimeListModel::TimeListModel(QObject *parent, TimeStore *timeStore, TaskStore *taskStore, TTSettings *settings) :
    QAbstractListModel(parent),
    _timeStore(timeStore),
    _taskStore(taskStore),
    _databaseModel(nullptr),
    _settings(settings)
{
}

TimeListModel::~TimeListModel()
{
    if (_databaseModel) {
        _databaseModel->clear();
        _databaseModel->deleteLater();
    }
}

void TimeListModel::initialize()
{
    _databaseModel = new QSqlTableModel();
}

int TimeListModel::rowCount(const QModelIndex &) const
{
    return _entryList.size();
}

QVariant TimeListModel::data(const QModelIndex &modelIndex, int role) const
{
    int nrow = modelIndex.row();
    TimeEntry* timeEntry = (nrow <= _entryList.size()) ? _entryList.at(nrow) : nullptr;
    if (timeEntry) {
        if (role == TIMEROLE_ID) {
            return QVariant::fromValue(timeEntry->id());
        } else if (role == TIMEROLE_TASKID) {
            return QVariant::fromValue(timeEntry->taskId());
        } else if (role == TIMEROLE_TASKNAME) {
            int taskId = timeEntry->taskId();
            Task *task = taskId > 0 ? _taskStore->task(taskId, true) : nullptr;
            QString name = task ? task->name() : "";
            return QVariant::fromValue(name);
        } else if (role == TIMEROLE_DATESECTION) {
            QDateTime date = timeEntry->time();
            QString t = date.toString("dd/MM/yyyy");
            return QVariant::fromValue(t);
        } else if (role == TIMEROLE_DATETIME) {
            return QVariant::fromValue(timeEntry->time());
        }
    }
    return QVariant();
}

QHash<int, QByteArray> TimeListModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[TIMEROLE_TASKID] = "taskId";
        roles[TIMEROLE_TASKNAME] = "taskName";
        roles[TIMEROLE_DATETIME] = "datetime";
        roles[TIMEROLE_DATESECTION] = "day";
        roles[TIMEROLE_ID] = "entryId";
    }
    return roles;
}

bool TimeListModel::canFetchMore(const QModelIndex &) const
{
    bool can = false;
    if (_entryList.size() < _databaseModel->rowCount()) {
        can = true;
    } else {
        if (_entryList.size() == _databaseModel->rowCount()) {
            can = _databaseModel->canFetchMore();
        } else {
            qCritical() << "Error: los modelos no están alineados";
        }
    }
    qDebug() << "TimeListModel::canFetchMore " << can;
    return can;
}

void TimeListModel::fetchMore(const QModelIndex &)
{
    TimeEntry *lastInModel = _entryList.last();
    qDebug() << "TimeListModel::fetchMore: " << _entryList.size() << " entradas actuales, la última en " << lastInModel->time();
    QList<TimeEntry*> tmp = _timeStore->loadPreviousTo(lastInModel, 50);
    qDebug() << "TimeListModel::fetchMore: cargados " << tmp.size() << " elementos más desde el Store";
    if (!tmp.isEmpty()) {
        beginInsertRows(QModelIndex(), _entryList.size(), _entryList.size() + tmp.size() - 1);
        _entryList += tmp;
        endInsertRows();
    }
    fetchDbModel();
}


//=======================================================================
//=======================================================================
//=======================================================================


void TimeListModel::loadModel()
{
    qDebug() << "TimeListModel::loadModel";
    QList<TimeEntry*> tmp = _timeStore->loadRecentEntries();
    beginResetModel();
    _entryList = tmp;
    qDebug() << "TimeListModel::loadModel: cargadas " << tmp.size() << " entradas del store";
    endResetModel();
    loadDbModel();
    fetchDbModel();
}

void TimeListModel::loadDbModel()
{
    _databaseModel->setTable("tiempo");
    _databaseModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _databaseModel->setSort(TimeStore::FIELD_TSTAMP, Qt::DescendingOrder);
    _databaseModel->select();
    qDebug() << "TimeListModel::loadDbModel: cargadas " << _databaseModel->rowCount() << " entradas";
}

void TimeListModel::fetchDbModel()
{
    while (_databaseModel->rowCount() < _entryList.size() && _databaseModel->canFetchMore()) {
        qDebug() << "TimeListModel::fetchDbModel: dbModel " << _databaseModel->rowCount()
                 << " rows, listaEntradas " << _entryList.size() << " entradas; fetcheando dbModel";
        _databaseModel->fetchMore();
    }
}

void TimeListModel::sortEditedEntry(qint64 entryId)
{
    TimeEntry *entry = _timeStore->timeEntry(entryId);
    bool ordenada = isSorted(entry);
    int indiceActual = _entryList.indexOf(entry);
    qDebug() << "TimeListModel::sortEditedEntry: entrada " << entryId
             << " está ordenada " << ordenada << ", indice actual " << indiceActual;
    if (ordenada) {
        // si no ha cambiado de index, basta con señalizar un dataChanged
        Q_EMIT(dataChanged(index(indiceActual, 0), index(indiceActual, 0)));
    } else {
        // si ha cambiado de índice, eliminamos y volvemos a insertar en la posición correcta
        beginRemoveRows(QModelIndex(), indiceActual, indiceActual);
        _entryList.removeAt(indiceActual);
        endRemoveRows();
        insertSorted(entry);
    }
}

bool TimeListModel::isSorted(TimeEntry* entry) const
{
    // compararemos con la muestra anterior y siguiente para saber si está ordenada
    bool sorted = true;
    int currentIndex = _entryList.indexOf(entry);
    if (currentIndex > 0) {
        sorted = entry->time() <= _entryList.at(currentIndex - 1)->time();
        qDebug() << "TimeListModel::isSorted: entrada anterior "
                << _entryList.at(currentIndex - 1)->time();
    }
    if (sorted && currentIndex < _entryList.size() - 1) {
        sorted = entry->time() >= _entryList.at(currentIndex + 1)->time();
        qDebug() << "TimeListModel::isSorted: entrada posterior "
                << _entryList.at(currentIndex + 1)->time();
    }
    return sorted;
}

void TimeListModel::insertSorted(TimeEntry *entry)
{
    if (_entryList.isEmpty()) {
        qDebug() << "TimeListModel::insertSorted: insertando entrada en lista vacía";
        beginInsertRows(QModelIndex(), 0, 0);
        _entryList << entry;
        endInsertRows();
        loadDbModel();
        fetchDbModel(); // para que que databaseModel quede actualizado con la realidad
    } else {
        //si queda fuera del rango actualmente cargado, no se inserta
        int nuevoIndice = searchIndexInDb(entry->id());
        qDebug() << "TimeListModel::insertSorted: nuevoIndice " << nuevoIndice;
        if (nuevoIndice < _databaseModel->rowCount()) {
            beginInsertRows(QModelIndex(), nuevoIndice, nuevoIndice);
            _entryList.insert(nuevoIndice, entry);
            endInsertRows();
        }
    }
}

int TimeListModel::searchIndexInDb(const qint64 id)
{
    loadDbModel();
    fetchDbModel();
    bool found = false;
    int index = 0;
    while (!found && index < _databaseModel->rowCount()) {
        qint64 currId = _databaseModel->data(_databaseModel->index(index, TimeStore::FIELD_ID)).toLongLong();
        if (currId == id) {
            found = true;
        } else {
            index++;
        }
    }
    return index;
}

void TimeListModel::insertNewEntry(const qint64 entryId)
{
    // las nuevas entradas siempre serán las más recientes en el tiempo e irán en la primera posición de la lista
    TimeEntry *newEntry = _timeStore->timeEntry(entryId);
    qDebug() << "TimeListModel::insertNewEntry: prepend de entrada "
             << entryId << " " << newEntry->time();
    // con los insert no funciona. Cuando se hace el insert estando la lista scrollada abajo mucho,
    // al subir de nuevo aparecen dos secciones repetidas
    beginInsertRows(QModelIndex(), 0, 0);
    //beginResetModel();
    _entryList.prepend(newEntry);
    endInsertRows();
    //Q_EMIT(dataChanged(index(0, 0), index(0, 0)));
    loadDbModel();
    fetchDbModel();
    //endResetModel();
}

