/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 9 oct 2023
**
****************************************************************************/

#include "TimeViewModel.h"
#include <QDebug>
#include <qqml.h>
#include "TTSettings.h"
#include "TimeListModel.h"
#include "../tareas/TaskStore.h"
#include "TimeEntry.h"
#include "Reloj.h"
#include "../tareas/Task.h"
#include "WorkingDayManagement.h"

TimeViewModel::TimeViewModel(QObject* parent, TimeStore *timeStore, TaskStore *taskStore, TTSettings *settings) :
    QObject(parent),
    _timeStore(timeStore),
    _taskStore(taskStore),
    _editorIsDirty(false),
    _settings(settings),
    _timeEntry(nullptr)
{
    qDebug() << "TimeListModel::TimeListModel";
    qmlRegisterUncreatableType<TimeListModel>("TimeTracking.models", 1, 0, "TimeListModel", "No se puede crear un TimeListModel");
    connect(_timeStore, &TimeStore::timeNotification, this, &TimeViewModel::slotNotifications, Qt::QueuedConnection);
    _listModel = new TimeListModel(this, timeStore, taskStore, _settings);
    _workingDayManagement = new WorkingDayManagement(this, timeStore, taskStore, settings);
    connect(_workingDayManagement, &WorkingDayManagement::workingDayDurationChanged, this, &TimeViewModel::workingDayDurationChanged);
}

TimeViewModel::~TimeViewModel()
{
}

void TimeViewModel::initialize()
{
    _listModel->initialize();
    _listModel->loadModel();
    _workingDayManagement->initialize();
}


TimeListModel *TimeViewModel::listModel() const
{
    return _listModel;
}

QDateTime TimeViewModel::entryTime() const
{
    return _timeEntry ? _timeEntry->time() : QDateTime();
}
QDateTime TimeViewModel::timeEdited() const
{
    return _timeEdited;
}
void TimeViewModel::setTimeEdited(QDateTime datetime)
{
    if (_timeEdited != datetime) {
        qDebug() << "TimeViewModel::setTimeEdited: "<<datetime;
        _timeEdited = datetime;
        Q_EMIT(timeEditedChanged());
        calculateError();
    }
}

QString TimeViewModel::errorStr() const
{
    return _errorStr;
}

void TimeViewModel::setErrorStr(const QString &error)
{
    if (_errorStr != error) {
        _errorStr = error;
        Q_EMIT(errorStrChanged());
    }
}

///////////////////////
///                 ///
/// BUSINESS-LOGIC  ///
///                 ///
///////////////////////

void TimeViewModel::loadTimeEntry(qint64 id)
{
    _timeEntry = _timeStore->timeEntry(id);
    qDebug() << "TimeViewModel::loadTimeEntry: entry " << id << ", "<<_timeEntry;
    Q_EMIT(entryTimeChanged());
    setTimeEdited(_timeEntry->time());
    setErrorStr("");
}

void TimeViewModel::saveChanges()
{
    // guardamos si el nuevo tiempo es válido y distinto
    if (_timeEdited.isValid() && _timeEdited != _timeEntry->time()) {
        _timeStore->editEntry(_timeEntry->id(), _timeEdited);
    }
}

void TimeViewModel::slotNotifications(TimeStore::TimeNotifications notification, qint64 entryId)
{
    switch (notification) {
        case TimeStore::TIMENOTIF_NEWENTRY: {
            qDebug() << "TimeViewModel::slotNotifications: nuevo registro de tiempo";
            _listModel->insertNewEntry(entryId);
            Q_EMIT(isActiveTaskChanged());
            break;
        }
        case TimeStore::TIMENOTIF_UPDATEDATA:{
            qDebug() << "TimeViewModel::slotNotifications: notification updatedata.";
            _listModel->sortEditedEntry(entryId);
            Q_EMIT(isActiveTaskChanged());
            break;
        }
        default:
            break;
    }
}

void TimeViewModel::calculateError()
{
    QDateTime now = Reloj::currentDateTime();
    if (_timeEdited > now) {
        setErrorStr(tr("Has seleccionado una fecha y hora del futuro"));
    } else {
        setErrorStr("");
    }
}

void TimeViewModel::restartTimeEdited()
{
    setTimeEdited(_timeEntry->time());
    setErrorStr("");
}

void TimeViewModel::createNewEntry(int taskId)
{
    int taskIdToApply = -1;
    Task *task = _taskStore->task(taskId, false);
    if (task) {
        if (!task->isActive()) {
            taskIdToApply = task->id();
        }
        _timeStore->createEntry(taskIdToApply);
    }

}

QDateTime TimeViewModel::workingDayDuration() const
{
    return _workingDayManagement->workingDayDuration();
}

bool TimeViewModel::isActiveTask() const
{
    Task *at = _timeStore->mostRecentEntry() ? _timeStore->mostRecentEntry()->task() : nullptr;
    return (at != nullptr);
}
