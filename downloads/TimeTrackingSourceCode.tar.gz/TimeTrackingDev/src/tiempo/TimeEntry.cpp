/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 12 oct. 2018
**
****************************************************************************/

#include "TimeEntry.h"
#include <QDebug>
#include "../tareas/Task.h"

TimeEntry::TimeEntry() :
    _id(0),
    _taskId(0),
    _task(nullptr)
{
}

TimeEntry::TimeEntry(qint64 id, int taskId, const QDateTime &time) :
    _id(id),
    _taskId(taskId),
    _time(time),
    _task(nullptr)
{
}

TimeEntry::~TimeEntry()
{
    //qDebug()<<"destruyendo entrada tiempo " << this;
}

QDateTime TimeEntry::time() const
{
    return _time;
}

qint64 TimeEntry::id() const
{
    return _id;
}

int TimeEntry::taskId() const
{
    return _taskId;
}

Task *TimeEntry::task() const
{
    return _task;
}

void TimeEntry::setTime(const QDateTime &value)
{
    _time = value;
}

void TimeEntry::setTaskId(int id)
{
    _taskId = id;
}

void TimeEntry::setTask(Task *task)
{
    _task = task;
}
