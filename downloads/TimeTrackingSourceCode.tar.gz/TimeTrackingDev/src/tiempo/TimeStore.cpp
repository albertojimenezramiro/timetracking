/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 19 jan. 2019
**
****************************************************************************/

#include "TimeStore.h"
#include "TimeEntry.h"
#include <QSqlTableModel>
//#include <QLinkedList>
#include "Reloj.h"
#include <QSqlRecord>
#include <QSqlError>
#include "../tareas/TaskStore.h"
#include <QDebug>

TimeStore::TimeStore(QObject* parent, TaskStore *taskStore) :
    QObject(parent),
    _timeDbModel(nullptr),
    _mostRecentEntry(nullptr),
    _taskStore(taskStore)
{

}

TimeStore::~TimeStore()
{
    if (_timeDbModel) {
        _timeDbModel->clear();
        _timeDbModel->deleteLater();
    }
}

void TimeStore::initialize()
{
    _timeDbModel = new QSqlTableModel(this);
    _timeDbModel->setTable("tiempo");
}

QList<TimeEntry*> TimeStore::loadRecentEntries()
{
    QList<TimeEntry*> list;
    // cargaremos las 50 entradas más recientes
    _timeDbModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _timeDbModel->setSort(FIELD_TSTAMP, Qt::DescendingOrder);
    _timeDbModel->select();
    if (_timeDbModel->rowCount() > 0) {
        int last = _timeDbModel->rowCount() < 50 ? _timeDbModel->rowCount() - 1 : 49;
        list += parseDbModel(0, last);
        _mostRecentEntry = list.first();
    }
    return list;
}

QList<TimeEntry*> TimeStore::loadTimeRange(const QDateTime &begin, const QDateTime &end)
{
    qDebug() << "TimeStore::loadTimeRange: " << begin << " - " << end;
    // cargaremos todas las entradas en el rango dado con los bordes incluidos. También cargaremos la anterior y la siguiente al rango.
    QList<TimeEntry*> list;
    qint64 beginTs = begin.toMSecsSinceEpoch(),
           endTs = end.toMSecsSinceEpoch();
    _timeDbModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _timeDbModel->setSort(FIELD_TSTAMP, Qt::DescendingOrder);
    _timeDbModel->setFilter("timestamp < "+QString::number(beginTs));
    _timeDbModel->select();
    qDebug() << "TiempoStore::loadTimeRange: " << _timeDbModel->rowCount() << " elementos previos";
    // nos quedamos con una anterior
    if (_timeDbModel->rowCount() > 0) {
        list += parseDbModel(0, 0);
    }

    _timeDbModel->setSort(FIELD_TSTAMP, Qt::AscendingOrder);
    _timeDbModel->setFilter("timestamp >= "+QString::number(beginTs)+" AND timestamp < "+QString::number(endTs));
    _timeDbModel->select();
    while (_timeDbModel->canFetchMore()) {
        _timeDbModel->fetchMore();
    }
    // cargamos todas las del rango dado
    qDebug() << "TiempoStore::loadTimeRange: " << _timeDbModel->rowCount() << " elementos en rango";
    if (_timeDbModel->rowCount() > 0) {
        list += parseDbModel(0, _timeDbModel->rowCount() - 1);
    }

    _timeDbModel->setFilter("timestamp >= "+QString::number(endTs));
    _timeDbModel->select();
    // y cargamos también una posterior
    qDebug() << "TiempoStore::loadTimeRange: " << _timeDbModel->rowCount() << " elementos posteriores";
    if (_timeDbModel->rowCount() > 0) {
        list += parseDbModel(0, 0);
    }
    return list;
}

QList<TimeEntry*> TimeStore::loadPreviousTo(const TimeEntry *entry, const int numEntries)
{
    qDebug() << "TimeStore::loadPreviousTo: anteriores a " << entry->time();
    QList<TimeEntry*> lista;
    _timeDbModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _timeDbModel->setSort(FIELD_TSTAMP, Qt::DescendingOrder);
    qint64 endTs = entry->time().toMSecsSinceEpoch();

    //se carga todo el rango pedido
    _timeDbModel->setFilter("timestamp <= "+QString::number(endTs));
    _timeDbModel->select();
    if (_timeDbModel->rowCount() > 0) {
        // las primeras podrían tener todas la fecha igual, así que hay que mirar
        // las realmente anteriores a la entrada dada, para no meter duplicados
        int first = 0, ind = 0;
        bool duplicadosFiltrados = false;
        while (!duplicadosFiltrados && first < _timeDbModel->rowCount()) {
            qint64 id = _timeDbModel->data(_timeDbModel->index(ind, FIELD_ID, QModelIndex())).toLongLong();
            qint64 ts = _timeDbModel->data(_timeDbModel->index(ind, FIELD_TSTAMP, QModelIndex())).toLongLong();
            QDateTime time = QDateTime::fromMSecsSinceEpoch(ts);
            if (time > entry->time()) {
                duplicadosFiltrados = true;
                // si la fecha es distinta, ya es seguro que es anterior a la muestra dada.
            } else {
                if (id == entry->id()) {
                    duplicadosFiltrados = true;
                    first = ind + 1;
                    //parsear a partir del siguiente.
                }
            }
            ++ind;
        }
        lista += parseDbModel(first, numEntries);
    }
    return lista;
}

QList<TimeEntry*> TimeStore::loadEntriesForDate(const QDate &date)
{
    qDebug() << "TimeStore::loadEntriesForDate: "<<date;
    QList<TimeEntry*> list;
    _timeDbModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _timeDbModel->setSort(FIELD_TSTAMP, Qt::DescendingOrder);
    QDateTime dt(date.addDays(1), QTime(0, 0, 0, 0));
    _timeDbModel->setFilter("timestamp <= " + QString::number(dt.toMSecsSinceEpoch()));
    _timeDbModel->select();
    bool parsed = _timeDbModel->rowCount() == 0;
    bool found = false;
    int lastFetched = -1;
    while(!parsed && !found) {
        int nuevolast = _timeDbModel->rowCount() - 1;
        list += parseDbModel(lastFetched + 1, nuevolast);
        lastFetched = nuevolast;
        parsed = !_timeDbModel->canFetchMore();
        if (!parsed) {
            _timeDbModel->fetchMore();
        }
        found = list.last()->time().date() < date;
    }
    qDebug() << "TimeStore::loadEntriesForDate: cargadas" << list.size() << " entradas";
    if (!list.isEmpty()) {
        qDebug() << "TimeStore::loadEntriesForDate: rango " << list.first()->time() << " - " << list.last()->time();
    }
    return list;
}

QList<TimeEntry*> TimeStore::parseDbModel(const int first, const int last)
{
    QList<TimeEntry*> list;
    qDebug() << "TimeStore::parseDbModel: parseando indices " << first << " - " << last;
    for (auto ind = first; ind <= last; ind++) {
        qint64 id = _timeDbModel->data(_timeDbModel->index(ind, FIELD_ID, QModelIndex())).toLongLong();
        int idTarea = _timeDbModel->data(_timeDbModel->index(ind, FIELD_TASKID, QModelIndex())).toInt();
        qint64 ts = _timeDbModel->data(_timeDbModel->index(ind, FIELD_TSTAMP, QModelIndex())).toLongLong();
        TimeEntry *entry = nullptr;
        if (_entriesById.contains(id)) {
            entry = _entriesById.value(id);
        } else {
            entry = timeEntryFactoryMethod(id, idTarea, QDateTime::fromMSecsSinceEpoch(ts));
            _entriesById[id] = entry;

        }
        list << entry;
    }
    return list;
}

void TimeStore::editEntry(const qint64 entryId, const QDateTime &newTime)
{
    _timeDbModel->setFilter("id = "+QString::number(entryId));
    _timeDbModel->select();
    TimeEntry *entry = _entriesById.value(entryId);
    qDebug() << "TimeStore::editEntry: entrada " << entryId
             << " cambia de " << entry->time() << " a " << newTime;

    QModelIndex index = _timeDbModel->index(0, FIELD_TSTAMP);
    _timeDbModel->setData(index, newTime.toMSecsSinceEpoch(), Qt::EditRole);
    if (_timeDbModel->submitAll()) {
        entry->setTime(newTime);
    }
    //ahora hay que comprobar si la entrada más reciente ha cambiado
    _timeDbModel->setSort(FIELD_TSTAMP, Qt::DescendingOrder);
    _timeDbModel->setFilter("");
    _timeDbModel->select();
    qint64 mostRecentId = _timeDbModel->data(_timeDbModel->index(0, FIELD_ID)).toLongLong();
    if (mostRecentId != _mostRecentEntry->id()) {
        _mostRecentEntry = _entriesById.value(mostRecentId, nullptr);
    }
    Q_EMIT(timeNotification(TIMENOTIF_UPDATEDATA, entryId));
}

TimeEntry* TimeStore::timeEntry(const qint64 idEntrada) const
{
    return _entriesById.value(idEntrada, nullptr);
}

void TimeStore::createEntry(int taskId)
{
    QSqlRecord newEntryRecord = _timeDbModel->record();
    qint64 tsint = Reloj::currentDateTime().toMSecsSinceEpoch();
    QVariant id(taskId),
             ts(tsint);
    newEntryRecord.setValue(FIELD_TASKID, id);
    newEntryRecord.setValue(FIELD_TSTAMP, ts);
    _timeDbModel->insertRecord(-1, newEntryRecord);
    bool b = _timeDbModel->submitAll();
    qDebug()<<"TimeStore::createEntry: "<<newEntryRecord<<", b "<<b<<" "<<_timeDbModel->lastError();
    _timeDbModel->setFilter("timestamp = "+QString::number(tsint));
    _timeDbModel->select();
    qint64 idint = _timeDbModel->data(_timeDbModel->index(0, FIELD_ID, QModelIndex())).toLongLong();
    TimeEntry *newEntry = timeEntryFactoryMethod(idint, taskId, QDateTime::fromMSecsSinceEpoch(tsint));
    _entriesById[idint] = newEntry;
    qDebug() << "TimeStore::createEntry: nueva entrada " << idint << " para tarea "
             << taskId << " con tiempo " << newEntry->time();
    _mostRecentEntry = newEntry; // la nueva entrada creada siempre será la más reciente
    Q_EMIT(timeNotification(TIMENOTIF_NEWENTRY, newEntry->id()));
}

TimeEntry* TimeStore::timeEntryFactoryMethod(qint64 idEntrada, qint64 idTarea, const QDateTime &tiempo)
{
    TimeEntry *ent = new TimeEntry(idEntrada, idTarea, tiempo);
    if (idTarea > 0) {
        Task *task = _taskStore->task(idTarea, true);
        ent->setTask(task);
    }
    return ent;
}

TimeEntry *TimeStore::mostRecentEntry() const
{
    return _mostRecentEntry;
}

