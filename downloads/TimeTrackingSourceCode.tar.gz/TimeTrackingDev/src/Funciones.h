/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 19 ene. 2019
**
****************************************************************************/

#ifndef SRC_FUNCIONES_H_
#define SRC_FUNCIONES_H_

#include <QDateTime>

QDateTime calcularPrimerDiaSemana(const QDateTime& ref, const int firstDayOfWeek,
        const int lastDayOfWeek, int& numDiasLaborales);

qreal roundTo(qreal number, int decimals);

QDateTime firstDayOfMonth(const QDateTime &ref);

QString toSexagesimal(qint64 msecs, bool useSecs);

#endif /* SRC_FUNCIONES_H_ */
