/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 6 dic 2023
**
****************************************************************************/

#ifndef FEATURES_H_
#define FEATURES_H_

#include <qobject.h>
#include <QDateTime>
#include "Reloj.h"


class Features: public QObject {
    Q_OBJECT

    Q_PROPERTY(bool jiraIntegration READ jiraIntegration CONSTANT)
    Q_PROPERTY(bool timesheetJiraIntegration READ timesheetJiraIntegration CONSTANT)

public:
    Features(QObject * parent);
    virtual ~Features();

    void initialize();

    bool jiraIntegration() const;
    bool timesheetJiraIntegration() const;
};

#endif /* FEATURES_H_ */
