/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 9 oct. 2018
**
****************************************************************************/

#include "Contexto.h"
#include <QDebug>
#include <QDateTime>
#include <QGuiApplication>
#include "TTSettings.h"
#include "Reloj.h"
#include <QFont>
#include <QFontMetricsF>
#include <QNetworkAccessManager>
#include <qqml.h>
#include <QLibraryInfo>
#include "workorders/WorkOrdersViewModel.h"
#include "tareas/TasksViewModel.h"
#include "tareas/TaskStore.h"
#include "tiempo/TimeViewModel.h"
#include "tiempo/TimeStore.h"
#include "reportes/ReportViewModel.h"
#include "projects/ProjectsViewModel.h"
#include "clockingIn/ClockingInViewModel.h"
#include <QFileInfo>

Contexto::Contexto() {
    qRegisterMetaType<TTSettings*>();
    debugInfo();
    _settings = new TTSettings();

    _workOrderStore = new WorkOrderStore(this);
    _workOrdersViewModel = new WorkOrdersViewModel(this, _workOrderStore, _settings);
    _projectStore = new ProjectStore(this);
    _taskStore = new TaskStore(this, _workOrderStore, _projectStore);
    _tasksViewModel = new TasksViewModel(this, _taskStore, _settings, _workOrderStore, _projectStore);
    _timeStore = new TimeStore(this, _taskStore);
    _timeViewModel = new TimeViewModel(this, _timeStore, _taskStore, _settings);
    _tasksViewModel->setTimeStore(_timeStore);
    _reportViewModel = new ReportViewModel(this, _settings, _timeStore, _taskStore, _projectStore, _workOrderStore);
    _networkManager = new QNetworkAccessManager(this);
    _splash = true;
    _projectsViewModel = new ProjectsViewModel(this, _projectStore, _settings);
    _clockingInViewModel = new ClockingInViewModel(this, _timeStore, _settings);

}

Contexto::~Contexto() {
}

void Contexto::initialize()
{
    qDebug() << "Contexto::initialize: inicializando todo";
    _workOrderStore->initialize();
    _workOrdersViewModel->initialize();
    _projectStore->initialize();
    _taskStore->initialize();
    _tasksViewModel->initialize();
    _timeStore->initialize();
    _timeViewModel->initialize();
    _tasksViewModel->evaluateActiveTask();
    _reportViewModel->initialize();
    _projectsViewModel->initialize();
    _clockingInViewModel->initialize();

    qDebug() << "Contexto::initialize: fin";
}

void Contexto::debugInfo() const
{
    qDebug() << "*** PATHS ***";
    qDebug() << "AppDirPath " << QCoreApplication::applicationDirPath();
    qDebug() << "isDebug " << QLibraryInfo::isDebugBuild();
    qDebug() << "Prefix " << QLibraryInfo::location(QLibraryInfo::PrefixPath);
    qDebug() << "Doc " << QLibraryInfo::location(QLibraryInfo::DocumentationPath);
    qDebug() << "Headers " << QLibraryInfo::location(QLibraryInfo::HeadersPath);
    qDebug() << "Libraries " << QLibraryInfo::location(QLibraryInfo::LibrariesPath);
    qDebug() << "Lib exes " << QLibraryInfo::location(QLibraryInfo::LibraryExecutablesPath);
    qDebug() << "Binaries " << QLibraryInfo::location(QLibraryInfo::BinariesPath);
    qDebug() << "Plugins " << QLibraryInfo::location(QLibraryInfo::PluginsPath);
    qDebug() << "Imports " << QLibraryInfo::location(QLibraryInfo::ImportsPath);
    qDebug() << "Imports2 " << QLibraryInfo::location(QLibraryInfo::Qml2ImportsPath);
    qDebug() << "ArchData " << QLibraryInfo::location(QLibraryInfo::ArchDataPath);
    qDebug() << "Data " << QLibraryInfo::location(QLibraryInfo::DataPath);
    qDebug() << "Translations " << QLibraryInfo::location(QLibraryInfo::TranslationsPath);
    qDebug() << "Examples " << QLibraryInfo::location(QLibraryInfo::ExamplesPath);
    qDebug() << "Tests " << QLibraryInfo::location(QLibraryInfo::TestsPath);
    qDebug() << "Settings " << QLibraryInfo::location(QLibraryInfo::SettingsPath);
    qDebug() << "";
}



QString Contexto::version() const
{
    qint64 v = VERSION;
    QString versionStr = QString::number(v).insert(8, "-");
#ifdef FLAVOUR_MIRADA
    versionStr = "mirada."+versionStr;
#endif
    return versionStr;
}

TTSettings* Contexto::settings() const
{
    return _settings;
}

Reloj* Contexto::reloj()
{
    return Reloj::instance();
}

qreal Contexto::textWidth(const QString &text, const QFont &font) const
{
    QFontMetricsF metricas(font);
    qreal w = metricas.width(text);
    return w;
}

qreal Contexto::textHeight(const QFont &font) const
{
    QFontMetricsF metricas(font);
    qreal h = metricas.height() + metricas.descent(); //descent es extra, porque ya se tiene en cuenta en height
    return h;
}

bool Contexto::fileExists(QString filePath) const
{
    return QFile::exists(filePath);
}

bool Contexto::isFile(const QString &filePath) const
{
    QFileInfo fi(filePath);
    bool isFile = fi.exists() && fi.isFile();
    return isFile;
}

WorkOrdersViewModel *Contexto::workOrdersViewModel() const
{
    return _workOrdersViewModel;
}

TasksViewModel *Contexto::tasksViewModel() const
{
    return _tasksViewModel;
}

TimeViewModel *Contexto::timeViewModel() const
{
    return _timeViewModel;
}

ReportViewModel *Contexto::reportViewModel() const
{
    return _reportViewModel;
}

QString Contexto::infoTextForSplash() const
{
    return _infoText;
}
void Contexto::setInfoTextForSplash(const QString &text)
{
    qDebug() << "Contexto::setInfoTextForSplash: "<<text;
    if (_infoText != text) {
        _infoText = text;
        Q_EMIT(infoTextForSplashChanged());
    }
}

bool Contexto::splash() const
{
    return _splash;
}

void Contexto::setSplash(bool b)
{
    if (_splash != b) {
        _splash = b;
        Q_EMIT(splashChanged());
    }
}

void Contexto::slotSplashLoaded()
{
    Q_EMIT(splashLoaded());
}

ProjectsViewModel *Contexto::projectsViewModel() const
{
    return _projectsViewModel;
}

ClockingInViewModel *Contexto::clockingInViewModel() const
{
    return _clockingInViewModel;
}

