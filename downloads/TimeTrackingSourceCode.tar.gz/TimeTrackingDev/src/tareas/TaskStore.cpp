/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 12 jan. 2019
**
****************************************************************************/

#include "TaskStore.h"
#include <QDebug>
#include <QSqlTableModel>
#include <QSqlRecord>
#include "Task.h"
#include "Reloj.h"
#include <QVariant>
#include "../workorders/WorkOrderStore.h"
#include "../workorders/WorkOrder.h"
#include "../projects/Project.h"
#include "../projects/ProjectStore.h"

const qint64 TaskStore::_defaultArchiveTimestamp = 9999999999999;

TaskStore::TaskStore(QObject* parent, WorkOrderStore *workOrderStore, ProjectStore *projectStore) :
    QObject(parent),
    _taskModelDb(nullptr),
     _workOrderStore(workOrderStore),
    _last(nullptr),
    _projectStore(projectStore)

{
    qRegisterMetaType<TaskStore::TaskNotifications>();
}

TaskStore::~TaskStore()
{
    if (_taskModelDb) {
        _taskModelDb->deleteLater();
    }
}

void TaskStore::initialize()
{
    _taskModelDb = new QSqlTableModel(this);
    _taskModelDb->setTable("tareas");
}

Task *TaskStore::taskFactoryMethod(int id, const QString &name, const QString &desc, const QString &code)
{
    Task *t = new Task(this, id, name, desc);
    t->setCode(code);
    return t;
}

Task *TaskStore::task(int id, bool loadFromDb)
{
    Task *t = _taskById.value(id, nullptr);
    if (loadFromDb && t == nullptr) {
        qDebug() << "TaskStore::task: haciendo select con id " << id;
        selectTask(id);
        t = cacheSelected();
    }
    return t;
}

Task *TaskStore::last() const
{
    return _last;
}

void TaskStore::selectTask(int id)
{
    _taskModelDb->setFilter("id = " + QString::number(id));
    _taskModelDb->select();
}

Task *TaskStore::cacheSelected()
{
    return cacheSelected(0);
}

Task *TaskStore::cacheSelected(int rowIndex)
{
    Task *t = nullptr;
    if (_taskModelDb->rowCount() > 0) {
        int id = sqlData(rowIndex, TASK_ID).toInt();
        QString name = sqlData(rowIndex, TASK_NAME).toString();
        QString desc = sqlData(rowIndex, TASK_DESCRIPTION).toString();
        QString cod = sqlData(rowIndex, TASK_CODE).toString();
        qlonglong llarchived = sqlData(rowIndex, TASK_ARCHIVEDATE).toLongLong();
        QDateTime archived = QDateTime::fromMSecsSinceEpoch(llarchived);
        t = taskFactoryMethod(id, name, desc, cod);
        t->setArchiveDate(archived);
        qDebug() << "TaskStore::cacheSelected: index " << rowIndex << ", tarea: "<< id << " " << name << " "
                << cod << " " << archived << " " << llarchived << " " << desc;
        _taskById.insert(id, t);
        loadTaskWorkOrders(t);
        loadTaskProject(t);
    } else {
        qCritical() << "TaskStore::cacheSelected: error al parsear. el modelo solo tiene "
                    << _taskModelDb->rowCount();
    }
    return t;
}

void TaskStore::loadTaskWorkOrders(Task *task)
{
    QSqlTableModel dbmodel;
    dbmodel.setTable("wos");
    dbmodel.setFilter("idtarea = " + QString::number(task->id()));
    dbmodel.select();
    int index = 0;
    qDebug() << "TaskStore::loadTaskWorkOrders: " << dbmodel.rowCount();
    while (index < dbmodel.rowCount()) {
        int idwo = dbmodel.data(dbmodel.index(index, 4, QModelIndex())).toInt();
        int percentage = dbmodel.data(dbmodel.index(index, 3, QModelIndex())).toInt();
        if (idwo > 0) {
            WorkOrder *wor = _workOrderStore->wo(idwo, true);
            qDebug() << "TaskStore::loadTaskWorkOrders: cargando wo "<<wor->code()<<" con porcentaje " <<percentage<<" en tarea "<<task->id() << " "<<task;
            task->addWorkOrder(wor, percentage);
        }
        index++;
    }
}

void TaskStore::loadTaskProject(Task *task)
{
    QSqlTableModel dbmodel;
    dbmodel.setTable("projecttask");
    dbmodel.setFilter("taskid = " + QString::number(task->id()));
    dbmodel.select();
    qDebug() << "TaskStore::loadTaskProject: " << dbmodel.rowCount();
    if (dbmodel.rowCount() > 0) {
        int projectId = dbmodel.data(dbmodel.index(0, 2, QModelIndex())).toInt();
        if (projectId > 0) {
            Project *p = _projectStore->project(projectId, true);
            qDebug() << "TaskStore::loadTaskProject: cargando proyecto " << p->code() <<" en tarea "<<task->id();
            task->setProject(p);
        } else {
            task->setProject(nullptr);
        }
    } else {
        task->setProject(nullptr);
    }
}

bool TaskStore::sameWOs(QMap<WorkOrder*, int> w1, QMap<WorkOrder*, int> w2) const
{
    // comprueba si los dos mapas tienen exactamente las mismas work orders con el mismo porcentaje
    // primero comprueba si todas las de w1 están en w2 con el mismo porcentaje. Si es así, se
    // comprueba si w2 no tiene alguna más.
    bool res = true;
    for (auto w : w1.keys()) {
        res &= (w2.value(w, -1) == w1.value(w));
    }
    res &= (w2.size() == w1.size());
    return res;
}

void TaskStore::saveTaskWorkOrders(Task *task, QMap<WorkOrder*, int> workOrders)
{
    if (task && !sameWOs(task->workOrderMap(), workOrders)) {
        qDebug() << "TaskStore::saveTaskWorkOrders: las work orders han cambiado; se guardan en db: "<<workOrders;
        QSqlTableModel dbmodel;
        dbmodel.setTable("wos");
        dbmodel.setFilter("idtarea = " + QString::number(task->id()));
        dbmodel.select();
        // primero borramos las de ahora
        for (int i = 0; i < dbmodel.rowCount(); i++) {
            dbmodel.removeRow(i, QModelIndex());
        }
        dbmodel.submitAll();
        // y guardamos las nuevas
        for (auto wo : workOrders.keys()) {
            int taskId = task->id();
            int perc = workOrders.value(wo);
            int woId = wo->id();
            QSqlRecord nuevaFila = dbmodel.record();
            nuevaFila.setValue(1, taskId);
            nuevaFila.setValue(4, woId);
            nuevaFila.setValue(3, perc);
            bool res = dbmodel.insertRecord(-1, nuevaFila);
            qDebug() << "TaskStore::saveTaskWorkOrders: " << task->name() << " -- "
                     << wo->code() << " " << perc << "% --- " << res;
        }
        dbmodel.submitAll();
        task->clearWorkOrders();
        loadTaskWorkOrders(task);
    }
}

void TaskStore::saveTaskProject(Task *task, int projectId)
{
    bool projectChanged = task && ((task->project() && task->project()->id() != projectId) || (task->project() == nullptr && projectId > 0));
    if (task && projectChanged) {
        qDebug() << "TaskStore::saveTaskProject: el proyecto ha cambiado; se guarda en db: " << projectId;
        QSqlTableModel dbmodel;
        dbmodel.setTable("projecttask");
        dbmodel.setFilter("taskId = " + QString::number(task->id()));
        dbmodel.select();
        // primero borramos
        for (int i = 0; i < dbmodel.rowCount(); i++) {
            dbmodel.removeRow(i, QModelIndex());
        }
        dbmodel.submitAll();
        // y guardamos el nuevo
        if (projectId > 0) {
            int taskId = task->id();
            QSqlRecord nuevaFila = dbmodel.record();
            nuevaFila.setValue(1, taskId);
            nuevaFila.setValue(2, projectId);
            bool res = dbmodel.insertRecord(-1, nuevaFila);
            qDebug() << "TaskStore::saveTaskProject: " << task->name() << " -- " << projectId << ": " << res;
            dbmodel.submitAll();
        }
        loadTaskProject(task);
    }
}

QVariant TaskStore::sqlData(int rowIndex, TaskStore::TaskFields column)
{
    QModelIndex ind = _taskModelDb->index(rowIndex, column, QModelIndex());
    return _taskModelDb->data(ind);
}

void TaskStore::createNewTaskFromData(const QString &name, const QString &code, qint64 creationTime, const QString &description, qint64 archiveTime)
{
    QSqlRecord newRecord = _taskModelDb->record();
    newRecord.setValue(TASK_NAME, name);
    newRecord.setValue(TASK_CODE, code);
    newRecord.setValue(TASK_CREATIONTIME, creationTime);
    newRecord.setValue(TASK_DESCRIPTION, description);
    newRecord.setValue(TASK_ARCHIVEDATE, QVariant(archiveTime));
    newRecord.setValue(TASK_REMOVED, QVariant(0));
    _taskModelDb->insertRecord(-1, newRecord);
    qDebug()<< "TaskStore::createNewTaskFromData: "<<newRecord;
    _taskModelDb->submitAll();
    // already created in db. Now, we select it and build into memory, with the correct id
    _taskModelDb->setFilter("creacion = " + QString::number(creationTime));
    _taskModelDb->select();
    _last = cacheSelected();
}

void TaskStore::createNewTask()
{
    qint64 creationTime = Reloj::instance()->currentTime().toMSecsSinceEpoch();
    int lastIndex = _taskById.isEmpty() ? 1 : (_taskById.keys().last() + 1);
    QString name = QString("Nueva tarea ") + QString::number(lastIndex);
    createNewTaskFromData(name, "", creationTime, "", _defaultArchiveTimestamp);
    Q_EMIT(taskNotification(TASKNOTIF_NEWTASK, _last->id()));
}

void TaskStore::importTask(const QString &name, const QString &code, const QString &description)
{
    qint64 creationTime = Reloj::instance()->currentTime().toMSecsSinceEpoch();
    createNewTaskFromData(name, code, creationTime, description, _defaultArchiveTimestamp);
    Q_EMIT(taskNotification(TASKNOTIF_IMPORTEDTASK, _last->id()));
}

void TaskStore::archiveTask(int id)
{
    // asignamos fecha de cierre, hacemos el select en el modelo de db y entonces cambiamos el
    // campo y hacemos submit
    Task *wtask = task(id, false);
    qDebug() << "WorkOrderStore::archiveWorkOrder: id " << id << ", task " << wtask;
    if (wtask) {
        QDateTime archiveDate = Reloj::currentDateTime();
        if (updateArchiveDateInDb(id, archiveDate)) {
            _last = wtask;
            wtask->setArchiveDate(archiveDate);
            Q_EMIT(taskNotification(TASKNOTIF_ARCHIVED, id));
        } else {
            qCritical() << "Error al actualizar el archiveDate de la tarea con id " << id;
        }
    }
}

void TaskStore::reopenTask(int id)
{
    // asignamos fecha de cierre, hacemos el select en el modelo de db y entonces cambiamos el
    // campo y hacemos submit
    Task *wtask = task(id, false);
    if (wtask) {
        QDateTime defaultArchiveDate = QDateTime::fromMSecsSinceEpoch(_defaultArchiveTimestamp);
        if (updateArchiveDateInDb(id, defaultArchiveDate)) {
            _last = wtask;
            wtask->setArchiveDate(defaultArchiveDate);
            Q_EMIT(taskNotification(TASKNOTIF_REOPEN, id));
        } else {
            qCritical() << "Error al actualizar el archiveDate de la tarea con id " << id;
        }
    }
}

bool TaskStore::updateArchiveDateInDb(int id, const QDateTime &archiveDate)
{
    selectTask(id);
    QVariant newField = QVariant::fromValue<qint64>(archiveDate.toMSecsSinceEpoch());
    qDebug() << "TaskStore::updateArchiveDateInDb: id " << id << ", db rowcount " << _taskModelDb->rowCount() << "; field " << newField << ", date " << archiveDate;
    QModelIndex index = _taskModelDb->index(0, TASK_ARCHIVEDATE);
    _taskModelDb->setData(index, newField, Qt::EditRole);
    return _taskModelDb->submitAll();
}

bool TaskStore::updateTaskDataInDb(int id, const QString &name, const QString &description, const QString &code, QMap<WorkOrder*, int> workOrders, int projectId)
{
    selectTask(id); //cargamos en el modelo de db la tarea a editar
    qDebug() << "TaskStore::updateWorkOrderDataInDb: name " << name << ", code " << code << ", desc " << description<<"; wos " << workOrders;
    _taskModelDb->setData(_taskModelDb->index(0, TASK_NAME), QVariant::fromValue(name), Qt::EditRole);
    //_woModelDb->setData(_woModelDb->index(0, WO_PARENT), QVariant::fromValue(parentId), Qt::EditRole);
    _taskModelDb->setData(_taskModelDb->index(0, TASK_DESCRIPTION), QVariant::fromValue(description), Qt::EditRole);
    _taskModelDb->setData(_taskModelDb->index(0, TASK_CODE), QVariant::fromValue(code), Qt::EditRole);
     bool res = _taskModelDb->submitAll(); // guardamos los nuevos datos
     if (res) {
         // si se han guardado bien, cargamos los nuevos datos en memoria y notificamos
         Task *t = task(id, true);
         t->setName(name);
         t->setDescription(description);
         t->setCode(code);
         _last = t;
         saveTaskWorkOrders(t, workOrders);
         saveTaskProject(t, projectId);
         Q_EMIT(taskNotification(TASKNOTIF_UPDATEDATA, id));
     }
    return res;
}

bool TaskStore::existsTaskWithCode(const QString &code)
{
    qint64 curr = Reloj::currentDateTime().toMSecsSinceEpoch();
    QSqlTableModel tmodel;
    tmodel.setTable("tareas");
    tmodel.setFilter("jiraId = '"+code+"' AND borrado = 0 AND cerrado > "+QString::number(curr));
    tmodel.select();
    return tmodel.rowCount() > 0;
}


