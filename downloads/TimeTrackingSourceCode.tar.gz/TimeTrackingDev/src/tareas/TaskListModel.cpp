/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 12 jan. 2019
**
****************************************************************************/

#include "TaskListModel.h"
#include <QSqlTableModel>
#include <QDebug>
#include <QSqlRecord>
#include <QSqlError>
#include "Task.h"
#include "Reloj.h"
#include <qalgorithms.h>
#include "../workorders/WorkOrder.h"
#include "projects/Project.h"

TaskListModel::TaskListModel(QObject *parent, TaskStore *store) :
    QAbstractListModel(parent),
    _databaseModel(nullptr),
    _store(store),
    _dbPageSize(50),
    _archiveThreshold(0),
    _includeArchived(false)
{
}

TaskListModel::~TaskListModel()
{
    _databaseModel->clear();
    _databaseModel->deleteLater();
}

void TaskListModel::initialize()
{
    _databaseModel = new QSqlTableModel();
}

int TaskListModel::rowCount(const QModelIndex &) const
{
    return _tasksByIndex.size();
}

QVariant TaskListModel::data(const QModelIndex &modelIndex, int role) const
{
    int nrow = modelIndex.row();
    Task *ta = _tasksByIndex.value(nrow, nullptr);
    if (ta) {
        if (role == WOID) {
            return QVariant::fromValue(ta->id());
        } else if (role == NAME) {
            return QVariant::fromValue(ta->name());
        } else if (role == CODE) {
            return QVariant::fromValue(ta->code());
        } else if (role == ARCHIVED) {
            int value = ta->isArchived() ? 1 : 0;
            return QVariant::fromValue(value);
        } else if (role == WOTEXT) {
            QList<WorkOrder*> l = ta->workOrderList();
            QStringList lstr;
            for (auto w : l) {
                QString code = w->code().trimmed().isEmpty() ? "<orden sin cód>" : w->code().trimmed();
                lstr.append(code);
            }
            return QVariant::fromValue(lstr.join(","));
        } else if (role == ACTIVE) {
            qDebug() << "TaskListModel::data: "<<nrow<<" "<<ta->isActive();
            return QVariant::fromValue(ta->isActive());
        } else {
            return QVariant();
        }
    }
    return QVariant();
}

QHash<int, QByteArray> TaskListModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[WOID] = "taskId";
        roles[NAME] = "name";
        roles[CODE] = "code";
        roles[ARCHIVED] = "isArchived";
        roles[WOTEXT] = "wotext";
        roles[ACTIVE] = "isActive";
    }
    return roles;
}

bool TaskListModel::canFetchMore(const QModelIndex &) const
{
    int numElems = _tasksByIndex.size();
    bool can = false;
    qDebug() << "TaskListModel::canFetchMore: numElems " << numElems
             << ", rowCount del modelo de db " << _databaseModel->rowCount();
    if (numElems < _databaseModel->rowCount()) {
        can = true;
    } else {
        if (numElems == _databaseModel->rowCount()) {
            can = _databaseModel->canFetchMore();
        } else {
            qCritical() << "El modelo de tareas no está alineado";
        }
    }
    qDebug() << "TaskListModel::canFetchMore: " << can << ", " << this;
    return can;
}

void TaskListModel::fetchMore(const QModelIndex &)
{
    int first = maxIndex() + 1;
    int last = first + (_dbPageSize-1);
    qDebug() << "TaskListModel::fetchMore: " << this << "; numElems "
             << first << ", rowCount db " << _databaseModel->rowCount();
    if (first < _databaseModel->rowCount()) {
        insertIntoListModel(first, last, true);
    } else {
        if (first == _databaseModel->rowCount()) {
            _databaseModel->fetchMore();
            insertIntoListModel(first, last, true);
        } else {
            qCritical() << "El modelo de tareas no está alineado";
        }
    }
    qDebug() << "TaskListModel::fetchMore: fetchMore terminado. fetcheados "
             << first << " -- " << last;
}

int TaskListModel::maxIndex() const
{
    int maxIndex = -1;
    QList<int> indexes = _tasksByIndex.keys();
    if (indexes.size() > 0) {
        qSort(indexes);
        maxIndex = indexes.last();
    }
    return maxIndex;
}

QVariant TaskListModel::sqlData(int i, TaskStore::TaskFields field)
{
    QModelIndex ind = _databaseModel->index(i, field, QModelIndex());
    return _databaseModel->data(ind);
}

void TaskListModel::sqlSelect()
{
    _databaseModel->setTable("tareas");
    _databaseModel->setSort(TaskStore::TASK_ARCHIVEDATE, Qt::DescendingOrder);
    QDateTime threshold = Reloj::currentDateTime();
    if (_includeArchived) {
        threshold = threshold.addDays(-_archiveThreshold);
    }
    qint64 llthreshold = threshold.toMSecsSinceEpoch();
    qDebug() << "TaskListModel::sqlSelect: threshold " << threshold << " " << llthreshold;
    _databaseModel->setFilter("cerrado > " + QString::number(llthreshold));
    _databaseModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _databaseModel->select();
}

void TaskListModel::shiftModelForInsertion(const int firstIndex, const int numElems)
{
    // todas las entradas de este modelo que ocupen los índices dados se desplazan hacia índices
    // superiores para que los índices dados puedan ser ocupados por nuevas entradas
    int woMaxIndex = maxIndex();
    qDebug() << "TaskListModel::shiftModelForInsertion: firstIndex " << firstIndex << ", numElems " << numElems << ", maxIndex " << woMaxIndex;
    if (woMaxIndex >= firstIndex) {
        for (int currIndex = woMaxIndex; currIndex >= firstIndex; currIndex--) {
            Task *currWo = _tasksByIndex.value(currIndex, nullptr);
            if (currWo) {
                qDebug() << "TaskListModel::shiftModelForInsertion: desplazando indice " << currIndex << " al indice " << (currIndex + numElems);
                _tasksByIndex[currIndex + numElems] = currWo;
                _tasksByIndex.remove(currIndex);
                _indexesById[currWo->id()] = currIndex + numElems;
            }

        }
    }
}

void TaskListModel::clearModel()
{
    beginResetModel();
    _indexesById.clear();
    _tasksByIndex.clear();
    _databaseModel->clear();
    endResetModel();
}

void TaskListModel::loadModel(bool includeArchived, int archiveThreshold)
{
    qDebug() << "TaskListModel::loadModel";
    clearModel();
    _archiveThreshold = archiveThreshold;
    _includeArchived = includeArchived;
    // cargamos el modelo de sql y metemos las primeras en este modelo
    qDebug() << "TaskListModel::loadModel: comenzando carga del modelo de tareas: includeArchived " << includeArchived << ", threshold " << archiveThreshold;
    sqlSelect();
    qDebug() << "cargado modelo DB de tareas. count " << _databaseModel->rowCount() << ", " << this;
    if (_databaseModel->rowCount() > 0) {
        insertIntoListModel(0, _dbPageSize-1, true);
    }
}

void TaskListModel::insertIntoListModel(int first, int last, bool signalInsertions)
{
    // como last nos quedamos con el más restrictivo entre el dado y el del modelo de sql
    int lastDef = last <= (_databaseModel->rowCount()-1) ? last : (_databaseModel->rowCount()-1);
    qDebug() << "WorkOrderListModel::insertIntoListModel: signalInsertions " << signalInsertions<<", beginInsertRows "
             << first << " " << lastDef;
    if (signalInsertions) {
        beginInsertRows(QModelIndex(), first, lastDef);
    }
    // si los indices están ocupados, los desplazamos
    int numHuecos = lastDef - first + 1;
    shiftModelForInsertion(first, numHuecos);
    // insertamos nuestros nuevos elementos, se los pedimos al store
    for (int i = first; i <= lastDef; i++) {
        int id = sqlData(i, TaskStore::TASK_ID).toInt();
        Task *ta = _store->task(id, true);
        qDebug() << "TaskListModel::insertIntoListModel: index "<<i<<", id "<<id<<", "<<ta;
        if (ta) {
            _tasksByIndex.insert(i, ta);
            _indexesById.insert(ta->id(), i);
        }
    }
    if (signalInsertions) {
        endInsertRows();
    }
}

void TaskListModel::removeFromListModel(int first, int last)
{
    int lastIndex = last;
    int maxIndexBefore = maxIndex();
    if (last  > maxIndexBefore) {
        lastIndex = maxIndexBefore;
    }
    // vamos a borrar el intervalo first - lastIndex. Todo lo que haya detrás de lastIndex nos lo
    // traemos a first en adelante. Los índices que sobren se tienen que quedar borrados.
    int newIndex = first;
    int oldIndex = lastIndex + 1;
    // true if there are items at [last+1,..) that must be moved
    bool forwardItemsToMove = true;
    qDebug() << "TaskListModel::removeFromListModel: first " << first << ", last " << lastIndex << ", maxIndexBefore "<<maxIndexBefore;
    beginRemoveRows(QModelIndex(), first, lastIndex);
    while (newIndex <= lastIndex || forwardItemsToMove) {
        if (oldIndex <= maxIndexBefore) {
            // existe algo en oldIndex, así que nos lo traemos a newIndex
            Task *ta = _tasksByIndex.value(oldIndex);
            qDebug() << "llevando tarea de id " << (ta?ta->id():-1) << " desde el oldIndex " << oldIndex << " hasta el newIndex " << newIndex;
            _tasksByIndex.insert(newIndex, ta);
            _tasksByIndex.remove(oldIndex);
            _indexesById.insert(ta->id(), newIndex);
        } else {
            // no hay nada en oldIndex, así que dejamos borrado newIndex
            Task *ta = _tasksByIndex.value(newIndex);
            qDebug() << "no hay nada en oldIndex "<< oldIndex << ". Borrando tarea " << (ta?ta->id():-1) << " de newIndex " << newIndex;
            _tasksByIndex.remove(newIndex);
            if (ta) {
                _indexesById.remove(ta->id());
            }
            forwardItemsToMove = false;
        }
        newIndex++; oldIndex++;
    }
    endRemoveRows();
    qDebug() << "TaskListModel::removeFromListModel: wosByIndex "<<_tasksByIndex<<"; indexesById " << _indexesById;
}

void TaskListModel::insertNewTask(int id)
{
    // primero cargamos de nuevo el modelo de base de datos y lo fetcheamos
    sqlSelect();
    int maxIndexInModel = maxIndex();
    fetchDbModelUntil(maxIndexInModel + 1); // vamos a insertar una nueva, que estará de las primeras
    qDebug() << "TaskListModel::insertNewWorkOrder: id " << id << ", maxIndex " << maxIndexInModel
             << ", dbmodel tiene " << _databaseModel->rowCount();
    int index = searchForIndex(id, maxIndexInModel + 1);
    if (index >= 0) {
        insertIntoListModel(index, index, true);
    } else {
        qDebug() << "WorkOrderListModel::insertNewWorkOrder: no se insertará porque no está fetcheada";
    }
}

void TaskListModel::removeTask(int id)
{
    // ya estará borrado de db. Así que cargamos el modelo de db de nuevo y alineamos
    sqlSelect();
    int maxIndexInModel = maxIndex();
    fetchDbModelUntil(maxIndexInModel);
    int index = _indexesById.value(id, -1);
    if (index >= 0) { // solo es necesario borrarlo si ya estaba fetcheado en este modelo
        removeFromListModel(index, index);
    }
}

void TaskListModel::fetchDbModelUntil(int rowIndex)
{
    while (_databaseModel->rowCount() < (rowIndex + 1) && _databaseModel->canFetchMore()) {
        qDebug() << "WorkOrderListModel::fetchDbModelUntil: dbModel " << _databaseModel->rowCount()
                 << " rows, indMaximo " << rowIndex << " entradas; fetcheando dbModel";
        _databaseModel->fetchMore();
    }
}

int TaskListModel::searchForIndex(int id, int maxIndex)
{
    // buscaremos en el modelo de db (debe estar fetcheado) qué índice ocupa la tarea dada
    // maxIndex es un tope, por seguridad
    int result = -1;
    int ind = 0;
    qDebug() << "TaskListModel::searchForIndex: id buscado "<<id<<", indice maximo " << maxIndex;
    while (ind <= maxIndex && result == -1) {
        int currid = sqlData(ind, TaskStore::TASK_ID).toInt();
        if (id == currid) {
            result = ind;
        }
        ind++;
    }
    return result;
}

void TaskListModel::changeTaskState(int id)
{
    // parece que no se puede borrar e insertar debido a las secciones. Por tanto, hacemos un reset
    int maxIndexInModel = maxIndex();
    int index = _indexesById.value(id, -1);
    if (index >= 0) {
        // hacemos un select para tener el nuevo orden y fetcheamos en el modelo de db lo mismo que teníamos
        sqlSelect();
        fetchDbModelUntil(maxIndexInModel);
        // y ahora hacemos el reset y cargamos de nuevo
        beginResetModel();
        _indexesById.clear();
        _tasksByIndex.clear();
        insertIntoListModel(0, maxIndexInModel, false);
        endResetModel();
    }
}

void TaskListModel::updateData(int id)
{
    int taskIndex = _indexesById.value(id, -1);
    qDebug() << "TaskListModel::updateData: id " << id << " esta en el indice " << taskIndex;
    if (taskIndex >= 0) {
        Q_EMIT(dataChanged(index(taskIndex, 0), index(taskIndex, 0)));
    }
}

int TaskListModel::indexOf(int id) const
{
    return _indexesById.value(id, -1);
}

void TaskListModel::updateDataForWorkOrder(int workOrderId)
{
    qDebug() << "TaskListModel::updateDataForWorkOrder: notificando cambios a tareas con wo " << workOrderId;
    for (auto taskIndex : _tasksByIndex.keys()) {
        Task *currTask = _tasksByIndex.value(taskIndex);
        if (currTask) {
            QList<WorkOrder*> wolist = currTask->workOrderList();
            for (auto wo : wolist) {
                if (wo->id() == workOrderId) {
                    Q_EMIT(dataChanged(index(taskIndex, 0), index(taskIndex, 0)));
                }
            }
        }
    }
}

