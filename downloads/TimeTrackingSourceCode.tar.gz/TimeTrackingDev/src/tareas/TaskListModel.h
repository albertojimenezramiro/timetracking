/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 12 jan. 2019
**
****************************************************************************/

#ifndef TAREAS_TASKLISTMODEL_H_
#define TAREAS_TASKLISTMODEL_H_

#include <QAbstractListModel>
#include <QMap>

#include "TaskStore.h"

class QSqlTableModel;
class Task;

class TaskListModel: public QAbstractListModel {
Q_OBJECT
public:
        TaskListModel(QObject *parent, TaskStore *store);
    virtual ~TaskListModel();

    void initialize();

    int rowCount(const QModelIndex& = QModelIndex()) const override;
    QVariant data(const QModelIndex &, int = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    bool canFetchMore(const QModelIndex &) const override;
    void fetchMore(const QModelIndex &) override;

    void loadModel(bool includeArchived, int archiveThreshold);
    void clearModel();
    void insertNewTask(int id);
    void removeTask(int id);
    void changeTaskState(int id);
    void updateData(int id);
    int indexOf(int id) const;
    void updateDataForWorkOrder(int workOrderId);

private:

    enum RoleEnum {
        WOID = Qt::UserRole + 1,
        NAME,
        CODE,
        ARCHIVED,
        WOTEXT,
        ACTIVE
    };

    QVariant sqlData(int i, TaskStore::TaskFields field);
    int maxIndex() const;
    void sqlSelect();
    void fetchDbModelUntil(int rowIndex);
    int searchForIndex(int id, int maxIndex);
    void insertIntoListModel(int first, int last, bool signalInsertions);
    void shiftModelForInsertion(const int indicePrimero, const int numHuecos);
    void removeFromListModel(int first, int last);

    QSqlTableModel* _databaseModel;
    QMap<int, int> _indexesById;
    QMap<int, Task*> _tasksByIndex;
    TaskStore *_store;
    int _dbPageSize;
    int _archiveThreshold;
    bool _includeArchived;
};
Q_DECLARE_METATYPE(TaskListModel*);
#endif /* TAREAS_TASKLISTMODEL_H_ */
