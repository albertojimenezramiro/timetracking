/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 29 sept. 2023
**
****************************************************************************/

#include "TasksViewModel.h"
#include <QDebug>
#include "TaskListModel.h"
#include <qqml.h>
#include <QTimer>
#include "TTSettings.h"
#include "../workorders/WorkOrder.h"
#include "../workorders/WorkOrderSuggestionsModel.h"
#ifdef FEATURE_JIRAINTEGRATION
#include <QNetworkAccessManager>
#include "../red/JiraApi.h"
#include "../red/JiraListModel.h"
#endif
#include "MultipleWosModel.h"
#include "../tiempo/TimeEntry.h"
#include "../projects/Project.h"
#include "../projects/ProjectSuggestionsModel.h"

QString TasksViewModel::_noWOCodeString = "<orden sin código>";
QString TasksViewModel::_noProjectNameString = "<proyecto sin nombre>";

TasksViewModel::TasksViewModel(QObject* parent, TaskStore *store, TTSettings *settings, WorkOrderStore *woStore, ProjectStore *projectStore) :
    QObject(parent),
    _taskLoaded(nullptr),
    _store(store),
    _workOrderStore(woStore),
    _timeStore(nullptr),
    _editorIsDirty(false),
    _settings(settings),
    _descriptionIsResetting(false),
    _activeTaskIndex(-1),
    _activeTask(nullptr),
    _projectEdited(nullptr),
    _projectStore(projectStore),
    _projectTextDirty(false),
    _workOrderTextDirty(false)
{
    qDebug() << "TasksViewModel::TasksViewModel";
    qmlRegisterUncreatableType<TaskListModel>("TimeTracking.models", 1, 0, "TaskListModel", "No se puede crear un TaskListModel");
    connect(_store, &TaskStore::taskNotification, this, &TasksViewModel::slotNotifications, Qt::QueuedConnection);
    connect(_projectStore, &ProjectStore::projectNotification, this, &TasksViewModel::slotProjectNotifications, Qt::QueuedConnection);
    connect(_workOrderStore, &WorkOrderStore::woNotification, this, &TasksViewModel::slotWorkOrderNotifications, Qt::QueuedConnection);
    connect(_settings, &TTSettings::diasCierreTareasChanged, this, &TasksViewModel::slotArchivedTaskThresholdChanged);
    _listModel = new TaskListModel(this, store);
    qDebug() << "TasksViewModel::TasksViewModel: cargar TaskListModel con threshold " << (_settings?_settings->diasCierreTareas():-1);
    _saveDelay = new QTimer();
    connect(_saveDelay, &QTimer::timeout, this, &TasksViewModel::saveChanges);
    _saveDelay->setInterval(800);
    _workOrderSuggestionsModel = new WorkOrderSuggestionsModel(this);
    _buttonListModel = new TaskListModel(this, store);
#ifdef FEATURE_JIRAINTEGRATION
    _networkManager = new QNetworkAccessManager(this);
    _jiraApi = new JiraApi(_networkManager, _settings, this);
    qRegisterMetaType<JiraListModel*>();
    qmlRegisterUncreatableType<JiraListModel>("TimeTracking.models", 1, 0, "JiraListModel", "No se puede crear un JiraListModel");
    _jiraListModel = new JiraListModel(_jiraApi, this, store);
#endif
    qmlRegisterUncreatableType<MultipleWosModel>("TimeTracking.models", 1, 0, "MultipleWosModel", "No se puede crear un MultipleWosModel");
    _multipleWosEditedModel = new MultipleWosModel(this);
    _multipleWOSuggestionsModel = new WorkOrderSuggestionsModel(this);
    qmlRegisterUncreatableType<ProjectSuggestionsModel>("TimeTracking.models", 1, 0, "ProjectSuggestionsModel", "No se puede crear un ProjectSuggestionsModel");
    _projectSuggestionsModel = new ProjectSuggestionsModel(this);
}

TasksViewModel::~TasksViewModel()
{
}

void TasksViewModel::initialize()
{
    _listModel->initialize();
    _listModel->loadModel(true, _settings->diasCierreTareas());
    _buttonListModel->initialize();
    _buttonListModel->loadModel(false, 0);
}

void TasksViewModel::setTimeStore(TimeStore *store)
{
    _timeStore = store;
    if (_timeStore) {
        connect(_timeStore, &TimeStore::timeNotification, this, &TasksViewModel::slotTimeNotifications, Qt::UniqueConnection);
    }
}

// properties

QString TasksViewModel::nameEdited() const
{
    return _nameEdited;
}
void TasksViewModel::setNameEdited(const QString &newValue)
{
    qDebug() << "TasksViewModel::setNameEdited";
    if (_nameEdited != newValue) {
        _nameEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
    }
}
QString TasksViewModel::descEdited() const
{
    return _descEdited;
}
void TasksViewModel::setDescEdited(const QString &newValue)
{
    qDebug() << "TasksViewModel::setDescEdited";
    if (_descEdited != newValue && !_descriptionIsResetting) {
        _descEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
    }
}
QString TasksViewModel::codeEdited() const
{
    return _codeEdited;
}
void TasksViewModel::setCodeEdited(const QString &newValue)
{
    qDebug() << "TasksViewModel::setCodeEdited";
    if (_codeEdited != newValue) {
        _codeEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
    }
}

QString TasksViewModel::workOrderTextEdited() const
{
    return _workOrderTextEdited;
}

void TasksViewModel::setWorkOrderTextEdited(const QString &newValue)
{
    if (_workOrderTextEdited != newValue) {
        _workOrderTextEdited = newValue;
        qDebug() << "TasksViewModel::setWorkOrderTextEdited: " << _workOrderTextEdited;
        calculateWorkOrderSuggestions();
        checkIfIsSuggestedWorkOrder(newValue);
    }
}

QString TasksViewModel::projectTextEdited() const
{
    return _projectTextEdited;
}

void TasksViewModel::setProjectTextEdited(const QString &newPattern)
{
    if (_projectTextEdited != newPattern) {
        _projectTextEdited = newPattern;
        calculateProjectSuggestions();
        checkIfTextIsProject(newPattern.trimmed());
    }
}

QString TasksViewModel::name() const
{
    return _taskLoaded ? _taskLoaded->name() : "";
}

QString TasksViewModel::desc() const
{
    return _taskLoaded ? _taskLoaded->description() : "";
}

QString TasksViewModel::code() const
{
    return _taskLoaded ? _taskLoaded->code() : "";
}


bool TasksViewModel::archived() const
{
    return _taskLoaded && _taskLoaded->isArchived();
}

bool TasksViewModel::active() const
{
    return _taskLoaded && _activeTask && _activeTask->id() == _taskLoaded->id();
}

int TasksViewModel::id() const
{
    return _taskLoaded ? _taskLoaded->id() : -1;
}

QString TasksViewModel::workOrderText() const
{
    QString res = "";
    if (_taskLoaded) {
        QList<WorkOrder*> list = _workOrders.keys();
        QStringList strList;
        for (auto w : list) {
            QString code = w->code().trimmed().isEmpty() ? _noWOCodeString : w->code().trimmed();
            strList.append(code);
        }
        qDebug() << "TasksViewModel::workOrderText: wos "<<list.size()<<": "<<strList;
        res = strList.join(", ");
    }
    return res;
}

bool TasksViewModel::workOrderTextDirty() const
{
    return _workOrderTextDirty;
}

QString TasksViewModel::workOrderName() const
{
    QString res = "";
    if (_taskLoaded && _workOrders.size() == 1) {
        res = _workOrders.keys().value(0)->name();
    }
    return res;
}

QString TasksViewModel::projectText() const
{
    QString res = "";
    if (_taskLoaded && _taskLoaded->project()) {
        qDebug() << "TasksViewModel::projectText: loaded con proyecto de nombre "<<_taskLoaded->project()->name();
        if (_taskLoaded->project()->name().trimmed().isEmpty()) {
            res = _noProjectNameString;
        } else {
            res = _taskLoaded->project()->name().trimmed();
        }
    }
    return res;
}

QString TasksViewModel::projectCode() const
{
    QString res = "";
    if (_taskLoaded && _taskLoaded->project()) {
        if (_taskLoaded->project()->code().trimmed().isEmpty()) {
            res = "<proyecto sin código>";
        } else {
            res = _taskLoaded->project()->code().trimmed();
        }
    }
    return res;
}

bool TasksViewModel::projectTextDirty() const
{
    return _projectTextDirty;
}

bool TasksViewModel::hasMultipleWosEdited() const
{
    qDebug() << "TasksViewModel::hasMultipleWosEdited: " << _workOrdersEdited;
    return _taskLoaded && _workOrdersEdited.size() > 1;
}

MultipleWosModel *TasksViewModel::multipleWosEditedModel() const
{
    return _multipleWosEditedModel;
}

TaskListModel *TasksViewModel::listModel() const
{
    return _listModel;
}

TaskListModel *TasksViewModel::buttonListModel() const
{
    return _buttonListModel;
}

WorkOrderSuggestionsModel *TasksViewModel::workOrderSuggestionsModel() const
{
    return _workOrderSuggestionsModel;
}

ProjectSuggestionsModel *TasksViewModel::projectSuggestionsModel() const
{
    qDebug() << "TasksViewModel::projectSuggestionsModel: "<<_projectSuggestionsModel;
    return _projectSuggestionsModel;
}
#ifdef FEATURE_JIRAINTEGRATION
JiraListModel *TasksViewModel::jiraListModel() const
{
    return _jiraListModel;
}
#endif
void TasksViewModel::setActiveTaskIndex(int newIndex)
{
    if (_activeTaskIndex != newIndex) {
        _activeTaskIndex = newIndex;
        Q_EMIT(activeTaskIndexChanged());
    }
}

///////////////////////
///                 ///
/// BUSINESS-LOGIC  ///
///                 ///
///////////////////////

void TasksViewModel::loadTask(int id)
{
    Task *ta = id > 0 ? _store->task(id, false) : nullptr;
    qDebug() << "TasksViewModel::loadTask: id " << id << ", wo " << ta << ", loaded " << _taskLoaded;
    if (ta != _taskLoaded) {
        saveChanges();
        _taskLoaded = ta;
        if (ta) {
            _workOrders = ta->workOrderMap();
        } else {
            _workOrders.clear();
        }
        emitLoadedTaskSignals();
        cleanEditedFields();
    }
}

void TasksViewModel::createNewTask()
{
    saveChanges();
    _store->createNewTask();
}

void TasksViewModel::archiveTask()
{
    saveChanges();
    if (_taskLoaded && !_taskLoaded->isArchived()) {
        _store->archiveTask(_taskLoaded->id());
    }
}

void TasksViewModel::reopenTask()
{
    saveChanges();
    if (_taskLoaded && _taskLoaded->isArchived()) {
        _store->reopenTask(_taskLoaded->id());
    }
}

void TasksViewModel::saveChanges()
{
    qDebug() << "TasksViewModel::saveChanges: dirty " << _editorIsDirty;
    _saveDelay->stop();
    if (_taskLoaded && _editorIsDirty) {
        int projectId = _projectEdited ? _projectEdited->id() : -1;
        _store->updateTaskDataInDb(_taskLoaded->id(), _nameEdited, _descEdited, _codeEdited, _workOrdersEdited, projectId);
        _editorIsDirty = false;
    }
    setProjectTextDirty(false);
    setWorkOrderTextDirty(false);
    qDebug() << "TasksViewModel::saveChanges: final";
}

void TasksViewModel::emitLoadedTaskSignals()
{
    Q_EMIT(nameChanged());
    _descriptionIsResetting = true;
    Q_EMIT(descChanged());
    _descriptionIsResetting = false;
    Q_EMIT(codeChanged());
    Q_EMIT(idChanged());
    Q_EMIT(archivedChanged());
    Q_EMIT(activeChanged());
    Q_EMIT(workOrderTextChanged());
    Q_EMIT(workOrderNameChanged());
    Q_EMIT(projectTextChanged());
    Q_EMIT(projectCodeChanged());
}

void TasksViewModel::cleanEditedFields()
{
    qDebug() << "TasksViewModel::cleanEditedFields";
    // esto no es un cambio que haya que guardar, por lo que no debe lanzar el timer ni actualizar
    // el flag de dirty. Por eso no uso setters.

    _nameEdited = name();
    _descEdited = desc();
    _codeEdited = code();
    _workOrdersEdited = _workOrders;
    _workOrderTextEdited = workOrderText();
    calculateWorkOrderSuggestions();
    Q_EMIT(enableMultipleWosChanged());
    Q_EMIT(hasMultipleWosEditedChanged());
    _projectTextEdited = projectText();
    _projectEdited = _taskLoaded ? _taskLoaded->project() : nullptr;
    calculateProjectSuggestions();
}

void TasksViewModel::slotNotifications(TaskStore::TaskNotifications notification, int taskId)
{
    switch (notification) {
        case TaskStore::TASKNOTIF_NEWTASK: {
            qDebug() << "TasksViewModel::slotNotifications: newtask. insertando en modelo de lista";
            Task *n = _store->task(taskId, false);
            _listModel->insertNewTask(n->id());
            Q_EMIT(taskIndexChanged(_listModel->indexOf(n->id())));
            qDebug() << "TasksViewModel::slotNotifications: insertando ahora en modelo de botonera";
            _buttonListModel->insertNewTask(n->id());
            break;
        }
        case TaskStore::TASKNOTIF_REOPEN:
        case TaskStore::TASKNOTIF_ARCHIVED: {
            qDebug() << "TasksViewModel::slotNotifications: notification reopen o archived. Cambiando estado en modelo de lista. task " << taskId;
            Task *n = _store->task(taskId, false);
            _listModel->changeTaskState(n->id());
            if (notification == TaskStore::TASKNOTIF_REOPEN) {
                qDebug() << "TasksViewModel::slotNotifications: insertando ahora en modelo de botonera";
                Q_EMIT(taskIndexChanged(_listModel->indexOf(n->id())));
                _buttonListModel->insertNewTask(n->id());
            } else {
                qDebug() << "TasksViewModel::slotNotifications: eliminando ahora de modelo de botonera";
                _buttonListModel->removeTask(n->id());
            }
            break;
        }
        case TaskStore::TASKNOTIF_UPDATEDATA: {
            Task *n = _store->task(taskId, false);
            if (_taskLoaded->id() == n->id()) {
                qDebug() << "TasksViewModel::slotNotifications: updatedata, id " << n->id() << " "<<_taskLoaded;
                _workOrders = n->workOrderMap();
                emitLoadedTaskSignals();
                cleanEditedFields();
            }
            qDebug() << "TasksViewModel::slotNotifications: actualizando en modelo de lista";
            _listModel->updateData(n->id());
            qDebug() << "TasksViewModel::slotNotifications: actualizando en modelo de botonera";
            _buttonListModel->updateData(n->id());
            break;
        }
        case TaskStore::TASKNOTIF_IMPORTEDTASK: {
            qDebug() << "TasksViewModel::slotNotifications: tarea importada; revisando work orders";
            Task *n = _store->task(taskId, false);
            bool error = false;
            QMap<WorkOrder*, int> woMap;
            for (auto wo : _wosPendingToBeImported.keys()) {
                QString code = wo;
                int perc = _wosPendingToBeImported.value(wo).toInt();
                // revisamos las work orders e intentamos crear las que no existen aún
                WorkOrder *woObject = _workOrderStore->woByCode(code);
                if (!woObject) {
                    _workOrderStore->importWorkOrder(code);// sincrono, sin esperar la notificacion; si no, se complica mucho
                    woObject = _workOrderStore->woByCode(code);
                }
                // en este punto, la work order debería existir ya de cualquier modo
                if (woObject) {
                    // si la work order está bien creada, nos la guardamos en el mapa definitivo
                    woMap.insert(woObject, perc);
                } else {
                    // ante cualquier error, no guardaremos las work orders. así que nos guardamos esto.
                    qCritical() << "no se ha podido importar la work order " << code;
                    error = true;
                }
            }
            Project *project = _projectStore->projectByCode(_projectPendingToBeImported);
            if (project == nullptr) {
                // si no existe el proyecto, creamos uno nuevo con este code
                _projectStore->importProject(_projectPendingToBeImported);
                project = _projectStore->projectByCode(_projectPendingToBeImported);
            }
            if (!error) {
                // solo asignamos las work orders a la tarea si todas existen
                _store->updateTaskDataInDb(taskId, n->name(), n->description(), n->code(), woMap, project ? project->id() : -1);
                _projectPendingToBeImported = -1;
            }
            qDebug() << "TasksViewModel::slotNotifications: insertando la tarea importada en modelo de lista";
            _listModel->insertNewTask(n->id());
            Q_EMIT(taskIndexChanged(_listModel->indexOf(n->id())));
            qDebug() << "TasksViewModel::slotNotifications: insertando ahora en modelo de botonera";
            _buttonListModel->insertNewTask(n->id());
            break;
        }
        default:
            break;
    }
}

void TasksViewModel::slotProjectNotifications(ProjectStore::ProjectNotifications notification, int projectId)
{
    Q_UNUSED(projectId);
    switch (notification) {
        case ProjectStore::PROJECTNOTIF_NEW:
        case ProjectStore::PROJECTNOTIF_IMPORTED:
        case ProjectStore::PROJECTNOTIF_ARCHIVED:
        case ProjectStore::PROJECTNOTIF_REOPEN:
        case ProjectStore::PROJECTNOTIF_UPDATEDATA: {
            if (_taskLoaded) {
                qDebug() << "TasksViewModel::slotProjectNotifications: reevaluating project suggestions";
                calculateProjectSuggestions();
                checkIfTextIsProject(_projectTextEdited.trimmed());
                Q_EMIT(projectCodeChanged());
                Q_EMIT(projectTextChanged());
            }
            break;
        }
        default:
            break;
    }
}

void TasksViewModel::slotWorkOrderNotifications(WorkOrderStore::WorkOrderNotifications notification, int workOrderId)
{
    switch (notification) {
        case WorkOrderStore::WONOTIF_UPDATEDATA: {
            _buttonListModel->updateDataForWorkOrder(workOrderId);
            Q_EMIT(workOrderTextChanged());
            Q_EMIT(workOrderNameChanged());
            _workOrdersEdited = _workOrders;
            _workOrderTextEdited = workOrderText();
            calculateWorkOrderSuggestions();
            Q_EMIT(enableMultipleWosChanged());
            break;
        }
        default:
            break;
    }
}

void TasksViewModel::evaluateActiveTask()
{
    if (_timeStore) {
        TimeEntry *last = _timeStore->mostRecentEntry();
        evaluateActiveTask(last);
    }
}

void TasksViewModel::evaluateActiveTask(TimeEntry *lastTimeEntry)
{
    qDebug() << "TasksViewModel::evaluateActiveTask";
    if (lastTimeEntry) {
        int newId = lastTimeEntry->taskId();
        qDebug() << "TasksViewModel::evaluateActiveTask: " << newId << "; activeTask " << _activeTask
                 << ", id " << (_activeTask ? _activeTask->id() : -1);
        if (_activeTask) { // si ya teniamos una tarea activa
            if (newId <= 0) { // ninguna activa
                _activeTask->setActive(false);
                _buttonListModel->updateData(_activeTask->id());
                _activeTask = nullptr;
                setActiveTaskIndex(-1);
            } else if (newId == _activeTask->id()) { // la misma que ya estaba. esto es un error, pero lo soportamos.

            } else { // nueva tarea activa
                _activeTask->setActive(false);
                _buttonListModel->updateData(_activeTask->id());
                _activeTask = _store->task(newId, true);
                qDebug() << "TasksViewModel::evaluateActiveTask: nueva activeTask " << _activeTask
                         << ", id " << (_activeTask ? _activeTask->id() : -1);
                _activeTask->setActive(true);
                _buttonListModel->updateData(newId);
                setActiveTaskIndex(_buttonListModel->indexOf(newId));
            }
        } else { // si no teníamos tarea activa
            if (newId <= 0) { // ninguna activa. esto es un error, no debería pasar

            } else {
                _activeTask = _store->task(newId, true);
                qDebug() << "TasksViewModel::evaluateActiveTask: nueva activeTask " << _activeTask
                         << ", id " << (_activeTask ? _activeTask->id() : -1);
                _activeTask->setActive(true);
                _buttonListModel->updateData(newId);
                setActiveTaskIndex(_buttonListModel->indexOf(newId));
            }
        }
        Q_EMIT(activeChanged());
    }
    qDebug() << "TasksViewModel::evaluateActiveTask: fin";
}

void TasksViewModel::slotTimeNotifications(TimeStore::TimeNotifications notification, qint64 entryId)
{
    Q_UNUSED(entryId);
    switch (notification) {
        case TimeStore::TIMENOTIF_NEWENTRY:
        case TimeStore::TIMENOTIF_UPDATEDATA: {
            qDebug() << "TasksViewModel::slotTimeNotifications: nueva entrada de tiempo: " << entryId;
            TimeEntry *lastTimeEntry = _timeStore->mostRecentEntry();
            evaluateActiveTask(lastTimeEntry);
            break;
        }
        default:
            break;
    }
}

void TasksViewModel::slotArchivedTaskThresholdChanged()
{
    qDebug() << "TasksViewModel::slotArchivedTaskThresholdChanged";
    _listModel->loadModel(true, _settings->diasCierreTareas());
    Q_EMIT(taskIndexChanged(0));
}

void TasksViewModel::calculateWorkOrderSuggestions()
{
    int excludeId = -1;//no necesitamos excluir ninguna work order
    qDebug() << "TasksViewModel::calculateWorkOrderSuggestions: calculando sugerencias para texto '"
             << _workOrderTextEdited << "' excluyendo id " << excludeId;
    _workOrderSuggestionsModel->loadModel(_workOrderStore->suggestionsFor(_workOrderTextEdited, false, false, excludeId));
}

bool TasksViewModel::checkIfIsSuggestedWorkOrder(const QString &pattern)
{
    QString trimmed = pattern.trimmed();
    qDebug() << "TasksViewModel::checkIfIsSuggestedWorkOrder: comprobando si hay una wo sugerida exacta con codigo "<<trimmed;
    WorkOrder *found = trimmed.isEmpty() ? nullptr : _workOrderSuggestionsModel->suggestionWithCode(trimmed);
    if (found || pattern.trimmed().isEmpty()) {
        _workOrdersEdited.clear();
        if (found) {
            _workOrdersEdited.insert(found, 100);
        }
        Q_EMIT(hasMultipleWosEditedChanged());
        _editorIsDirty = true;
        _saveDelay->start();
        setWorkOrderTextDirty(true);
    }
    Q_EMIT(enableMultipleWosChanged());
    return (found != nullptr);
}

void TasksViewModel::selectWorkOrderSuggestion(int index)
{
    WorkOrder *suggestion = _workOrderSuggestionsModel->suggestionAt(index);
    qDebug() << "TasksViewModel::selectWorkOrderSuggestion: index " << index << ", suggestion " << (suggestion?suggestion->id():-1);
    if (suggestion) {
        _workOrdersEdited.clear();
        _workOrdersEdited.insert(suggestion, 100);
        _editorIsDirty = true;
        qDebug() << "TasksViewModel::selectWorkOrderSuggestion: wos editadas "<<_workOrdersEdited;
        saveChanges();
        Q_EMIT(enableMultipleWosChanged());
        Q_EMIT(hasMultipleWosEditedChanged());
    }
}

int TasksViewModel::activeTaskIndex() const
{
    return _activeTaskIndex;
}
#ifdef FEATURE_JIRAINTEGRATION
void TasksViewModel::importJiraIssue(const QString &key, const QString &summary, const QString &description, const QVariantMap &wos, const QString &projectCode)
{
    qDebug() << "TasksViewModel::importJiraIssue: importando tarea " << key << " " << summary << " " << projectCode;
    _wosPendingToBeImported = wos;
    _projectPendingToBeImported = projectCode;
    _store->importTask(summary, key, description);
}
#endif
WorkOrderSuggestionsModel *TasksViewModel::multipleWOSuggestionsModel() const
{
    return _multipleWOSuggestionsModel;
}

void TasksViewModel::calculateMultipleWOSuggestions(const QString &pattern)
{
       qDebug() << "TasksViewModel::calculateMultipleWOSuggestions: calculando sugerencias para texto '"
                << pattern << "'";
       _multipleWOSuggestionsModel->loadModel(_workOrderStore->suggestionsFor(pattern, false, false, -1));
}

bool TasksViewModel::checkIfMultipleWOExact(const QString &pattern, int index)
{
    QString trimmed = pattern.trimmed();
    qDebug() << "TasksViewModel::checkIfMultipleWOExact: comprobando si hay una wo sugerida exacta con codigo "<<trimmed;
    WorkOrder *found = trimmed.isEmpty() ? nullptr : _multipleWOSuggestionsModel->suggestionWithCode(trimmed);
    if (found) {
        _multipleWosEditedModel->addNewWorkOrder(found, 0);
    } else {
        _multipleWosEditedModel->removeWorkOrder(index, pattern, true);
    }
    return (found != nullptr);
}

void TasksViewModel::removeMultipleWO(int index)
{
    _multipleWosEditedModel->removeWorkOrder(index, "", false);
}

bool TasksViewModel::enableMultipleWos() const
{
    bool res = false;
    qDebug() << "TasksViewModel::enableMultipleWos: "<<_workOrderTextEdited << " wos edited size " << _workOrdersEdited.size();
    if (_workOrderTextEdited.size() > 0) {
        QList<WorkOrder*> wos = _workOrdersEdited.keys();
        int ind = 0;
        res = wos.size() > 1;
        while (!res && ind < wos.size()) {
            qDebug() << "code " << wos.value(ind)->code();
            res |= (wos.value(ind)->code() == _workOrderTextEdited || (wos.value(ind)->code().trimmed().isEmpty() && _workOrderTextEdited == _noWOCodeString));
            ind++;
        }
    }
    return res;
}

void TasksViewModel::loadMultipleWosModel()
{
    _multipleWosEditedModel->loadModel(_workOrdersEdited);
}

void TasksViewModel::saveMultipleWoChanges()
{
    qDebug() << "TasksViewModel::saveMultipleWoChanges: guardando nuevas wos";
    _workOrdersEdited = _multipleWosEditedModel->getMap();
    _editorIsDirty = true;
    saveChanges();
}

void TasksViewModel::selectMultipleWoSuggestion(int suggestionIndex, int woIndex)
{
    WorkOrder *suggestion = _multipleWOSuggestionsModel->suggestionAt(suggestionIndex);
    qDebug() << "TasksViewModel::selectMultipleWoSuggestion: index " << suggestionIndex << ", suggestion " << (suggestion?suggestion->id():-1);
    if (suggestion) {
        _multipleWosEditedModel->confirmSuggestion(suggestion, woIndex);
    }
}

void TasksViewModel::calculateProjectSuggestions()
{
    qDebug() << "TasksViewModel::calculateProjectSuggestions: calculando sugerencias de proyecto para texto '"
             << _projectTextEdited ;
    _projectSuggestionsModel->loadModel(_projectStore->suggestionsFor(_projectTextEdited.trimmed()));
}

void TasksViewModel::selectProjectSuggestion(int index)
{
    Project *suggestion = _projectSuggestionsModel->suggestionAt(index);
    qDebug() << "TasksViewModel::selectProjectSuggestion: index " << index << ", suggestion " << (suggestion?suggestion->id():-1);
    if (suggestion) {
        _projectEdited = suggestion;
        _editorIsDirty = true;
        saveChanges(); // esto lanza la notificación de updatedata y ya se emiten las señales de cambio
    }
}

bool TasksViewModel::checkIfTextIsProject(const QString &pattern)
{
    qDebug() << "TasksViewModel::checkIfTextIsProject: comprobando si hay un proyecto exacto con nombre "<<pattern;
    Project *found = pattern.isEmpty() ? nullptr : _projectSuggestionsModel->suggestionExactMatch(pattern);
    if (found || pattern.trimmed().isEmpty()) {
        _projectEdited = found;
        _editorIsDirty = true;
        _saveDelay->start();
        setProjectTextDirty(true);
        // si se guarda de inmediato no se da lugar a que el usuario escriba un nombre de proyecto
        // más largo que podría existir: "proyecto 1" vs "proyecto 11". Usando el delay salvamos este problema
    }
    return (found != nullptr);
}

void TasksViewModel::setProjectTextDirty(bool value)
{
    if (_projectTextDirty != value) {
        _projectTextDirty = value;
        Q_EMIT(projectTextDirtyChanged());
    }
}

void TasksViewModel::setWorkOrderTextDirty(bool value)
{
    if (_workOrderTextDirty != value) {
        _workOrderTextDirty = value;
        Q_EMIT(workOrderTextDirtyChanged());
    }
}

