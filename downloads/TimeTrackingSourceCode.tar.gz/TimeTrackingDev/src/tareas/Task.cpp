/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 8 oct. 2018
**
****************************************************************************/

#include <QDebug>
#include "Task.h"
#include "../workorders/WorkOrder.h"
#include "../projects/Project.h"
#include "../Reloj.h"

Task::Task(QObject* parent) :
    QObject(parent),
    _id(-1),
    _isArchived(false),
    _isActive(false),
    _project(nullptr)
{
}

Task::Task(const Task& w) :
    QObject(w.parent()),
    _id(w._id),
    _name(w._name),
    _description(w._description),
    _code(w._code),
    _isArchived(w._isArchived),
    _archiveDate(w._archiveDate),
    _isActive(w._isActive),
    _project(w._project)
{
}

Task::Task(QObject* parent, int id, QString nombre, QString desc) :
    QObject(parent),
    _id(id),
    _name(nombre),
    _description(desc),
    _isArchived(false),
    _isActive(false),
    _project(nullptr)
{
}

Task::~Task()
{
}

QString Task::name() const
{
    return _name;
}
QString Task::description() const
{
    return _description;
}
QString Task::code() const
{
    return _code;
}

int Task::id() const
{
    return _id;
}

bool Task::isArchived() const
{
    return _isArchived;
}

Project *Task::project() const
{
    return _project;
}

void Task::setName(const QString &name)
{
    if (_name != name) {
        _name = name;
    }
}
void Task::setDescription(const QString &desc)
{
    if (_description != desc) {
        _description = desc;
    }
}

void Task::setArchiveDate(const QDateTime &archiveDate)
{
    _archiveDate = archiveDate;
    _isArchived = (Reloj::currentDateTime() > archiveDate);
}

void Task::setCode(const QString &code)
{
    _code = code;
}

QDateTime Task::archiveDate() const
{
    return _archiveDate;
}

void Task::addWorkOrder(WorkOrder *wo, int percentage)
{
    _workOrders.insert(wo, percentage);
}

bool Task::hasMultipleWorkOrders() const
{
    return _workOrders.size() > 1;
}

int Task::numWorkOrders() const
{
    return _workOrders.size();
}

WorkOrder *Task::workOrderByIndex(int index) const
{
    return _workOrders.keys().value(index);
}

QList<WorkOrder*> Task::workOrderList() const
{
    return _workOrders.keys();
}

QMap<WorkOrder*, int> Task::workOrderMap() const
{
    return _workOrders;
}

void Task::clearWorkOrders()
{
    _workOrders.clear();
}

bool Task::isActive() const
{
    return _isActive;
}

void Task::setActive(bool value)
{
    _isActive = value;
}

void Task::setProject(Project *project)
{
    _project = project;
}

