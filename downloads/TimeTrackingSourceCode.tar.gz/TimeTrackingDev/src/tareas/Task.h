/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 8 oct. 2018
**
****************************************************************************/

#ifndef SRC_TAREAS_TASK_H_
#define SRC_TAREAS_TASK_H_

#include <QObject>
#include <QString>
#include <QDateTime>
#include <QMap>

class WorkOrder;
class Project;

class Task: public QObject {
public:
    Task(QObject* parent = 0);
    Task(const Task& w);
    Task(QObject* parent, int id, QString name, QString desc);
    virtual ~Task();

    QString name() const;
    QString description() const;
    QString code() const;
    bool isArchived() const;
    int id() const;
    QDateTime archiveDate() const;
    bool hasMultipleWorkOrders() const;
    bool isActive() const;
    Project *project() const;

    void setName(const QString &name);
    void setDescription(const QString &desc);
    void setCode(const QString &code);
    void setArchiveDate(const QDateTime &archiveDate);
    void setActive(bool value);
    void setProject(Project *project);

    void addWorkOrder(WorkOrder *wo, int percentage);
    int numWorkOrders() const;
    WorkOrder *workOrderByIndex(int index) const;
    QList<WorkOrder*> workOrderList() const;
    QMap<WorkOrder*, int> workOrderMap() const;
    void clearWorkOrders();

private:
    int _id;
    QString _name;
    QString _description;
    QString _code;
    bool _isArchived;
    QDateTime _archiveDate;
    QMap<WorkOrder*, int> _workOrders;
    bool _isActive;
    Project *_project;
};

#endif /* SRC_TAREAS_TASK_H_ */
