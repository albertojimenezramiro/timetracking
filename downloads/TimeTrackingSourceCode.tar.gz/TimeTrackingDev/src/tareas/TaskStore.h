/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 12 jan. 2019
**
****************************************************************************/

#ifndef SRC_TAREAS_TASKSTORE_H_
#define SRC_TAREAS_TASKSTORE_H_

#include <QString>
#include <QList>
#include <QObject>
#include <QDateTime>
#include <QVariant>

class QSqlTableModel;
class Task;
class WorkOrderStore;
class WorkOrder;
class ProjectStore;

class TaskStore : public QObject {
Q_OBJECT
public:
    // fields for browsing into the db model resultset
    enum TaskFields {
        TASK_ID = 0,
        TASK_NAME,
        TASK_DESCRIPTION,
        TASK_WO_DEPRECATED,
        TASK_ARCHIVEDATE,
        TASK_CREATIONTIME,
        TASK_REMOVED,
        TASK_CODE
    };

    typedef enum TaskNotifications {
        TASKNOTIF_NONE = 0,
        TASKNOTIF_NEWTASK,
        TASKNOTIF_ARCHIVED,
        TASKNOTIF_REOPEN,
        TASKNOTIF_UPDATEDATA,
        TASKNOTIF_IMPORTEDTASK
    } TaskNotifications;
    Q_ENUM(TaskNotifications)

    TaskStore(QObject* parent, WorkOrderStore *workOrderStore, ProjectStore *projectStore);
    virtual ~TaskStore();

    void initialize();

    Task *task(int id, bool loadFromDb);
    Task *last() const;
    /**
     * @brief Creates a new task into the database using the given data and loads it into
     *        memory.
     *
     * @return
     */
    void createNewTaskFromData(const QString &name, const QString &code, qint64 creationTime, const QString &description, qint64 archiveTime);
    void createNewTask();
    void importTask(const QString &name, const QString &code, const QString &description);
    void archiveTask(int id);
    void reopenTask(int id);
    bool updateTaskDataInDb(int id, const QString &name, const QString &description, const QString &code, QMap<WorkOrder*, int> workOrders, int projectId);
    bool updateArchiveDateInDb(int id, const QDateTime &archiveDate);
    bool existsTaskWithCode(const QString &code);

Q_SIGNALS:
    // sends a notification
    void taskNotification(TaskStore::TaskNotifications notification, int taskId);

private:
    Task *taskFactoryMethod(int id, const QString &name, const QString &desc, const QString &code);
    // extracts a piece of data from the resultset of the db model, using a row number for the resultset and a column field
    QVariant sqlData(int rowIndex, TaskStore::TaskFields column);
    // this loads the db model with a select based on task id
    void selectTask(int id);
    void loadTaskWorkOrders(Task *task);
    void saveTaskWorkOrders(Task *task, QMap<WorkOrder*, int> workOrders);
    bool sameWOs(QMap<WorkOrder*, int> w1, QMap<WorkOrder*, int> w2) const;
    Task *cacheSelected();
    Task *cacheSelected(int rowIndex);
    void loadTaskProject(Task *task);
    void saveTaskProject(Task *task, int projectId);

    QSqlTableModel* _taskModelDb;
    QMap<int, Task*> _taskById;
    WorkOrderStore *_workOrderStore;
    Task *_last;
    ProjectStore *_projectStore;

    static const qint64 _defaultArchiveTimestamp;
};

#endif /* SRC_TAREAS_TASKSTORE_H_ */
