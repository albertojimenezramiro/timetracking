/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 7 oct. 2023
**
****************************************************************************/

#ifndef TAREAS_MULTIPLEWOSMODEL_H_
#define TAREAS_MULTIPLEWOSMODEL_H_

#include <QAbstractListModel>
#include <QList>

class WorkOrder;

class MultipleWosModel: public QAbstractListModel
{

    Q_OBJECT
    Q_PROPERTY(int size READ size NOTIFY sizeChanged)
    Q_PROPERTY(int totalPercentage READ totalPercentage NOTIFY totalPercentageChanged)
    Q_PROPERTY(QString errorStr READ errorStr NOTIFY errorStrChanged)

public:
    MultipleWosModel(QObject *parent);
    virtual ~MultipleWosModel();

    int rowCount(const QModelIndex& = QModelIndex()) const override;
    QVariant data(const QModelIndex &, int = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    bool canFetchMore(const QModelIndex &) const override;
    void fetchMore(const QModelIndex &) override;

    void loadModel(QMap<WorkOrder*, int> map);
    void clearModel();
    int size() const;
    int totalPercentage() const;
    void setVirtualText(const QString &text);
    void setVirtualPercentage(int percentage);
    QString errorStr() const;

    QMap<WorkOrder*, int> getMap() const;

    Q_INVOKABLE void modifyPercentage(int id, int percentage);
    void addNewWorkOrder(WorkOrder *wo, int perc);
    void removeWorkOrder(int indexToRemove, const QString &pattern, bool saveInVirtual);
    void confirmSuggestion(WorkOrder *suggestion, int woIndex);

Q_SIGNALS:
    void sizeChanged();
    void totalPercentageChanged();
    void errorStrChanged();

private:

    enum RoleEnum {
        MULTIPLE_ID = Qt::UserRole + 1,
        MULTIPLE_CODE,
        MULTIPLE_PERC,
        MULTIPLE_PREVINCOMPLETE,
        MULTIPLE_NAME
    };

    void setTotalPercentage(int value);
    void checkEntries();
    void calculatePercentage();
    void calculateError();

    QMap<WorkOrder*, int> _map;
    int _totalPercentage;
    QHash<int, WorkOrder*> _byId;
    QHash<int, WorkOrder*> _byIndex;

    QString _virtualText;
    int _virtualPercentage;
    QString _errorStr;

};
Q_DECLARE_METATYPE(MultipleWosModel*);
#endif /* TAREAS_MULTIPLEWOSMODEL_H_ */
