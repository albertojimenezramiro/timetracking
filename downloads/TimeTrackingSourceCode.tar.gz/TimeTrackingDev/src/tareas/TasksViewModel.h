/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 29 sept. 2023
**
****************************************************************************/

#ifndef SRC_TAREAS_TASKSVIEWMODEL_H_
#define SRC_TAREAS_TASKSVIEWMODEL_H_

#include <QObject>
#include "Task.h"
#include "TaskStore.h"
#include "../tiempo/TimeStore.h"
#include "../projects/ProjectStore.h"
#include "../workorders/WorkOrderStore.h"

class TaskListModel;
class QTimer;
class TTSettings;
class WorkOrderSuggestionsModel;
#ifdef FEATURE_JIRAINTEGRATION
class JiraListModel;
class QNetworkAccessManager;
class JiraApi;
#endif
class MultipleWosModel;
class TimeStore;
class ProjectSuggestionsModel;
class Project;

class TasksViewModel : public QObject
{
    Q_OBJECT

    // data from loaded task
    Q_PROPERTY(QString name READ name NOTIFY nameChanged)
    Q_PROPERTY(QString description READ desc NOTIFY descChanged)
    Q_PROPERTY(QString code READ code NOTIFY codeChanged)
    Q_PROPERTY(bool archived READ archived NOTIFY archivedChanged)
    Q_PROPERTY(bool active READ active NOTIFY activeChanged)
    Q_PROPERTY(int id READ id NOTIFY idChanged)
    Q_PROPERTY(QString workOrderText READ workOrderText NOTIFY workOrderTextChanged)
    Q_PROPERTY(QString workOrderName READ workOrderName NOTIFY workOrderNameChanged)
    Q_PROPERTY(bool enableMultipleWos READ enableMultipleWos NOTIFY enableMultipleWosChanged)
    Q_PROPERTY(QString projectText READ projectText NOTIFY projectTextChanged)
    Q_PROPERTY(QString projectCode READ projectCode NOTIFY projectCodeChanged)
    Q_PROPERTY(bool workOrderTextDirty READ workOrderTextDirty NOTIFY workOrderTextDirtyChanged)
    Q_PROPERTY(bool projectTextDirty READ projectTextDirty NOTIFY projectTextDirtyChanged)

    // editable fields
    Q_PROPERTY(QString nameEdited READ nameEdited WRITE setNameEdited NOTIFY nameEditedChanged)
    Q_PROPERTY(QString descriptionEdited READ descEdited WRITE setDescEdited NOTIFY descEditedChanged)
    Q_PROPERTY(QString codeEdited READ codeEdited WRITE setCodeEdited NOTIFY codeEditedChanged)
    Q_PROPERTY(QString workOrderTextEdited READ workOrderTextEdited WRITE setWorkOrderTextEdited NOTIFY workOrderTextEditedChanged)
    Q_PROPERTY(MultipleWosModel* multipleWosEditedModel READ multipleWosEditedModel CONSTANT)
    Q_PROPERTY(bool hasMultipleWosEdited READ hasMultipleWosEdited NOTIFY hasMultipleWosEditedChanged)
    Q_PROPERTY(QString projectTextEdited READ projectTextEdited WRITE setProjectTextEdited NOTIFY projectTextEditedChanged)

    Q_PROPERTY(TaskListModel* listModel READ listModel CONSTANT)
    Q_PROPERTY(WorkOrderSuggestionsModel* workOrderSuggestionsModel READ workOrderSuggestionsModel CONSTANT)
#ifdef FEATURE_JIRAINTEGRATION
    Q_PROPERTY(JiraListModel* jiraListModel READ jiraListModel CONSTANT)
#endif
    Q_PROPERTY(TaskListModel* buttonListModel READ buttonListModel CONSTANT)
    Q_PROPERTY(int activeTaskIndex READ activeTaskIndex NOTIFY activeTaskIndexChanged)
    Q_PROPERTY(WorkOrderSuggestionsModel* multipleWOSuggestionsModel READ multipleWOSuggestionsModel CONSTANT)
    Q_PROPERTY(ProjectSuggestionsModel* projectSuggestionsModel READ projectSuggestionsModel CONSTANT)

    public:
        TasksViewModel(QObject* parent, TaskStore *store, TTSettings *settings, WorkOrderStore *woStore, ProjectStore *projectStore);
        virtual ~TasksViewModel();

        void initialize();
        void evaluateActiveTask();

        void setTimeStore(TimeStore *store);

        // properties

        // editable fields content
        QString nameEdited() const;
        void setNameEdited(const QString &newValue);
        QString descEdited() const;
        void setDescEdited(const QString &newValue);
        QString codeEdited() const;
        void setCodeEdited(const QString &newValue);
        QString workOrderTextEdited() const;
        void setWorkOrderTextEdited(const QString &newValue);
        QString projectTextEdited() const;
        void setProjectTextEdited(const QString &newValue);

        // loaded work order data
        QString name() const;
        QString desc() const;
        QString code() const;
        bool archived() const;
        bool active() const;
        int id() const;
        QString workOrderText() const;
        QString workOrderName() const;
        bool hasMultipleWosEdited() const; // mira si las wos editadas para la tarea son varias (las que stán pendientes de guardar aún)
        MultipleWosModel *multipleWosEditedModel() const;
        bool enableMultipleWos() const;
        QString projectText() const;
        QString projectCode() const;
        bool projectTextDirty() const;
        bool workOrderTextDirty() const;

        TaskListModel *listModel() const;
        WorkOrderSuggestionsModel *workOrderSuggestionsModel() const;
        TaskListModel *buttonListModel() const;
        int activeTaskIndex() const;
        void setActiveTaskIndex(int newIndex);
#ifdef FEATURE_JIRAINTEGRATION
        JiraListModel *jiraListModel() const;
#endif
        WorkOrderSuggestionsModel *multipleWOSuggestionsModel() const;
        ProjectSuggestionsModel *projectSuggestionsModel() const;

        //business-logic
        Q_INVOKABLE void loadTask(int id);
        Q_INVOKABLE void createNewTask();
        Q_INVOKABLE void archiveTask();
        Q_INVOKABLE void reopenTask();
        Q_INVOKABLE void selectWorkOrderSuggestion(int index);
#ifdef FEATURE_JIRAINTEGRATION
        Q_INVOKABLE void importJiraIssue(const QString &key, const QString &summary, const QString &description, const QVariantMap &wos, const QString &projectCode);
#endif
        Q_INVOKABLE void calculateMultipleWOSuggestions(const QString &pattern);
        Q_INVOKABLE bool checkIfMultipleWOExact(const QString &pattern, int index);
        Q_INVOKABLE void removeMultipleWO(int index);
        Q_INVOKABLE void loadMultipleWosModel();
        Q_INVOKABLE void saveMultipleWoChanges();
        Q_INVOKABLE void selectMultipleWoSuggestion(int suggestionIndex, int woIndex);
        Q_INVOKABLE void selectProjectSuggestion(int index);

    Q_SIGNALS:
        // properties
        void nameEditedChanged();
        void descEditedChanged();
        void codeEditedChanged();
        void workOrderTextEditedChanged();
        void projectTextEditedChanged();
        void nameChanged();
        void descChanged();
        void codeChanged();
        void idChanged();
        void archivedChanged();
        void activeChanged();
        void workOrderTextChanged();
        void workOrderNameChanged();
        void projectTextChanged();
        void projectCodeChanged();
        void enableMultipleWosChanged();
        void hasMultipleWosEditedChanged();
        void taskIndexChanged(int newIndex);
        void activeTaskIndexChanged();
        void projectTextDirtyChanged();
        void workOrderTextDirtyChanged();

    private Q_SLOTS:
        void slotNotifications(TaskStore::TaskNotifications notification, int taskId);
        void slotProjectNotifications(ProjectStore::ProjectNotifications notification, int projectId);
        void slotWorkOrderNotifications(WorkOrderStore::WorkOrderNotifications notification, int workOrderId);
        void slotTimeNotifications(TimeStore::TimeNotifications notification, qint64 entryId);
        void saveChanges();
        void slotArchivedTaskThresholdChanged();

    private:

        void emitLoadedTaskSignals();
        void cleanEditedFields();
        void calculateWorkOrderSuggestions();
        bool checkIfIsSuggestedWorkOrder(const QString &pattern);
        void evaluateActiveTask(TimeEntry *lastTimeEntry);
        void calculateProjectSuggestions();
        bool checkIfTextIsProject(const QString &pattern);
        void setProjectTextDirty(bool value);
        void setWorkOrderTextDirty(bool value);

        static QString _noWOCodeString;
        static QString _noProjectNameString;

        Task *_taskLoaded;
        QString _nameEdited;
        QString _descEdited;
        QString _codeEdited;
        QString _workOrderTextEdited;
        QString _projectTextEdited;

        TaskStore *_store;
        WorkOrderStore *_workOrderStore;
        TimeStore *_timeStore;
        TaskListModel *_listModel;
        bool _editorIsDirty;
        QTimer *_saveDelay;
        TTSettings *_settings;
        WorkOrderSuggestionsModel *_workOrderSuggestionsModel; // modelo de sugerencias de wo para el editor de tarea
        QMap<WorkOrder*, int> _workOrders; // mapa con las work orders y porcentajes guardadas de la tarea
        QMap<WorkOrder*, int> _workOrdersEdited; // mapa con las work orders y porcentajes que están siendo editados y pendientes de guardar
        bool _descriptionIsResetting;
        TaskListModel *_buttonListModel;
        int _activeTaskIndex;
        Task *_activeTask;
#ifdef FEATURE_JIRAINTEGRATION
        JiraListModel *_jiraListModel;
        QNetworkAccessManager *_networkManager;
        JiraApi *_jiraApi;
#endif
        //auxiliary property to store the wos of a jira while the task is being created
        // they will be imported in a second step
        QVariantMap _wosPendingToBeImported;

        MultipleWosModel *_multipleWosEditedModel; // modelo de wos y porcentajes para el popup de wos múltiples
        WorkOrderSuggestionsModel *_multipleWOSuggestionsModel; // modelo de sugerencias de wos para el popup de wos múltiples
        ProjectSuggestionsModel *_projectSuggestionsModel;
        Project *_projectEdited;
        QString _projectPendingToBeImported;
        ProjectStore *_projectStore;
        bool _projectTextDirty;
        bool _workOrderTextDirty;
};

#endif /* SRC_TAREAS_TASKSVIEWMODEL_H_ */
