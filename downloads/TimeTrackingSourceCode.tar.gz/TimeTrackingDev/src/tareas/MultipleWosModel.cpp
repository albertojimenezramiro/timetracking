/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 7 oct. 2023
**
****************************************************************************/

#include <QDebug>
#include "../workorders/WorkOrder.h"
#include "MultipleWosModel.h"

MultipleWosModel::MultipleWosModel(QObject *parent) :
    QAbstractListModel(parent),
    _totalPercentage(0),
    _virtualPercentage(0)
{
}

MultipleWosModel::~MultipleWosModel()
{
}

int MultipleWosModel::rowCount(const QModelIndex &) const
{
    int count = _map.size() + 1;
    return count;
}

QVariant MultipleWosModel::data(const QModelIndex &modelIndex, int role) const
{
    int nrow = modelIndex.row();
    WorkOrder *w = _byIndex.value(nrow, nullptr);
    int perc = w ? _map.value(w) : _virtualPercentage;
    if (role == MULTIPLE_ID) {
        return QVariant::fromValue(w ? w->id() : -1);
    } else if (role == MULTIPLE_CODE) {
        return QVariant::fromValue(w ? w->code() : _virtualText);
    } else if (role == MULTIPLE_NAME) {
        return QVariant::fromValue(w ? w->name() : "");
    } else if (role == MULTIPLE_PERC) {
        return QVariant::fromValue(perc);
    } else if (role == MULTIPLE_PREVINCOMPLETE) {
        int prevIndex = nrow - 1;
        bool res = false;
        WorkOrder * prevObj = _byIndex.value(prevIndex, nullptr);
        if (prevObj) {
            res = (_map.value(prevObj,-1) == 0);
        }
        return QVariant::fromValue(res);
    } else {
        return QVariant();
    }
    return QVariant();
}

QHash<int, QByteArray> MultipleWosModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[MULTIPLE_ID] = "woid";
        roles[MULTIPLE_PERC] = "percentage";
        roles[MULTIPLE_CODE] = "code";
        roles[MULTIPLE_PREVINCOMPLETE] = "previousIsIncomplete";
        roles[MULTIPLE_NAME] = "name";
    }
    return roles;
}

bool MultipleWosModel::canFetchMore(const QModelIndex &) const
{
    return false;
}

void MultipleWosModel::fetchMore(const QModelIndex &)
{}

void MultipleWosModel::clearModel()
{
    beginResetModel();
    _map.clear();
    _byId.clear();
    _byIndex.clear();
    setVirtualPercentage(0);
    setVirtualText("");
    endResetModel();
    Q_EMIT(sizeChanged());
}

void MultipleWosModel::loadModel(QMap<WorkOrder*, int> map)
{
    qDebug() << "MultipleWosModel::loadModel: cargando modelo " << map;
    beginResetModel();
    _map = map;
    _byId.clear();
    _byIndex.clear();
    checkEntries();
    setVirtualPercentage(0);
    setVirtualText("");
    endResetModel();
    qDebug() << "MultipleWosModel::loadModel: total perc " << _totalPercentage<<", size "<<rowCount(QModelIndex());
    Q_EMIT(sizeChanged());
    calculateError();
}

void MultipleWosModel::checkEntries()
{
    int total = 0;
    int ind = 0;
    for (auto w : _map.keys()) {
        _byId.insert(w->id(), w);
        _byIndex.insert(ind, w);
        total += _map.value(w);
        ind++;
    }
    setTotalPercentage(total);
}

void MultipleWosModel::calculatePercentage()
{
    int total = 0;
    for (auto w : _map.values()) {
        total += w;
    }
    setTotalPercentage(total);
}

void MultipleWosModel::setTotalPercentage(int value)
{
    qDebug() << "MultipleWosModel::setTotalPercentage: nuevo "<<value<<", actual "<<_totalPercentage;
    if (_totalPercentage != value) {
        _totalPercentage = value;
        Q_EMIT(totalPercentageChanged());
    }
}

int MultipleWosModel::totalPercentage() const
{
    return _totalPercentage;
}

int MultipleWosModel::size() const
{
    return _map.size();
}

QMap<WorkOrder*, int> MultipleWosModel::getMap() const
{
    // antes de exportar el mapa resultante, filtramos las entradas malas que pudiera tener
    QMap<WorkOrder*, int> resMap = _map;
    for (int i = 0; i < resMap.size(); i++) {
        WorkOrder *wo = _byIndex.value(i);
        if (resMap.value(wo) == 0) {
            resMap.remove(wo);
        }
    }
    qDebug() << "resmap "<<resMap;
    return resMap;
}

void MultipleWosModel::modifyPercentage(int id, int percentage)
{
    qDebug() << "MultipleWosModel::modifyPercentage: id " << id << " -> " << percentage << " %";
    WorkOrder *w = _byId.value(id, nullptr);
    if (w) {
        _map.insert(w, percentage);
        int indexInModel = _byIndex.values().indexOf(w);
        int endRange = indexInModel;
        if (indexInModel+1 < _map.size()) {
            endRange++;
        }
        Q_EMIT(dataChanged(index(indexInModel, 0), index(endRange, 0)));
        calculatePercentage();
    } else {
        setVirtualPercentage(percentage);
    }
    calculateError();
}

void MultipleWosModel::addNewWorkOrder(WorkOrder *wo, int perc)
{
    // el modelo señaliza un elemento más de los que tiene le mapa, para reflejar el virtual.
    // cuando agregamos una nueva work order, tenemos que insertarlo en el índice map.size() porque el
    // mapa solo tenía hasta map.size-1. Pero señalizamos la inserción en map.size+1 y señalizamos un
    // cambio en map.size.
    int newIndex = _map.size() + 1;// dejamos el virtual quieto
    qDebug() << "MultipleWosModel::addNewWorkOrder: wo " << (wo?wo->id():-1) << " " << perc << "%. newIndex " << newIndex;
    beginInsertRows(QModelIndex(), newIndex, newIndex);
    _map.insert(wo, _virtualPercentage);
    _byId.insert(wo->id(), wo);
    _byIndex.insert(newIndex-1, wo);
    endInsertRows();
    setVirtualPercentage(0);
    setVirtualText("");
    calculatePercentage();
    qDebug() << "MultipleWosModel::addNewWorkOrder: emitiendo dataChanged " << (newIndex-1);
    Q_EMIT(dataChanged(index(newIndex-1), index(newIndex-1)));
    Q_EMIT(sizeChanged());
    calculateError();
}

void MultipleWosModel::removeWorkOrder(int indexToRemove, const QString &pattern, bool saveInVirtual)
{
    // solo borraremos wos reales
    qDebug() << "MultipleWosModel::removeWorkOrder: index " << indexToRemove << ", pattern " << pattern << ", saveVirt "<<saveInVirtual;
    if (indexToRemove < _map.size()) {
        int removalSignalIndex = indexToRemove;
        if (indexToRemove == _map.size() - 1 && saveInVirtual) {
            // si eliminamos la última real y salvamos sus datos en la virtual, vamos a señalizar la eliminación
            // de la virtual y un changed de la última real, para que mantenga el foco y se comporte mejor visualmente
            removalSignalIndex++;
        }



        qDebug() << "MultipleWosModel::removeWorkOrder: beginremoverows " <<removalSignalIndex;
        beginRemoveRows(QModelIndex(), removalSignalIndex, removalSignalIndex);
        WorkOrder *w = _byIndex.value(indexToRemove, nullptr);
        if (saveInVirtual) {
            setVirtualText(pattern);
            setVirtualPercentage(_map.value(w));
            qDebug() << "MultipleWosModel::removeWorkOrder: datos de virtual " << pattern << " "<<_map.value(w);
        }
        _map.remove(w);
        _byId.remove(w->id());
        for (int ind = indexToRemove; ind < _map.size() ; ind++) {
            WorkOrder *w = _byIndex.value(ind+1);
            if (w) {
                _byIndex.insert(ind, w);
            }
        }
        _byIndex.remove(_map.size());
        endRemoveRows();
        Q_EMIT(sizeChanged());
        calculatePercentage();
        qDebug() << "MultipleWosModel::removeWorkOrder: dataChanged " << indexToRemove << " - " << _map.size();
        Q_EMIT(dataChanged(index(indexToRemove), index(_map.size())));// el datachanged tambien para el virtual
    } else {
        if (saveInVirtual) {
            setVirtualText(pattern);
        }
    }
    calculateError();
}

void MultipleWosModel::setVirtualText(const QString &text)
{
    _virtualText = text;
}
void MultipleWosModel::setVirtualPercentage(int percentage)
{
    _virtualPercentage = percentage;
}

QString MultipleWosModel::errorStr() const
{
    return _errorStr;
}

void MultipleWosModel::calculateError()
{
    qDebug() << "MultipleWosModel::calculateError: totalperc "<<_totalPercentage<<", virtual " << _virtualText;
    QString oldError = _errorStr;
    if (_totalPercentage == 100) {
        _errorStr = "";
        // si las work orders reales suman 100%, no importa lo que haya en la virtual (ni siquiera se verá en pantalla)
    } else {
        if (_virtualText.isEmpty()) {
            if (_map.isEmpty()) {
                _errorStr = tr("Debe quedar al menos una orden de trabajo");
            } else {
                _errorStr = tr("Los porcentajes deben sumar 100%");
            }
        } else {
            _errorStr = tr("Hay órdenes de trabajo incorrectas");
        }
    }
    if (oldError != _errorStr) {
        Q_EMIT(errorStrChanged());
    }
}

void MultipleWosModel::confirmSuggestion(WorkOrder *suggestion, int woIndex)
{
    qDebug() << "MultipleWosModel::confirmSuggestion: wo " << suggestion->id() << " en index " << woIndex;
    if (woIndex < _map.size()) { // sugerencia para una que ya era real
        WorkOrder *real = _byIndex.value(woIndex);
        if (real != suggestion) {
            // solo hacemos algo si es una wo distinta a la que había; entonces la tenemos que cambiar
            int perc = _map.value(real);
            _map.remove(real);
            _map.insert(suggestion, perc);
            _byId.remove(real->id());
            _byId.insert(suggestion->id(), suggestion);
            _byIndex.insert(woIndex, suggestion);
            calculateError();
            Q_EMIT(dataChanged(index(woIndex), index(woIndex)));// el datachanged tambien para el virtual
        }
    } else if (woIndex == _map.size()) { // sugerencia para la virtual
        addNewWorkOrder(suggestion, 0);
    }
}
