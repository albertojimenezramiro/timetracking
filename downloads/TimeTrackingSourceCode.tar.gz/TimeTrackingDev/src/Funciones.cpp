/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 19 ene. 2019
**
****************************************************************************/

#include "Funciones.h"
#include <QtNumeric>
#include <QtMath>
#include <QDebug>

QDateTime calcularPrimerDiaSemana(const QDateTime& ref, const int firstDayOfWeek,
        const int lastDayOfWeek, int& numDiasLaborales)
{
    int dayOrdinal = ref.date().dayOfWeek();
    QDateTime firstDay;
    if (firstDayOfWeek < lastDayOfWeek) { // semana laboral contenida en la semana natural
        firstDay = ref.addDays(-(dayOrdinal-firstDayOfWeek));
        numDiasLaborales = lastDayOfWeek - firstDayOfWeek + 1;
        // primer día de la semana laboral contenida en la natural, sea futuro o pasado
    } else { // semana laboral empieza en una semana natural y termina en la siguiente
        if (dayOrdinal >= firstDayOfWeek) { // dentro de la semana laboral, primera semana natural
            firstDay = ref.addDays(-(dayOrdinal-firstDayOfWeek));

        } else if (dayOrdinal <= lastDayOfWeek) { // dentro de la semana laboral, segunda semana natural
            int dayOrdMayor = dayOrdinal + 7; //así el día de ref vuelve a ser mayor que el primero
            firstDay = ref.addDays(-(dayOrdMayor-firstDayOfWeek));
        } else { // fuera de la semana laboral, nos ponemos en el primer dia de la laboral terminada
            int diff = (dayOrdinal - 1) + (7 - firstDayOfWeek) + 1;
            //primer paréntesis: diferencia desde dayOrdinal hasta el día 1
            //segundo paréntesis: diferencia desde _first hasta el día 7
            // + 1 para el día del 7 al 1
            firstDay = ref.addDays(-diff); // primer dia de la semana laboral terminada
        }
        if (firstDayOfWeek == lastDayOfWeek) {
            numDiasLaborales = 1;
        } else {
            numDiasLaborales = lastDayOfWeek + (7 - firstDayOfWeek + 1);
        }
    }
    return firstDay;
}

qreal roundTo(qreal number, int decimals)
{
    qreal multiplier = (qreal)(qPow(10, decimals));
    qreal aux = number * multiplier;
    int auxInt = qRound(aux);
    //qDebug() << "roundTo: "<<number<<", "<<decimals<<". multiplier " << multiplier << ", aux es "<<aux<<", -> int "<<auxInt;
    aux = ((qreal)auxInt) / multiplier;
    return aux;
}

QDateTime firstDayOfMonth(const QDateTime &ref)
{
    QDateTime first = ref;
    first.setTime(QTime(0, 0, 0, 0));
    first = first.addDays(-(first.date().day() - 1));
    return first;
}

QString toSexagesimal(qint64 msecs, bool useSecs)
{
    // primero normalizamos para que siempre sea positivo
    qint64 normalizedSource = msecs >= 0 ? msecs : -msecs;
    qint64 mseconds = normalizedSource % 1000;
    qint64 sourceSecs = normalizedSource / 1000; // descartamos msecs
    qint64 seconds = sourceSecs % 60;
    sourceSecs -= seconds;
    qint64 minutes = (sourceSecs % (60 * 60)) / 60;
    sourceSecs -= (minutes * 60);
    qint64 hours = sourceSecs / (60 * 60);
    if ( (((hours * 3600) + (minutes * 60) + seconds) * 1000) + mseconds != normalizedSource ) {
        qWarning() << "ATENCIÓN!!! error al convertir " << msecs << " a sexagesimal. " << hours << " "<< minutes << " " << seconds;
    }
    QString res = QString::number(hours) + ":" + QString::number(minutes).rightJustified(2, '0');
    if (useSecs) {
        res += ":" + QString::number(seconds).rightJustified(2, '0');
    }
    return res;
}
