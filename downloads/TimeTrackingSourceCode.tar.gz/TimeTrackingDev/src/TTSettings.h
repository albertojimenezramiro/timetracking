/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 17 nov 2018
**
****************************************************************************/

#ifndef SRC_TTSETTINGS_H_
#define SRC_TTSETTINGS_H_

#include <QString>
#include <QVariant>
#include <QObject>
#include <QTime>

class QSettings;

class TTSettings : public QObject {
    Q_OBJECT

    Q_ENUMS(AgrupacionReportes);

    Q_PROPERTY(QDateTime comienzoJornada READ comienzoJornadaDate WRITE setComienzoJornada NOTIFY limitesJornadaChanged)
    Q_PROPERTY(QDateTime finalJornada READ finalJornadaDate WRITE setFinalJornada NOTIFY limitesJornadaChanged)
    Q_PROPERTY(AgrupacionReportes agrupacionReportes READ agrupacionReportes WRITE setAgrupacionReportes NOTIFY agrupacionReportesChanged)
    Q_PROPERTY(int decimales READ decimales WRITE setDecimales NOTIFY decimalesChanged)
    Q_PROPERTY(QString descripciones READ descripcionesPath WRITE setDescripcionesPath NOTIFY descripcionesPathChanged)
    Q_PROPERTY(QString usuarioJira READ usuarioJira WRITE setUsuarioJira NOTIFY usuarioJiraChanged)
    Q_PROPERTY(QString tokenJira READ tokenJira WRITE setTokenJira NOTIFY tokenJiraChanged)
    Q_PROPERTY(QString urlJira READ urlJira WRITE setUrlJira NOTIFY urlJiraChanged)
    Q_PROPERTY(int diasCierreTareas READ diasCierreTareas WRITE setDiasCierreTareas NOTIFY diasCierreTareasChanged)
    // las horas de trabajo de cada día de la semana laboral
    Q_PROPERTY(QVariantList horasTrabajo READ horasTrabajo WRITE setHorasTrabajo NOTIFY horasTrabajoChanged)
    // las órdenes de trabajo archivadas hace más de este umbral de días se ocultan de la lista
    Q_PROPERTY(int archivedWorkOrderThreshold READ archivedWorkOrderThreshold WRITE setArchivedWorkOrderThreshold NOTIFY archivedWorkOrderThresholdChanged)
    // comienzo y final de la semana laboral
    Q_PROPERTY(int firstDayOfWeek READ firstDayOfWeek WRITE setFirstDayOfWeek NOTIFY workingWeekRangeChanged)
    Q_PROPERTY(int lastDayOfWeek READ lastDayOfWeek WRITE setLastDayOfWeek NOTIFY workingWeekRangeChanged)
    // los proyectos archivados hace más de este umbral de días se ocultan de la lista
    Q_PROPERTY(int archivedProjectThreshold READ archivedProjectThreshold WRITE setArchivedProjectThreshold NOTIFY archivedProjectThresholdChanged)
    Q_PROPERTY(int accumulatedProjectReportsThreshold READ accumulatedProjectReportsThreshold WRITE setAccumulatedProjectReportsThreshold NOTIFY accumulatedProjectReportsThresholdChanged)
    Q_PROPERTY(ReportUnit reportUnit READ reportUnit WRITE setReportUnit NOTIFY reportUnitChanged)

public:

    static QString filePath();
    static QString backupPath();

    typedef enum AgrupacionReportes {
        AGRUPAR_TAREAS,
        AGRUPAR_WOS,
        AGRUPAR_MIXTO
    } AgrupacionReportes;

    typedef enum ReportUnit {
        REPORTUNIT_DECIMAL,
        REPORTUNIT_SEXAGESIMAL
    } ReportUnit;
    Q_ENUM(ReportUnit);

    TTSettings();
    virtual ~TTSettings();

    void checkUserBackup(const QString &version);

    int firstDayOfWeek() const;
    int lastDayOfWeek() const;
    void setLastDayOfWeek(int l);
    void setFirstDayOfWeek(int f);
    QTime comienzoJornada() const;
    void setComienzoJornada(QDateTime comienzo);
    QDateTime comienzoJornadaDate() const;
    QTime finalJornada() const;
    void setFinalJornada(QDateTime final);
    QDateTime finalJornadaDate() const;
    AgrupacionReportes agrupacionReportes() const;
    void setAgrupacionReportes(AgrupacionReportes group);
    int decimales() const;
    void setDecimales(int value);
    QString descripcionesPath() const;
    void setDescripcionesPath(QString path);
    QString usuarioJira() const;
    void setUsuarioJira(QString usuario);
    QString tokenJira() const;
    void setTokenJira(QString token);
    int diasCierreTareas() const;
    void setDiasCierreTareas(const int dias);
    QVariantList horasTrabajo() const;
    void setHorasTrabajo(QVariantList horas);
    int archivedWorkOrderThreshold() const;
    void setArchivedWorkOrderThreshold(int days);
    int archivedProjectThreshold() const;
    void setArchivedProjectThreshold(int days);
    int accumulatedProjectReportsThreshold() const;
    void setAccumulatedProjectReportsThreshold(int days);
    ReportUnit reportUnit() const;
    void setReportUnit(ReportUnit newUnit);
    QString urlJira() const;
    void setUrlJira(const QString &url);

    static QString _userDataDirectory;


Q_SIGNALS:
    void limitesJornadaChanged();
    void agrupacionReportesChanged();
    void decimalesChanged();
    void descripcionesPathChanged();
    void usuarioJiraChanged();
    void tokenJiraChanged();
    void diasCierreTareasChanged();
    void horasTrabajoChanged();
    void archivedWorkOrderThresholdChanged();
    void workingWeekRangeChanged();
    void archivedProjectThresholdChanged();
    void accumulatedProjectReportsThresholdChanged();
    void reportUnitChanged();
    void urlJiraChanged();

private:
    void setDefaultSettings();
    void setDefaultSetting(const QString &key, const QVariant &defaultValue);

    QSettings *_settings;

    static const QString _oldPath;
    static const QString _oldBackupPath;

    static const QString _firstDayKey;
    static const QString _lastDayKey;
    static const QString _comienzoJornadaKey;
    static const QString _finalJornadaKey;
    static const QString _agruparReportesKey;
    static const QString _decimalesKey;
    static const QString _descripcionesPathKey;
    static const QString _usuarioJiraKey;
    static const QString _tokenJiraKey;
    static const QString _diasCierreTareasKey;
    static const QString _horasTrabajoKey;
    static const QString _archivedWorkOrderThresholdKey;
    static const QString _archivedProjectThresholdKey;
    static const QString _accumulatedProjectReportsThresholdKey;
    static const QString _reportUnitKey;
    static const QString _urlJiraKey;
};
Q_DECLARE_METATYPE(TTSettings*);
#endif /* SRC_TTSETTINGS_H_ */
