/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 29 mar. 2019
**
****************************************************************************/

#ifndef SRC_RED_JIRALISTMODEL_H_
#define SRC_RED_JIRALISTMODEL_H_

#include <qobject.h>
#include <QAbstractListModel>
#include "JiraIssue.h"

class JiraApi;
class TaskStore;

class JiraListModel: public QAbstractListModel {
    Q_OBJECT
    Q_PROPERTY(ModelState state READ state NOTIFY stateChanged FINAL)
    Q_PROPERTY(QString errorMsg READ errorMsg NOTIFY errorMsgChanged FINAL)
public:
    typedef enum ModelState {
        IDLE,
        LOADING,
        LOADED,
        ERROR
    } ModelState;
    Q_ENUM(ModelState);

    typedef enum EstadoJira {
        ESTADO_SINRESOLVER,
        ESTADO_INPROGRESS,
        ESTADO_RESUELTO
    } EstadoJira;

    JiraListModel(JiraApi *api, QObject *parent, TaskStore *taskStore);
    virtual ~JiraListModel();

    QHash<int, QByteArray> roleNames() const;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const;
    int rowCount(const QModelIndex &parent = QModelIndex()) const;
    void fetchMore(const QModelIndex &parent) override;
    bool canFetchMore(const QModelIndex &parent) const override;

    ModelState state() const;
    QString errorMsg() const;
    void clearModel();

public Q_SLOTS:
    void loadModel();
    void applyFilters(const QString &filtroKey, const QString &filtroAsignado);

Q_SIGNALS:
    void stateChanged();
    void errorMsgChanged();

private Q_SLOTS:
    void slotNewJiras(int firstIndex, int total, QList<JiraIssue*> issues);
    void slotError(const QString &errorMsg);

private:
    void setState(ModelState state);
    void setErrorMsg(const QString &msg);

    enum RoleEnum {
        KEY = Qt::UserRole,
        SUMMARY,
        PRIORITY,
        DESCRIPTION,
        TYPE,
        IMPORTED,
        WOS,
        STATUS,
        PROJECTCODE
    };
    JiraApi *_api;
    ModelState _state;
    QHash<int, JiraIssue*> _issues;
    QHash<QString, bool> _importados;
    TaskStore *_taskStore;
    int _total;
    QString _lastKey;
    QString _lastAssigned;
    QString _lastError;
};
Q_DECLARE_METATYPE(JiraListModel*);
#endif /* SRC_RED_JIRALISTMODEL_H_ */
