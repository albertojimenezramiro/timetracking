/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 29 mar. 2019
**
****************************************************************************/

#include "JiraListModel.h"
#include "JiraApi.h"
#include "../tareas/TaskStore.h"
#include "../projects/Project.h"

JiraListModel::JiraListModel(JiraApi *api, QObject *parent, TaskStore *taskStore) :
    QAbstractListModel(parent),
    _api(api),
    _state(IDLE),
    _taskStore(taskStore),
    _total(0)
{
    connect(_api, &JiraApi::newJiras, this, &JiraListModel::slotNewJiras);
    connect(_api, &JiraApi::error, this, &JiraListModel::slotError, Qt::QueuedConnection);
}

JiraListModel::~JiraListModel() {}

QHash<int, QByteArray> JiraListModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[KEY] = "key";
        roles[SUMMARY] = "summary";
        roles[PRIORITY] = "priority";
        roles[DESCRIPTION] = "description";
        roles[TYPE] = "issueType";
        roles[IMPORTED] = "imported";
        roles[WOS] = "wos";
        roles[STATUS] = "status";
        roles[PROJECTCODE] = "projectCode";
    }
    return roles;
}

QVariant JiraListModel::data(const QModelIndex &index, int role) const
{
    QVariant res;
    JiraIssue *issue = _issues.value(index.row());
    if (role == KEY) {
        res = QVariant::fromValue(issue->key());
    } else if (role == SUMMARY) {
        res = QVariant::fromValue(issue->summary());
    } else if (role == PRIORITY) {
        res = QVariant::fromValue(issue->priority());
    } else if (role == DESCRIPTION) {
        res = QVariant::fromValue(issue->description());
    } else if (role == TYPE) {
        res = QVariant::fromValue(issue->type());
    } else if (role == IMPORTED) {
        res = QVariant::fromValue(_importados.value(issue->key()));
    } else if (role == WOS) {
        QVariantMap map;
        QMap<QString, int> wos = issue->wos();
        for (auto key : wos.keys()) {
            map[key] = QVariant::fromValue(wos.value(key));
        }
        res = map;
    } else if (role == STATUS) {
        JiraIssue::EstadoJira st = issue->estado();
        QString statusStr = "";
        switch (st) {
            case JiraIssue::ESTADO_INPROGRESS: {
                statusStr = "En progreso";
                break;
            }
            case JiraIssue::ESTADO_RESUELTO: {
                statusStr = "Resueltos";
                break;
            }
            case JiraIssue::ESTADO_SINRESOLVER: {
                statusStr = "Sin resolver";
                break;
            }
            default:
                statusStr = "Unknown";
        }
        res = QVariant::fromValue(statusStr);
    } else if (role == PROJECTCODE) {
        res = QVariant::fromValue(issue->projectCode());
    }
    return res;
}

int JiraListModel::rowCount(const QModelIndex &) const
{
    return _issues.size();
}

void JiraListModel::fetchMore(const QModelIndex &)
{
    _api->pedirJiras(_lastKey, _lastAssigned, _issues.size());
}

bool JiraListModel::canFetchMore(const QModelIndex &) const
{
    return (_issues.size() < _total);
}

void JiraListModel::clearModel()
{
    beginResetModel();
    for (auto ind : _issues.keys()) {
        JiraIssue *issue = _issues.take(ind);
        delete issue;
    }
    _issues.clear();
    _importados.clear();
    _total = 0;
    _lastKey = "";
    _lastAssigned = "";
    _lastError = "";
    endResetModel();
}

void JiraListModel::loadModel()
{
    setState(LOADING);
    clearModel();
    _api->pedirJiras("", "");
}

void JiraListModel::applyFilters(const QString &filtroKey, const QString &filtroAsignado)
{
    setState(LOADING);
    clearModel();
    _lastKey = filtroKey;
    _lastAssigned = filtroAsignado;
    _api->pedirJiras(filtroKey, filtroAsignado);
}

JiraListModel::ModelState JiraListModel::state() const
{
    return _state;
}

void JiraListModel::setState(ModelState state)
{
    if (_state != state) {
        _state = state;
        Q_EMIT(stateChanged());
    }
}

void JiraListModel::slotNewJiras(int firstIndex, int total, QList<JiraIssue*> issues)
{
    qDebug() << "JiraListModel::slotNewJiras: firstInd " << firstIndex
             << ", total " << total << ", jiras " << issues.size();
    setState(LOADED);
    _total = total;
    beginInsertRows(QModelIndex(), firstIndex, firstIndex + issues.size() - 1);
    for (int ind = firstIndex; !issues.isEmpty(); ind++) {
        JiraIssue *issue = issues.takeAt(0);
        _issues[ind] = issue;
        _importados[issue->key()] = _taskStore->existsTaskWithCode(issue->key());
    }
    endInsertRows();
}

void JiraListModel::slotError(const QString &errorMsg)
{
    qDebug() << "JiraListModel::slotError";
    setState(ERROR);
    setErrorMsg(errorMsg);
}

QString JiraListModel::errorMsg() const
{
    return _lastError;
}

void JiraListModel::setErrorMsg(const QString &msg)
{
    if (_lastError != msg) {
        _lastError = msg;
        Q_EMIT(errorMsgChanged());
    }
}
