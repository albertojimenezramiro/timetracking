/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 30 mar. 2019
**
****************************************************************************/

#ifndef SRC_RED_JIRAISSUE_H_
#define SRC_RED_JIRAISSUE_H_

#include <QString>
#include <QUrl>
#include <QMap>

class JiraIssue {
public:
    typedef enum EstadoJira {
        ESTADO_SINRESOLVER,
        ESTADO_INPROGRESS,
        ESTADO_RESUELTO
    } EstadoJira;


    JiraIssue();
    virtual ~JiraIssue();

    QString key() const;
    void setKey(QString key);
    QString summary() const;
    void setSummary(QString sum);
    QString description() const;
    void setDescription(QString desc);
    QUrl priority() const;
    void setPriority(QUrl url);
    QUrl type() const;
    void setType(QUrl url);
    QMap<QString, int> wos() const;
    void setWos(QMap<QString, int> wos);
    EstadoJira estado() const;
    void setEstado(EstadoJira estado);
    QString projectCode() const;
    void setProjectCode(const QString &p);

private:
    QString _key;
    QString _summary;
    QString _description;
    QUrl _priority;
    QUrl _type;
    QMap<QString, int> _wos;
    EstadoJira _estado;
    QString _projectCode;
};

#endif /* SRC_RED_JIRAISSUE_H_ */
