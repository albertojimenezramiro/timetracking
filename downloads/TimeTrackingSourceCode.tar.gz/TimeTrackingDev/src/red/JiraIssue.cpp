/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 30 mar. 2019
**
****************************************************************************/

#include "JiraIssue.h"

JiraIssue::JiraIssue() : _estado(ESTADO_SINRESOLVER)
{}

JiraIssue::~JiraIssue() {}

QString JiraIssue::key() const
{
    return _key;
}

void JiraIssue::setKey(QString key)
{
    _key = key;
}

QString JiraIssue::summary() const
{
    return _summary;
}

void JiraIssue::setSummary(QString sum)
{
    _summary = sum;
}

QString JiraIssue::description() const
{
    return _description;
}

void JiraIssue::setDescription(QString desc)
{
    _description = desc;
}

QUrl JiraIssue::priority() const
{
    return _priority;
}

void JiraIssue::setPriority(QUrl url)
{
    _priority = url;
}

QUrl JiraIssue::type() const
{
    return _type;
}

void JiraIssue::setType(QUrl url)
{
    _type = url;
}

QMap<QString, int> JiraIssue::wos() const
{
    return _wos;
}

void JiraIssue::setWos(QMap<QString, int> wos)
{
    _wos = wos;
}

JiraIssue::EstadoJira JiraIssue::estado() const
{
    return _estado;
}

void JiraIssue::setEstado(EstadoJira estado)
{
    _estado = estado;
}

QString JiraIssue::projectCode() const
{
    return _projectCode;
}
void JiraIssue::setProjectCode(const QString &p)
{
    _projectCode = p;
}
