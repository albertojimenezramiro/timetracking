/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 29 mar. 2019
**
****************************************************************************/

#include "JiraApi.h"
#include <QNetworkAccessManager>
#include <QObject>
#include <QNetworkRequest>
#include <QUrlQuery>
#include <QtGlobal>
#include "TTSettings.h"
#include <QJsonDocument>
#include <QJsonParseError>
#include <QJsonObject>
#include <QJsonArray>
#include <QRegularExpression>
#include <QRegularExpressionMatch>
#include <QMetaObject>

JiraApi::JiraApi(QNetworkAccessManager *networkManager, TTSettings *settings, QObject *parent) :
    QObject(parent),
    _networkManager(networkManager),
    _settings(settings),
    _requestId(0)
{
}

JiraApi::~JiraApi()
{
}

QString JiraApi::paramJql(const QString &key, const QString &asignado) const
{
    QString keyF = key.isEmpty() ? "" : "key=" + key;
    QString asigF = asignado.isEmpty() ? "" : "assignee=" + asignado;
    QString jql = "assignee=currentUser() AND resolution=Unresolved ORDER BY priority";
    if (!key.isEmpty() || !asignado.isEmpty()) {
        jql = "";
        if (!key.isEmpty()) {
            jql = keyF;
        }
        if (!asignado.isEmpty()) {
            if (jql.isEmpty()) {
                jql = asigF;
            } else {
                jql += " AND " + asigF;
            }
        }
        if (key.isEmpty()) {
            jql += " AND resolution=Unresolved";
        }
        jql += " ORDER BY priority";
    }
    return jql;
}

bool JiraApi::headerAuthorization(QByteArray &auth, QString &errorMsg) const
{
    bool success = true;
    if (_settings->usuarioJira().isEmpty()) {
        qWarning() << "Error: La preferencia del username de Jira está vacía";
        errorMsg = "usuario de jira no configurado en preferencias";
        success = false;
    }
    if (_settings->tokenJira().isEmpty()) {
        qWarning() << "Error: La preferencia del username de Jira está vacía";
        errorMsg = "token de jira no configurado en preferencias";
        success = false;
    }
    if (success) {
        auth = _settings->usuarioJira().toUtf8() + ":" + _settings->tokenJira().toUtf8();
        auth = auth.toBase64();
        auth = QString("Basic ").toUtf8() + auth;
    }
    return success;
}

void JiraApi::pedirJiras(const QString &key, const QString &asignado, const int firstIndex)
{
    QNetworkRequest request;
    QString jiraUrl = _settings->urlJira();
    if (jiraUrl.isEmpty()) {
        Q_EMIT(error("URL de jira no configurada en preferencias (ej: https://xxxx.atlassian.net)"));
        qWarning() << "Error: La preferencia de la url de Jira está vacía";
    } else {
        QUrl url(jiraUrl + (jiraUrl.endsWith("/") ? "" : "/") + "rest/api/3/search");
        QUrlQuery params;
        params.addQueryItem("jql", paramJql(key, asignado));
        params.addQueryItem("fields", "issuetype,summary,description,key,priority,customfield_11700,status,resolution");
        params.addQueryItem("validateQuery", "strict");
        if (firstIndex > 0) {
            params.addQueryItem("startAt", QString::number(firstIndex));
        }
        url.setQuery(params);
        QByteArray auth;
        QString errorMsg = "";
        bool hasAuth = headerAuthorization(auth, errorMsg);
        qDebug() << "JiraApi::pedirJiras: " << key << ", " << asignado
                << ", firstInd " << firstIndex << " " << url.toString() << ", hasAuth "
                << hasAuth << ", requestId " << _requestId;
        if (hasAuth) {
            request.setUrl(url);
            request.setRawHeader("User-Agent", "TimeTracking");
            request.setRawHeader("Authorization", auth);

            QNetworkReply *reply = _networkManager->get(request);
            ++_requestId;
            reply->setProperty("rid", _requestId);
            qDebug() << "JiraApi::pedirJiras: reply " << reply << ", rid " << _requestId
                    << ", isFinished " << reply->isFinished() << ", isRunning " << reply->isRunning()
                    << ", error " << reply->error();
            connect(reply, &QNetworkReply::finished, this, &JiraApi::slotFinished, Qt::UniqueConnection);
            connect(reply, QOverload<QNetworkReply::NetworkError>::of(&QNetworkReply::error),
                    this, &JiraApi::slotError, Qt::UniqueConnection);
            connect(reply, &QNetworkReply::sslErrors, this, &JiraApi::slotSslErrors, Qt::UniqueConnection);
        } else {
            Q_EMIT(error(errorMsg));
        }
    }
}

void JiraApi::slotSslErrors(const QList<QSslError> &errors)
{
    qDebug() << "JiraApi::slotSslErrors "<<errors << "; sender " << sender();
    if (sender()) {
        sender()->deleteLater();
    }
}
void JiraApi::slotFinished()
{
    QNetworkReply *reply = static_cast<QNetworkReply*>(sender());
    int rid = reply->property("rid").toInt();
    qDebug() << "JiraApi::slotFinished: requestId " << rid << " " << _requestId << ", reply " << reply;
    if (rid == _requestId && reply->error() == QNetworkReply::NoError) {
        QByteArray ba(reply->readAll());
        qDebug() << "JiraApi::slotFinished: respuesta tiene " << ba.size() << " bytes";
        QJsonParseError jsonError;
        QJsonDocument doc = QJsonDocument::fromJson(ba, &jsonError);
        if (jsonError.error == QJsonParseError::NoError) {
            parsearJiras(doc.object());
        } else {
            qWarning() << "Error " << jsonError.error << " en el json: " << jsonError.errorString();
            QString msg = "Error en la respuesta: parse error " + QString::number(jsonError.error) + " - " + jsonError.errorString();
            Q_EMIT(error(msg));
        }
        qDebug() << "JiraApi::slotFinished: "<<ba;
        _requestId = 0;
    }
    if (sender()) {
        sender()->deleteLater();
    }
}
void JiraApi::slotError(QNetworkReply::NetworkError nerror)
{
    qDebug() << "JiraApi::slotError: "<<nerror << ", sender " << sender();
    QNetworkReply *reply = static_cast<QNetworkReply*>(sender());
    QString msg = "Network error " + QString::number(nerror) + (reply ? (": " + reply->errorString()) : "");
    Q_EMIT(error(msg));
    if (sender()) {
        sender()->deleteLater();
    }
}

void JiraApi::parsearJiras(QJsonObject rootObject)
{
    int firstIndex = rootObject.value("startAt").toInt();
    int totalJiras = rootObject.value("total").toInt();
    QList<JiraIssue*> issueList;
    QJsonArray issues = rootObject.value("issues").toArray();
    for (auto issueJson : issues) {
        QJsonObject issueObj = issueJson.toObject();
        QString key = issueObj.value("key").toString();
        QJsonObject fields = issueObj.value("fields").toObject();
        QString summary = fields.value("summary").toString();
        QString priorityUrl = fields.value("priority").toObject().value("iconUrl").toString();
        QString typeUrl = fields.value("issuetype").toObject().value("iconUrl").toString();
        QString description = parsearDescription(fields.value("description").toObject());
        QString statusStr = fields.value("status").toObject().value("name").toString().toLower();
        QJsonValue resolution = fields.value("resolution");
        QString resolutionStr = resolution.isNull() || resolution.isUndefined() ? "" :
                    resolution.toObject().value("name").toString("").toLower();
        QString proj = parseProject(key);

        QMap<QString, int> wos = parsearWos(fields.value("customfield_11700").toString());
        JiraIssue *issue = new JiraIssue();
        issue->setDescription(description);
        issue->setKey(key);
        issue->setPriority(QUrl(priorityUrl));
        issue->setType(QUrl(typeUrl));
        issue->setSummary(summary);
        issue->setWos(wos);
        issue->setEstado(parsearEstado(statusStr, resolutionStr));
        issue->setProjectCode(proj);
        issueList << issue;
    }
    issueList = adelantarInProgress(issueList);
    qDebug() << "JiraApi::parsearJiras: issues " << issueList.size()
             << ", firstIndex " << firstIndex << ", total " << totalJiras;
    Q_EMIT(newJiras(firstIndex, totalJiras, issueList));
}

QString JiraApi::parsearDescription(QJsonObject obj)
{
    QString desc = "";
    QJsonArray content = obj.value("content").toArray();
    for (auto elem : content) {
        QJsonArray para = elem.toObject().value("content").toArray();
        for (auto text : para) {
            QJsonObject textObj = text.toObject();
            if (textObj.value("type").toString() == "text") {
                desc += (textObj.value("text").toString() + "\n");
            }
        }
        desc += "\n";
    }
    return desc;
}

QMap<QString, int> JiraApi::parsearWos(QString wosStr)
{
    QMap<QString, int> map;
    wosStr = wosStr.trimmed();
    QStringList toks = wosStr.split(' ', QString::SkipEmptyParts);
    QRegularExpression woExpr1("\\d{5,5}"),
                       woExpr2("\\d{5,5}-\\d{3,3}"),
                       porcentaje("\\d{1,3}%");
    if (toks.size() == 1) {
        QString str = toks.first();
        QRegularExpressionMatch m1 = woExpr1.match(str),
                                m2 = woExpr2.match(str),
                                pe = porcentaje.match(str);

        if (m1.hasMatch() || m2.hasMatch()) {
            QString wo = m2.hasMatch() ? m2.captured(0) : m1.captured(0);
            map[wo] = 100;
        }
    } else {
        QStringList woPending;
        QString lastWo;
        for (auto str : toks) {
            QRegularExpressionMatch m1 = woExpr1.match(str),
                                    m2 = woExpr2.match(str),
                                    pe = porcentaje.match(str);
            QString percent;
            QString possibleWo;
            if (m1.hasMatch() || m2.hasMatch()) {
                possibleWo = m2.hasMatch() ? m2.captured(0) : m1.captured(0);
                qDebug()<<"match wo "<<possibleWo;
            } else if (pe.hasMatch()) {
                percent = pe.captured(0);
                qDebug() << "match % "<<percent;
            }
            if (!possibleWo.isEmpty()) {
                if (!lastWo.isEmpty()) {
                    woPending << lastWo;
                }
                lastWo = possibleWo;
            } else if (!percent.isEmpty()) {
                if (!lastWo.isEmpty()) {
                    int perc = percent.left(percent.length()-1).toInt();
                    map[lastWo] = perc;
                    lastWo = "";
                }
            }
            possibleWo = "";
            percent = "";
        }
        if (woPending.size() > 0) {
            int resto = 100;
            for (auto key : map.keys()) {
                resto -= map.value(key);
            }
            int cadaUno = resto / woPending.size();
            for (auto wo : woPending) {
                map[wo] = cadaUno;
            }
        }
    }
    return map;
}

QList<JiraIssue*> JiraApi::adelantarInProgress(QList<JiraIssue*> original)
{
    QList<JiraIssue*> inProgress, resto;
    for (auto jira : original) {
        if (jira->estado() == JiraIssue::ESTADO_INPROGRESS) {
            inProgress << jira;
        } else {
            resto << jira;
        }
    }
    QList<JiraIssue*> final;
    final.append(inProgress);
    final.append(resto);
    return final;
}

JiraIssue::EstadoJira JiraApi::parsearEstado(const QString &estado, const QString &resolucion)
{
    JiraIssue::EstadoJira st = JiraIssue::ESTADO_SINRESOLVER;
    if (resolucion != "" && resolucion != "unresolved") {
        st = JiraIssue::ESTADO_RESUELTO;
    } else {
        st = estado == "in progress" ? JiraIssue::ESTADO_INPROGRESS : JiraIssue::ESTADO_SINRESOLVER;
    }
    return st;
}

QString JiraApi::parseProject(const QString &key)
{
    QStringList tokens = key.split("-");
    return tokens.isEmpty() ? "" : tokens.value(0);
}
