/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 29 mar. 2019
**
****************************************************************************/

#ifndef SRC_RED_JIRAAPI_H_
#define SRC_RED_JIRAAPI_H_

#include <qobject.h>
#include <QSslError>
#include <QNetworkReply>
#include <QSslError>
#include "JiraIssue.h"

class QNetworkAccessManager;
class TTSettings;

class JiraApi: public QObject {
    Q_OBJECT
public:
    JiraApi(QNetworkAccessManager *networkManager, TTSettings *settings, QObject *parent);
    virtual ~JiraApi();

    void pedirJiras(const QString &key, const QString &asignado, const int firstIndex = 0);

Q_SIGNALS:
    void newJiras(int firstIndex, int total, QList<JiraIssue*> issues);
    void error(const QString &errorMsg);

private Q_SLOTS:
    void slotSslErrors(const QList<QSslError> &errors);
    void slotFinished();
    void slotError(QNetworkReply::NetworkError nerror);

private:
    void parsearJiras(QJsonObject rootObject);
    QString parsearDescription(QJsonObject obj);
    QMap<QString, int> parsearWos(QString wosStr);
    QString paramJql(const QString &key, const QString &asignado) const;
    bool headerAuthorization(QByteArray &auth, QString &errorMsg) const;
    QList<JiraIssue*> adelantarInProgress(QList<JiraIssue*> original);
    JiraIssue::EstadoJira parsearEstado(const QString &estado, const QString &resolucion);
    QString parseProject(const QString &key);

    QNetworkAccessManager *_networkManager;
    TTSettings *_settings;
    int _requestId;
};

#endif /* SRC_RED_JIRAAPI_H_ */
