/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 19 nov. 2018
**
****************************************************************************/

#ifndef SRC_RELOJ_H_
#define SRC_RELOJ_H_

#include <qobject.h>
#include <QDateTime>
#include <QDate>
#include <QTime>
#include <QTimer>

class Reloj: public QObject {
    Q_OBJECT
    Q_PROPERTY(QDateTime time READ currentTime NOTIFY currentTimeChanged)
    Q_PROPERTY(QDateTime date READ currentDateSlot NOTIFY currentTimeChanged)

public:
    static Reloj *instance();
    virtual ~Reloj();

    static QDateTime currentDateTime();
    static QDate currentDate();
    //static QTime currentTime() const;

public Q_SLOTS:
    QDateTime currentTime() const;
    QDateTime currentDateSlot() const;

Q_SIGNALS:
    void currentTimeChanged();

private Q_SLOTS:
    void processTimeChange();

private:
    Reloj();
    Reloj(const QDateTime &base, const int &intervalo, const int &frecuencia);

    QDateTime currentFakedTime() const;

    static Reloj *_instance;
    QTimer _timer;

    QDateTime _currentTime, _startup;
    int _programSecsPerRealSec;
    int _pollFreq;
};

#endif /* SRC_RELOJ_H_ */
