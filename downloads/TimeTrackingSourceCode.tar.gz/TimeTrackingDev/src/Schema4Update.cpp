/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 6 oct 2023
**
****************************************************************************/

#include "Schema4Update.h"
#include <QDebug>
#include <QSqlRecord>
#include <QSqlTableModel>
#include <QSqlQuery>
#include <QDateTime>
#include <QElapsedTimer>

Schema4Update::Schema4Update()
{
}

Schema4Update::~Schema4Update()
{
}

void Schema4Update::checkWorkOrders()
{
    QSqlTableModel woModel;
    woModel.setTable("wos");
    woModel.select();
    qDebug() << "updateSchemaToVersion4: " << woModel.rowCount() << " entradas en tabla wos";
    QSqlTableModel workOrderModel;
    workOrderModel.setTable("workorders");
    int woIndex = 0;
    bool canFetch = true;
    int fixed = 0;
    int woCreated = 0;
    QHash<QString, int> creationTimesByCode;
    QHash<QString, int> archiveTimesByCode;
    QHash<QString, int> idsByCode;
    qint64 sum = 0;
    qint64 creates = 0;
    while (canFetch) {
        while (woIndex <  woModel.rowCount()) {
            QElapsedTimer t; t.start();
            QString woCode = woModel.data(woModel.index(woIndex, 2, QModelIndex())).toString();
            //int idTarea = woModel.data(woModel.index(woIndex, 1, QModelIndex())).toInt();
            int id = woModel.data(woModel.index(woIndex, 0, QModelIndex())).toInt();
            if (woCode.size() > 0) { // solo corregimos las entradas con work order válida (deberían ser todas aquí)
                int idWorkOrder = idsByCode.value(woCode, -1);
                // buscamos la woCode en la nueva tabla de work orders
                if (idWorkOrder == -1) {
                    bool created = false;
                    QElapsedTimer t2; t2.start();
                    idWorkOrder = tryCreateWorkOrderEntry(woCode, created);
                    creates+=t2.elapsed();
                    idsByCode.insert(woCode, idWorkOrder);
                    if (created) {
                        woCreated++;
                    }
                }
                modifyWoEntry(id, idWorkOrder); // modificamos la tabla wos poniendo la entrada en el nuevo formato
                fixed++;
            }
            qDebug() << "procesado de entrada wo "<<t.elapsed();
            sum += t.elapsed();
            woIndex++;
        }
        //qDebug() << "updateSchemaToVersion4: fin tabla wos. can "<<woModel.canFetchMore();
        if (woModel.canFetchMore()) {
            woModel.fetchMore();
            canFetch = true;
        } else {
            canFetch = false;
        }
    }
    qDebug() << "updateSchemaToVersion4: " << fixed << " entradas corregidas en tabla wos. "
             << woCreated << " work orders creadas. "<<sum<<". creates "<<creates;
}

int Schema4Update::tryCreateWorkOrderEntry(const QString &woCode, bool &created)
{
    int idWorkOrder = -1;
    QSqlTableModel workOrderModel;
    workOrderModel.setTable("workorders");
    workOrderModel.setFilter("code = '"+woCode+"'");
    workOrderModel.select();
    if (workOrderModel.rowCount() == 0) {
        // no existe una work order con ese código. La creamos nueva
        qint64 creationTime, archiveDate;
        // algunos de sus datos dependerán de sus tareas:
        // fecha de creación: la de creación de su primera tarea
        // fecha de archivo: la de su última tarea archivada. Si todas están archivadas,
        //                   la work order queda archivada. Si alguna no lo está, quedará abierta.
        extractWorkOrderData(woCode, creationTime, archiveDate);
        QSqlRecord newRecord = workOrderModel.record();
        newRecord.setValue(1, woCode); // usamos el code como nombre también
        newRecord.setValue(2, woCode);
        newRecord.setValue(3, creationTime);
        newRecord.setValue(4, -1);
        newRecord.setValue(5, "");
        newRecord.setValue(6, QVariant(archiveDate));
        workOrderModel.insertRecord(-1, newRecord);
        workOrderModel.submitAll();
        // y ahora sacamos el id de la work order creada
        workOrderModel.setFilter("creationtime = " + QString::number(creationTime));
        workOrderModel.setSort(0, Qt::DescendingOrder);
        workOrderModel.select();
        idWorkOrder = workOrderModel.data(workOrderModel.index(0, 0, QModelIndex())).toInt();
        /*qDebug() << "updateSchemaToVersion4: creamos work order con creacion " << QDateTime::fromMSecsSinceEpoch(creationTime)
                                 << " y archivo " << QDateTime::fromMSecsSinceEpoch(archiveDate) << " - id " << idWorkOrder;*/
        created = true;;
    } else {
        // ya existe una work order con ese código. La reutilizamos
        idWorkOrder = workOrderModel.data(workOrderModel.index(0, 0, QModelIndex())).toInt();
        //qDebug() << "updateSchemaToVersion4: reutilizamos work order " << idWorkOrder;
    }
    return idWorkOrder;
}

void Schema4Update::modifyWoEntry(int id, int idWorkOrder)
{
    QSqlTableModel woModel;
    woModel.setTable("wos");
    woModel.setFilter("id = " + QString::number(id));
    woModel.select();
    woModel.setData(woModel.index(0, 4), idWorkOrder, Qt::EditRole);
    // borramos el antiguo campo con el código de la wo a pelo
    woModel.setData(woModel.index(0, 2), "", Qt::EditRole);
    woModel.submitAll();
}

void Schema4Update::extractWorkOrderData(const QString &workOrder, qint64 &workOrderCreationTime, qint64 &workOrderArchiveDate)
{
    /*
     * usaremos este método para saber los datos necesarios para crear una work order nueva a partir
     * de sus tareas. Sacaremos su fecha de creación a partir de la creación de la primera tarea que
     * tuvo esa work order; sacaremos si debe estar archivada o no sabiendo si todas las tareas con
     * esa work order están cerradas; sacaremos la fecha de archivo a partir de la fecha de cierre
     * de la última tarea.
     */
    QSqlTableModel woModel;
    // iteramos por todas las tareas con la misma work order
    woModel.setTable("wos");
    woModel.setFilter("wo = '"+workOrder+"'");
    woModel.select();
    int firstTaskId = -1; qint64 firstTaskCreationTime = 9999999999999;
    int lastTaskId = -1; qint64 lastTaskArchiveDate = 0;

    int woIndex = 0;
    bool canFetch = true;
    while (canFetch) {
        while (woIndex <  woModel.rowCount()) {
            int idTarea = woModel.data(woModel.index(woIndex, 1, QModelIndex())).toInt();
            // para cada una de las tareas sacamos su fecha de creación y de archivo
            qint64 creationTime, archiveDate;
            extractTaskData(idTarea, creationTime, archiveDate);

            // nos quedamos con la fecha de creación más tempranera y la de archivo más tardía
            if (firstTaskId == -1 || creationTime < firstTaskCreationTime) {
                firstTaskId = idTarea;
                firstTaskCreationTime = creationTime;
            }
            if (lastTaskId == -1 || archiveDate > lastTaskArchiveDate) {
                lastTaskId = idTarea;
                lastTaskArchiveDate = archiveDate;
            }
            woIndex++;
        }
        if (woModel.canFetchMore()) {
            woModel.fetchMore();
            canFetch = true;
        } else {
            canFetch = false;
        }
    }
    // la fecha de creación de la work order será la de creación de su tarea más tempranera
    workOrderCreationTime = firstTaskCreationTime;
    workOrderArchiveDate = lastTaskArchiveDate;
}

void Schema4Update::extractTaskData(int taskId, qint64 &taskCreationTime, qint64 &taskArchiveDate)
{
    QSqlTableModel taskModel;
    // sacamos los datos de una task concreta
    taskModel.setTable("tareas");
    taskModel.setFilter("id = "+QString::number(taskId));
    taskModel.select();
    if (taskModel.rowCount() > 0) {
        taskModel.data(taskModel.index(0, 1, QModelIndex())).toInt();
        taskArchiveDate = taskModel.data(taskModel.index(0, 4, QModelIndex())).toLongLong();
        taskCreationTime = taskModel.data(taskModel.index(0, 5, QModelIndex())).toLongLong();
    }
}
