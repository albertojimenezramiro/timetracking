/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 30 oct 2023
**
****************************************************************************/

#include "ProjectStore.h"
#include <QDebug>
#include <QSqlTableModel>
#include <QSqlRecord>
#include <QSqlError>
#include "Project.h"
#include "Reloj.h"
#include <QVariant>

const qint64 ProjectStore::_defaultArchiveTimestamp = 9999999999999;

ProjectStore::ProjectStore(QObject* parent) :
    QObject(parent),
    _model(nullptr),
    _last(nullptr)
{
    qRegisterMetaType<ProjectStore::ProjectNotifications>();
}

ProjectStore::~ProjectStore()
{
    if (_model) {
        _model->deleteLater();
    }
}

void ProjectStore::initialize()
{
    _model = new QSqlTableModel(this);
    _model->setTable("projects");
}

Project *ProjectStore::projectFactoryMethod(int id, const QString &name, const QString &desc, const QString &code, const QString &client)
{
    Project *p = new Project(id, name, desc, code, client);
    return p;
}

Project *ProjectStore::project(int id, bool loadFromDb)
{
    Project *p = _projects.value(id, nullptr);
    if (loadFromDb && p == nullptr) {
        qDebug() << "ProjectStore::project: haciendo select con id " << id;
        selectProject(id);
        p = cacheSelected();
    }
    return p;
}

Project *ProjectStore::last() const
{
    return _last;
}

void ProjectStore::selectProject(int id)
{
    _model->setFilter("id = " + QString::number(id));
    _model->select();
}

void ProjectStore::selectProjects(const QString &pattern)
{
    // para la búsqueda de sugerencias
    QString filterClause = "(name LIKE '%"+pattern+"%' OR code LIKE '%"+pattern+"%' OR client LIKE '%" + pattern + "%')";
    filterClause = "archivetimestamp = " + QString::number(_defaultArchiveTimestamp) + " AND " + filterClause;
    _model->setFilter(filterClause);
    _model->select();
}

Project *ProjectStore::cacheSelected()
{
    return cacheSelected(0);
}

Project *ProjectStore::cacheSelected(int rowIndex)
{
    Project *proj = nullptr;
    if (_model->rowCount() > 0) {
        int id = sqlData(rowIndex, PROJECT_ID).toInt();
        QString name = sqlData(rowIndex, PROJECT_NAME).toString();
        QString desc = sqlData(rowIndex, PROJECT_DESCRIPTION).toString();
        QString cod = sqlData(rowIndex, PROJECT_CODE).toString();
        QString client = sqlData(rowIndex, PROJECT_CLIENT).toString();
        qlonglong llarchived = sqlData(rowIndex, PROJECT_ARCHIVEDATE).toLongLong();
        QDateTime archived = QDateTime::fromMSecsSinceEpoch(llarchived);
        proj = projectFactoryMethod(id, name, desc, cod, client);
        proj->setArchiveDate(archived);
        qDebug() << "ProjectStore::cacheSelected: index " << rowIndex << ", proyectId: "<< id << " " << name << " "
                << cod << " " << archived << " " << llarchived << " " << desc;
        _projects.insert(id, proj);
    } else {
        qCritical() << "ProjectStore::cacheSelected: error al parsear. el modelo solo tiene "
                    << _model->rowCount();
    }
    return proj;
}

QVariant ProjectStore::sqlData(int rowIndex, ProjectStore::ProjectFields column)
{
    QModelIndex ind = _model->index(rowIndex, column, QModelIndex());
    return _model->data(ind);
}

void ProjectStore::createProjectFromData(const QString &name, const QString &code, const QString &description, const QString &client, qint64 creationTime, qint64 archiveTime)
{
    QSqlRecord newRecord = _model->record();
    newRecord.setValue(PROJECT_NAME, name);
    newRecord.setValue(PROJECT_CODE, code);
    newRecord.setValue(PROJECT_CREATIONTIME, creationTime);
    newRecord.setValue(PROJECT_CLIENT, client);
    newRecord.setValue(PROJECT_DESCRIPTION, description);
    newRecord.setValue(PROJECT_ARCHIVEDATE, QVariant(archiveTime));
    _model->insertRecord(-1, newRecord);
    qDebug()<< "ProjectStore::createNewProject: "<<newRecord<<". lastError " << _model->lastError();
    _model->submitAll();
    // already created in db. Now, we select it and build into memory, with the correct id
    _model->setFilter("creationtime = " + QString::number(creationTime));
    _model->select();
    qDebug() << "ProjectStore::createProjectFromData: creado " << _model->rowCount();
    _last = cacheSelected();
}
void ProjectStore::createNewProject()
{
    qint64 creationTime = Reloj::instance()->currentTime().toMSecsSinceEpoch();
    int lastIndex = _projects.isEmpty() ? 1 : (_projects.keys().last() + 1);
    QString name = QString("Nuevo proyecto ") + QString::number(lastIndex);
    createProjectFromData(name, "", "", "", creationTime, _defaultArchiveTimestamp);
    Q_EMIT(projectNotification(PROJECTNOTIF_NEW, _last->id()));
}

void ProjectStore::archiveProject(int id)
{
    // asignamos fecha de cierre, hacemos el select en el modelo de db y entonces cambiamos el
    // campo y hacemos submit
    Project *proj = project(id, false);
    qDebug() << "ProjectStore::archiveProject: id " << id;
    if (proj) {
        QDateTime archiveDate = Reloj::currentDateTime();
        if (updateArchiveDateInDb(id, archiveDate)) {
            _last = proj;
            proj->setArchiveDate(archiveDate);
            Q_EMIT(projectNotification(PROJECTNOTIF_ARCHIVED, id));
        } else {
            qCritical() << "Error al actualizar el archiveDate del proyecto con id " << id;
        }
    }
}

void ProjectStore::reopenProject(int id)
{
    // asignamos fecha de cierre, hacemos el select en el modelo de db y entonces cambiamos el
    // campo y hacemos submit
    Project *proj = project(id, false);
    if (proj) {
        QDateTime defaultArchiveDate = QDateTime::fromMSecsSinceEpoch(_defaultArchiveTimestamp);
        if (updateArchiveDateInDb(id, defaultArchiveDate)) {
            _last = proj;
            proj->setArchiveDate(defaultArchiveDate);
            Q_EMIT(projectNotification(PROJECTNOTIF_REOPEN, id));
        } else {
            qCritical() << "Error al actualizar el archiveDate del proyecto con id " << id;
        }
    }
}

bool ProjectStore::updateArchiveDateInDb(int id, const QDateTime &archiveDate)
{
    selectProject(id);
    QVariant newField = QVariant::fromValue<qint64>(archiveDate.toMSecsSinceEpoch());
    qDebug() << "ProjectStore::updateArchiveDateInDb: id " << id << ", db rowcount " << _model->rowCount() << "; field " << newField << ", date " << archiveDate;
    QModelIndex index = _model->index(0, PROJECT_ARCHIVEDATE);
    _model->setData(index, newField, Qt::EditRole);
    return _model->submitAll();
}

bool ProjectStore::updateProjectDataInDb(int id, const QString &name, const QString &description, const QString &code, const QString &client)
{
    selectProject(id); //cargamos en el modelo de db el proyecto a editar
    qDebug() << "ProjectStore::updateProjectDataInDb: name " << name << ", code " << code << ", desc " << description;
    _model->setData(_model->index(0, PROJECT_NAME), QVariant::fromValue(name), Qt::EditRole);
    _model->setData(_model->index(0, PROJECT_CLIENT), QVariant::fromValue(client), Qt::EditRole);
    _model->setData(_model->index(0, PROJECT_DESCRIPTION), QVariant::fromValue(description), Qt::EditRole);
    _model->setData(_model->index(0, PROJECT_CODE), QVariant::fromValue(code), Qt::EditRole);
     bool res = _model->submitAll(); // guardamos los nuevos datos
     if (res) {
         // si se han guardado bien, cargamos los nuevos datos en memoria y notificamos
         Project *proj = project(id, true);
         if (proj) {
             proj->setName(name);
             proj->setDescription(description);
             proj->setCode(code);
             proj->setClient(client);
             _last = proj;
         }
         Q_EMIT(projectNotification(PROJECTNOTIF_UPDATEDATA, id));
     }
    return res;
}

QList<Project*> ProjectStore::suggestionsFor(const QString &pattern)
        {
    QList<Project*> results;
    selectProjects(pattern);
    int currentIndex = 0;
    while (currentIndex < _model->rowCount()) {
        int currentId = sqlData(currentIndex, PROJECT_ID).toInt();
        Project *currentProject = nullptr;
        if (_projects.contains(currentId)) {
            currentProject = project(currentId, false);
            results.append(currentProject);
        } else {
            currentProject = cacheSelected(currentIndex);
            results.append(currentProject);
        }
        if (currentIndex == _model->rowCount() - 1 && _model->canFetchMore()) {
            _model->fetchMore();
        }
        currentIndex++;
    }
    return results;
}

Project *ProjectStore::projectByCode(const QString &code)
{
    _model->setFilter("code = '" + code + "'");
    _model->select();
    int id = sqlData(0, PROJECT_ID).toInt();
    qDebug() << "ProjectStore::woByCode: haciendo select con code " << code << ": " << _model->rowCount() << " rows. first id " << id;
    return id > 0 ? project(id, true) : nullptr;
}

void ProjectStore::importProject(const QString &code)
{
    qint64 creationTime = Reloj::instance()->currentTime().toMSecsSinceEpoch();
    QString name = QString("Nuevo proyecto ") + code;
    createProjectFromData(name, code, "", "", creationTime, _defaultArchiveTimestamp);
    Q_EMIT(projectNotification(PROJECTNOTIF_IMPORTED, _last->id()));
}

