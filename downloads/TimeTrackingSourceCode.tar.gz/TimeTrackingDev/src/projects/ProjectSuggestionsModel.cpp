/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 1 nov 2023
**
****************************************************************************/

#include <QDebug>
#include "Project.h"
#include "ProjectSuggestionsModel.h"

ProjectSuggestionsModel::ProjectSuggestionsModel(QObject *parent) :
    QAbstractListModel(parent)
{
}

ProjectSuggestionsModel::~ProjectSuggestionsModel()
{
}

int ProjectSuggestionsModel::rowCount(const QModelIndex &) const
{
    return _list.size();
}

QVariant ProjectSuggestionsModel::data(const QModelIndex &modelIndex, int role) const
{
    int nrow = modelIndex.row();
    Project *p = _list.size() > nrow ? _list.value(nrow) : nullptr;
    if (p) {
        if (role == PROJSUGGESTION_ID) {
            return QVariant::fromValue(p->id());
        } else if (role == PROJSUGGESTION_NAME) {
            QString name = p->name().trimmed().isEmpty() ? "<proyecto sin nombre>" : p->name().trimmed();
            return QVariant::fromValue(name);
        } else if (role == PROJSUGGESTION_CODE) {
            return QVariant::fromValue(p->code());
        } else {
            return QVariant();
        }
    }
    return QVariant();
}

QHash<int, QByteArray> ProjectSuggestionsModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[PROJSUGGESTION_ID] = "projectId";
        roles[PROJSUGGESTION_NAME] = "name";
        roles[PROJSUGGESTION_CODE] = "code";
    }
    return roles;
}

bool ProjectSuggestionsModel::canFetchMore(const QModelIndex &) const
{
    return false;
}

void ProjectSuggestionsModel::fetchMore(const QModelIndex &)
{}

void ProjectSuggestionsModel::clearModel()
{
    beginResetModel();
    _list.clear();
    endResetModel();
    Q_EMIT(sizeChanged());
}

void ProjectSuggestionsModel::loadModel(QList<Project*> list)
{
    beginResetModel();
    _list = list;
    endResetModel();
    qDebug() << "ProjectSuggestionsModel::loadModel: cargando nueva lista de" << list.size() << " sugerencias";
    Q_EMIT(sizeChanged());
}

Project *ProjectSuggestionsModel::suggestionAt(int index)
{
    Project *res = nullptr;
    if (index < _list.size()) {
        res = _list.value(index);
    }
    return res;
}

Project * ProjectSuggestionsModel::suggestionExactMatch(const QString &pattern)
{
    int index = 0;
    Project * found = nullptr;
    bool matchedByCode = false;
    bool stopSearch = false;
    // buscamos proyectos por nombre y por código, pero tiene preferencia el nombre
    while (!stopSearch && index < _list.size()) {
        Project *p = _list.value(index);
        if (p->name().trimmed() == pattern) {
            found = p;
            stopSearch = true;
        } else if (p->code().trimmed().toLower() == pattern.toLower() && found == nullptr) {
            found = p;
        }
        if (found) {
            qDebug() << "ProjectSuggestionsModel::suggestionWithCode: encontrada sugerencia " << p->name();
        }
        index++;
    }
    return found;
}

int ProjectSuggestionsModel::size() const
{
    return _list.size();
}

