/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 30 oct 2023
**
****************************************************************************/

#ifndef SRC_PROJECTS_PROJECT_H_
#define SRC_PROJECTS_PROJECT_H_

#include <QString>
#include <QDateTime>

class Project {
public:
    Project();
    Project(const Project& w);
    Project(int id, const QString &name, const QString &desc, const QString code, const QString client);
    virtual ~Project();

    QString name() const;
    QString description() const;
    QString code() const;
    bool isArchived() const;
    int id() const;
    QString client() const;
    QDateTime archiveDate() const;

    void setName(const QString &name);
    void setDescription(const QString &desc);
    void setCode(const QString &code);
    void setArchiveDate(const QDateTime &archiveDate);
    void setClient(const QString &client);

private:
    int _id;
    QString _name;
    QString _description;
    QString _code;
    QString _client;
    bool _isArchived;
    QDateTime _archiveDate;
};

#endif /* SRC_PROJECTS_PROJECT_H_ */
