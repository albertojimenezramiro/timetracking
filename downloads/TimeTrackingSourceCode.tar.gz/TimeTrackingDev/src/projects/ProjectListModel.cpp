/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 30 oct 2023
**
****************************************************************************/

#include <QSqlTableModel>
#include <QDebug>
#include <QSqlRecord>
#include <QSqlError>
#include "Project.h"
#include "Reloj.h"
#include <qalgorithms.h>
#include "ProjectListModel.h"

ProjectListModel::ProjectListModel(QObject *parent, ProjectStore *store) :
    QAbstractListModel(parent),
    _databaseModel(nullptr),
    _store(store),
    _dbPageSize(50),
    _archiveThreshold(0)
{
}

ProjectListModel::~ProjectListModel()
{
    _databaseModel->clear();
    _databaseModel->deleteLater();
}

void ProjectListModel::initialize()
{
    _databaseModel = new QSqlTableModel();
}

int ProjectListModel::rowCount(const QModelIndex &) const
{
    return _list.size();
}

QVariant ProjectListModel::data(const QModelIndex &modelIndex, int role) const
{
    int nrow = modelIndex.row();
    Project *p = _list.value(nrow, nullptr);
    if (p) {
        if (role == PROJECTID) {
            return QVariant::fromValue(p->id());
        } else if (role == NAME) {
            return QVariant::fromValue(p->name());
        } else if (role == DESC) {
            return QVariant::fromValue(p->description());
        } else if (role == CODE) {
            return QVariant::fromValue(p->code());
        } else if (role == CLIENT) {
            return QVariant::fromValue(p->client());
        } else if (role == ARCHIVED) {
            int value = p->isArchived() ? 1 : 0;
            return QVariant::fromValue(value);
        } else {
            return QVariant();
        }
    }
    return QVariant();
}

QHash<int, QByteArray> ProjectListModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[PROJECTID] = "projectId";
        roles[NAME] = "name";
        roles[CODE] = "code";
        roles[CLIENT] = "client";
        roles[ARCHIVED] = "isArchived";
    }
    return roles;
}

bool ProjectListModel::canFetchMore(const QModelIndex &) const
{
    // si el modelo de db tiene más elementos fetcheados, claramente true
    // si tiene igual, le tendremos que preguntar si canFetchMore
    int numElems = _list.size();
    bool can = false;
    qDebug() << "ProjectListModel::canFetchMore: numElems " << numElems
             << ", rowCount del modelo de db " << _databaseModel->rowCount();
    if (numElems < _databaseModel->rowCount()) {
        can = true;
    } else {
        if (numElems == _databaseModel->rowCount()) {
            can = _databaseModel->canFetchMore();
        } else {
            qCritical() << "El modelo de wos no está alineado";
        }
    }
    qDebug() << "ProjectListModel::canFetchMore: " << can << ", " << this;
    return can;
}

void ProjectListModel::fetchMore(const QModelIndex &)
{
    int first = maxIndex() + 1;
    int last = first + (_dbPageSize-1);
    qDebug() << "ProjectListModel::canFetchMore: " << this << "; numElems "
             << first << ", rowCount db " << _databaseModel->rowCount();
    if (first < _databaseModel->rowCount()) {
        insertIntoListModel(first, last, true);
    } else {
        if (first == _databaseModel->rowCount()) {
            _databaseModel->fetchMore();
            insertIntoListModel(first, last, true);
        } else {
            qCritical() << "El modelo de tareas no está alineado";
        }
    }
    qDebug() << "ProjectListModel::canFetchMore: fetchMore terminado. fetcheados "
             << first << " -- " << last;
}

int ProjectListModel::maxIndex() const
{
    return _list.isEmpty() ? -1 : _list.size()-1;
}

QVariant ProjectListModel::sqlData(int i, ProjectStore::ProjectFields field)
{
    QModelIndex ind = _databaseModel->index(i, field, QModelIndex());
    return _databaseModel->data(ind);
}

void ProjectListModel::sqlSelect()
{
    _databaseModel->setTable("projects");
    _databaseModel->setSort(ProjectStore::PROJECT_ARCHIVEDATE, Qt::DescendingOrder);
    QDateTime threshold = Reloj::currentDateTime().addDays(-_archiveThreshold);
    qint64 llthreshold = threshold.toMSecsSinceEpoch();
    _databaseModel->setFilter("archivetimestamp > " + QString::number(llthreshold));
    _databaseModel->setEditStrategy(QSqlTableModel::OnManualSubmit);
    _databaseModel->select();
}



void ProjectListModel::clearModel(bool sendNotifications)
{
    if (sendNotifications) {
        beginResetModel();
    }
    _list.clear();
    _projectIndexes.clear();
    _databaseModel->clear();
    if (sendNotifications) {
        endResetModel();
    }
}

void ProjectListModel::loadModel(int archiveThreshold)
{
    qDebug() << "ProjectListModel::loadModel: " << archiveThreshold;
    beginResetModel();
    clearModel(false);
    _archiveThreshold = archiveThreshold;
    // cargamos el modelo de sql y metemos las primeras en este modelo
    qDebug() << "ProjectListModel::loadModel: comenzando carga del modelo de proyectos. ";
    sqlSelect();
    qDebug() << "cargado modelo DB de proyectos. count " << _databaseModel->rowCount() << ", " << this;
    if (_databaseModel->rowCount() > 0) {
        insertIntoListModel(0, _dbPageSize-1, false);
    }
    endResetModel();
}

void ProjectListModel::insertIntoListModel(int first, int last, bool signalInsertions)
{
    // como last nos quedamos con el más restrictivo entre el dado y el del modelo de sql
    int lastDef = last <= (_databaseModel->rowCount()-1) ? last : (_databaseModel->rowCount()-1);
    qDebug() << "ProjectListModel::insertIntoListModel: signalInsertions " << signalInsertions<<", beginInsertRows "
             << first << " " << lastDef;
    if (signalInsertions) {
        beginInsertRows(QModelIndex(), first, lastDef);
    }
    // insertamos nuestros nuevos elementos, se los pedimos al store
    for (int i = first; i <= lastDef; i++) {
        int id = sqlData(i, ProjectStore::PROJECT_ID).toInt();
        Project *pro = _store->project(id, true);
        qDebug() << "ProjectListModel::insertIntoListModel: index "<<i<<", id "<<id<<", "<<pro;
        if (pro) {
            int index = _list.size();
            if (i < _list.size()) {
                _list.insert(i, pro);
                index = i;
            } else {
                _list.append(pro);
            }
            _projectIndexes.insert(pro->id(), index);
        }
    }
    if (signalInsertions) {
        endInsertRows();
    }
}

void ProjectListModel::removeFromListModel(int first, int last)
{
    int lastIndex = last;
    if (last  >= _list.size()) {
        lastIndex = _list.size() - 1;
    }
    // vamos a borrar el intervalo first - lastIndex.
    qDebug() << "ProjectListModel::removeFromListModel: first " << first << ", last " << lastIndex;
    beginRemoveRows(QModelIndex(), first, lastIndex);
    int numToRemove = lastIndex - first + 1;
    for (int i = 0; i < numToRemove; i++) {
        Project *pro = _list.takeAt(first);
        _projectIndexes.remove(pro->id());
    }
    endRemoveRows();
}

void ProjectListModel::insertNewProject(int id)
{
    // primero cargamos de nuevo el modelo de base de datos y lo fetcheamos
    sqlSelect();
    int maxIndexInModel = maxIndex();
    fetchDbModelUntil(maxIndexInModel + 1); // vamos a insertar una nueva, que estará de las primeras
    qDebug() << "ProjectListModel::insertNewProject: id " << id << ", maxIndex " << maxIndexInModel
             << ", dbmodel tiene " << _databaseModel->rowCount();
    int index = searchForIndex(id, maxIndexInModel + 1);
    if (index >= 0) {
        insertIntoListModel(index, index, true);
    } else {
        qDebug() << "ProjectListModel::insertNewWorkOrder: no se insertará porque no está fetcheada";
    }

}

void ProjectListModel::fetchDbModelUntil(int rowIndex)
{
    while (_databaseModel->rowCount() < (rowIndex + 1) && _databaseModel->canFetchMore()) {
        qDebug() << "ProjectListModel::fetchDbModelUntil: dbModel " << _databaseModel->rowCount()
                 << " rows, indMaximo " << rowIndex << " entradas; fetcheando dbModel";
        _databaseModel->fetchMore();
    }
}

int ProjectListModel::searchForIndex(int id, int maxIndex)
{
    // buscaremos en el modelo de db (debe estar fetcheado) qué índice ocupa el proyecto dado
    // maxIndex es un tope, por seguridad
    int result = -1;
    int ind = 0;
    qDebug() << "ProjectListModel::searchForIndex: id buscado "<<id<<", indice maximo " << maxIndex;
    while (ind <= maxIndex && result == -1) {
        int currid = sqlData(ind, ProjectStore::PROJECT_ID).toInt();
        if (id == currid) {
            result = ind;
        }
        ind++;
    }
    return result;
}

void ProjectListModel::changeProjectState(int id)
{
    int maxIndexInModel = maxIndex();
    int index = _projectIndexes.value(id, -1);
    qDebug() << "ProjectListModel::changeProjectState: index " << index << "; max " << maxIndexInModel;
    if (index >= 0) {
        // hacemos un select para tener el nuevo orden y fetcheamos en el modelo de db lo mismo que teníamos
        sqlSelect();
        fetchDbModelUntil(maxIndexInModel);
        // y ahora hacemos el reset y cargamos de nuevo
        beginResetModel();
        _projectIndexes.clear();
        _list.clear();
        insertIntoListModel(0, maxIndexInModel, false);
        endResetModel();
    }
}

void ProjectListModel::updateData(int id)
{
    int projectIndex = _projectIndexes.value(id, -1);
    qDebug() << "ProjectListModel::updateData: id " << id << " esta en el indice " << projectIndex;
    if (projectIndex >= 0) {
        Q_EMIT(dataChanged(index(projectIndex, 0), index(projectIndex, 0)));
    }
}

int ProjectListModel::indexOf(int id) const
{
    return _projectIndexes.value(id, -1);
}

