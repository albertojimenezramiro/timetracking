/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 30 oct 2023
**
****************************************************************************/

#ifndef SRC_PROJECTS_PROJECTSVIEWMODEL_H_
#define SRC_PROJECTS_PROJECTSVIEWMODEL_H_

#include <QObject>
#include "Project.h"
#include "ProjectStore.h"

class ProjectListModel;
class QTimer;
//class WorkOrderSuggestionsModel;
class TTSettings;

class ProjectsViewModel : public QObject
{
    Q_OBJECT

    // data from loaded project
    Q_PROPERTY(QString name READ name NOTIFY nameChanged)
    Q_PROPERTY(QString desc READ desc NOTIFY descChanged)
    Q_PROPERTY(QString code READ code NOTIFY codeChanged)
    Q_PROPERTY(QString client READ client NOTIFY clientChanged)
    Q_PROPERTY(bool archived READ archived NOTIFY archivedChanged)
    Q_PROPERTY(int id READ id NOTIFY idChanged)

    // editable fields
    Q_PROPERTY(QString nameEdited READ nameEdited WRITE setNameEdited NOTIFY nameEditedChanged)
    Q_PROPERTY(QString descEdited READ descEdited WRITE setDescEdited NOTIFY descEditedChanged)
    Q_PROPERTY(QString codeEdited READ codeEdited WRITE setCodeEdited NOTIFY codeEditedChanged)
    Q_PROPERTY(QString clientEdited READ clientEdited WRITE setClientEdited NOTIFY clientEditedChanged)

    Q_PROPERTY(ProjectListModel* listModel READ listModel CONSTANT)
	//Q_PROPERTY(WorkOrderSuggestionsModel *parentTextSuggestionsModel READ parentTextSuggestionsModel CONSTANT)

    public:
        ProjectsViewModel(QObject* parent, ProjectStore *store, TTSettings *settings);
        virtual ~ProjectsViewModel();

        void initialize();

        // properties

        // editable fields content
        QString nameEdited() const;
        void setNameEdited(const QString &newValue);
        QString descEdited() const;
        void setDescEdited(const QString &newValue);
        QString codeEdited() const;
        void setCodeEdited(const QString &newValue);
        QString clientEdited() const;
        void setClientEdited(const QString &newValue);

        // loaded work order data
        QString name() const;
        QString desc() const;
        QString code() const;
        QString client() const;
        bool archived() const;
        int id() const;

        ProjectListModel *listModel() const;
        //WorkOrderSuggestionsModel *parentTextSuggestionsModel() const;

        //business-logic
        Q_INVOKABLE void loadProject(int id);
        Q_INVOKABLE void createNewProject();
        Q_INVOKABLE void archiveProject();
        Q_INVOKABLE void reopenProject();
        //Q_INVOKABLE void selectParentTextSuggestion(int index);

    Q_SIGNALS:
        // properties
        void nameEditedChanged();
        void descEditedChanged();
        void codeEditedChanged();
        void clientEditedChanged();
        void nameChanged();
        void descChanged();
        void codeChanged();
        void clientChanged();
        void idChanged();
        void archivedChanged();

        // algunas acciones hacen que el indice del proyecto con foco en la lista cambie.
        // con esto lo señalizamos para que la lista cambie su foco
        void projectIndexChanged(int newIndex);

    private Q_SLOTS:
        void slotNotifications(ProjectStore::ProjectNotifications notification, int projectId);
        void saveChanges();
        void slotArchivedProjectThresholdChanged();

    private:

        void emitLoadedProjectSignals();
        void cleanEditedFields();
        //void calculateParentTextSuggestions();
        //bool checkIfIsSuggestedWorkOrder(const QString &pattern);

        Project *_projectLoaded;
        QString _nameEdited;
        QString _descEdited;
        QString _codeEdited;
        QString _clientEdited;

        ProjectStore *_store;
        ProjectListModel *_listModel;
        bool _editorIsDirty;
        QTimer *_saveDelay;
        //WorkOrderSuggestionsModel *_parentTextSuggestionsModel;
        TTSettings *_settings;
        bool _descriptionIsResetting;

};

#endif /* SRC_PROJECTS_PROJECTSVIEWMODEL_H_ */
