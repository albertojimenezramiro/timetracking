/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 1 nov 2023
**
****************************************************************************/

#ifndef PROJECTS_PROJECTSUGGESTIONSMODEL_H_
#define PROJECTS_PROJECTSUGGESTIONSMODEL_H_

#include <QAbstractListModel>
#include <QList>

class Project;

class ProjectSuggestionsModel: public QAbstractListModel
{

    Q_OBJECT
    Q_PROPERTY(int size READ size NOTIFY sizeChanged)

public:
    ProjectSuggestionsModel(QObject *parent);
    virtual ~ProjectSuggestionsModel();

    int rowCount(const QModelIndex& = QModelIndex()) const override;
    QVariant data(const QModelIndex &, int = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    bool canFetchMore(const QModelIndex &) const override;
    void fetchMore(const QModelIndex &) override;

    void loadModel(QList<Project*> list);
    void clearModel();
    Project *suggestionAt(int index);
    Project * suggestionExactMatch(const QString &pattern);
    int size() const;

Q_SIGNALS:
    void sizeChanged();

private:

    enum RoleEnum {
        PROJSUGGESTION_ID = Qt::UserRole + 1,
        PROJSUGGESTION_NAME,
        PROJSUGGESTION_CODE
    };

    QList<Project*> _list;

};
Q_DECLARE_METATYPE(ProjectSuggestionsModel*);
#endif /* PROJECTS_PROJECTSUGGESTIONSMODEL_H_ */
