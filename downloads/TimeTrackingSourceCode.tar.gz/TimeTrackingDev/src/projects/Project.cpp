/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 30 oct 2023
**
****************************************************************************/

#include <QDebug>
#include "Project.h"
#include "Reloj.h"

Project::Project() :
    _id(-1),
    _isArchived(false)
{
}

Project::Project(const Project& p) :
    _id(p._id),
    _name(p._name),
    _description(p._description),
    _code(p._code),
    _client(p._client),
    _isArchived(p._isArchived),
    _archiveDate(p._archiveDate)
{
}

Project::Project(int id, const QString &name, const QString &desc, const QString code, const QString client) :
    _id(id),
    _name(name),
    _description(desc),
    _code(code),
    _client(client),
    _isArchived(false)
{
}

Project::~Project()
{
}

QString Project::name() const
{
    return _name;
}
QString Project::description() const
{
    return _description;
}
QString Project::code() const
{
    return _code;
}
QString Project::client() const
{
    return _client;
}

int Project::id() const
{
    return _id;
}

bool Project::isArchived() const
{
    return _isArchived;
}

void Project::setName(const QString &name)
{
    if (_name != name) {
        _name = name;
    }
}
void Project::setDescription(const QString &desc)
{
    if (_description != desc) {
        _description = desc;
    }
}

void Project::setArchiveDate(const QDateTime &archiveDate)
{
    _archiveDate = archiveDate;
    _isArchived = (Reloj::currentDateTime() > archiveDate);
}

void Project::setCode(const QString &code)
{
    _code = code;
}

void Project::setClient(const QString &client)
{
    _client = client;
}

QDateTime Project::archiveDate() const
{
    return _archiveDate;
}
