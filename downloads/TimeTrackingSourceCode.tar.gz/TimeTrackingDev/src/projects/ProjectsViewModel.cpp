/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 30 oct 2023
**
****************************************************************************/

#include "ProjectsViewModel.h"
#include <QDebug>
#include "ProjectListModel.h"
#include <qqml.h>
#include <QTimer>
//#include "WorkOrderSuggestionsModel.h"
#include "../TTSettings.h"

ProjectsViewModel::ProjectsViewModel(QObject* parent, ProjectStore *store, TTSettings *settings) :
    QObject(parent),
    _projectLoaded(nullptr),
    _store(store),
    _editorIsDirty(false),
    _settings(settings),
    _descriptionIsResetting(false)
{
    qmlRegisterUncreatableType<ProjectListModel>("TimeTracking.models", 1, 0, "ProjectListModel", "No se puede crear un ProjectListModel");
    //qmlRegisterUncreatableType<WorkOrderSuggestionsModel>("TimeTracking.models", 1, 0, "WorkOrderSuggestionsModel", "No se puede crear un WorkOrderSuggestionsModel");
    connect(_store, &ProjectStore::projectNotification, this, &ProjectsViewModel::slotNotifications, Qt::QueuedConnection);
    connect(_settings, &TTSettings::archivedProjectThresholdChanged, this, &ProjectsViewModel::slotArchivedProjectThresholdChanged);
    _listModel = new ProjectListModel(this, store);
    _saveDelay = new QTimer();
    connect(_saveDelay, &QTimer::timeout, this, &ProjectsViewModel::saveChanges);
    _saveDelay->setInterval(1500);
    //_parentTextSuggestionsModel = new WorkOrderSuggestionsModel(this);
}

ProjectsViewModel::~ProjectsViewModel()
{
}

void ProjectsViewModel::initialize()
{
    _listModel->initialize();
    _listModel->loadModel(_settings->archivedProjectThreshold());
}

// properties

QString ProjectsViewModel::nameEdited() const
{
    return _nameEdited;
}
void ProjectsViewModel::setNameEdited(const QString &newValue)
{
    if (_nameEdited != newValue) {
        qDebug() << "ProjectsViewModel::setNameEdited: "<<newValue<<" vs "<<_nameEdited;
        _nameEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
    }
}
QString ProjectsViewModel::descEdited() const
{
    return _descEdited;
}
void ProjectsViewModel::setDescEdited(const QString &newValue)
{
    if (_descEdited != newValue && !_descriptionIsResetting) {
        qDebug() << "ProjectsViewModel::setDescEdited: "<<newValue<<" vs "<<_descEdited;
        _descEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
    }
}
QString ProjectsViewModel::codeEdited() const
{
    return _codeEdited;
}
void ProjectsViewModel::setCodeEdited(const QString &newValue)
{
    if (_codeEdited != newValue) {
        qDebug() << "ProjectsViewModel::setCodeEdited: "<<newValue<<" vs "<<_codeEdited;
        _codeEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
    }
}
QString ProjectsViewModel::clientEdited() const
{
    return _clientEdited;
}
void ProjectsViewModel::setClientEdited(const QString &newValue)
{
    if (_clientEdited != newValue) {
        qDebug() << "ProjectsViewModel::setClientEdited: "<<newValue<<" vs "<<_clientEdited;
        _clientEdited = newValue;
        _editorIsDirty = true;
        _saveDelay->start();
    }
}

QString ProjectsViewModel::name() const
{
    return _projectLoaded ? _projectLoaded->name() : "";
}

QString ProjectsViewModel::desc() const
{
    return _projectLoaded ? _projectLoaded->description() : "";
}

QString ProjectsViewModel::code() const
{
    return _projectLoaded ? _projectLoaded->code() : "";
}

QString ProjectsViewModel::client() const
{
    return _projectLoaded ? _projectLoaded->client() : "";
}

bool ProjectsViewModel::archived() const
{
    return _projectLoaded && _projectLoaded->isArchived();
}

int ProjectsViewModel::id() const
{
    return _projectLoaded ? _projectLoaded->id() : -1;
}

ProjectListModel *ProjectsViewModel::listModel() const
{
    return _listModel;
}



///////////////////////
///                 ///
/// BUSINESS-LOGIC  ///
///                 ///
///////////////////////

void ProjectsViewModel::loadProject(int id)
{
    Project *proj = id > 0 ? _store->project(id, false) : nullptr;
    qDebug() << "ProjectsViewModel::loadProject: id " << id << ", proj " << proj << ", loaded " << _projectLoaded;
    if (proj != _projectLoaded) {
        saveChanges();
        _projectLoaded = proj;
        qDebug() << "ProjectsViewModel::loadProject: ahora loaded es " << (_projectLoaded ? _projectLoaded->id() : -1);
        emitLoadedProjectSignals();
        cleanEditedFields();
    }
}

void ProjectsViewModel::createNewProject()
{
    saveChanges();
    _store->createNewProject();
}

void ProjectsViewModel::archiveProject()
{
    saveChanges();
    if (_projectLoaded && !_projectLoaded->isArchived()) {
        _store->archiveProject(_projectLoaded->id());
    }
}

void ProjectsViewModel::reopenProject()
{
    saveChanges();
    if (_projectLoaded && _projectLoaded->isArchived()) {
        _store->reopenProject(_projectLoaded->id());
    }
}

void ProjectsViewModel::saveChanges()
{
    qDebug() << "ProjectsViewModel::saveChanges: dirty " << _editorIsDirty << ", loaded " << _projectLoaded << " " << (_projectLoaded ? _projectLoaded->id() : -1);
    _saveDelay->stop();
    if (_projectLoaded && _editorIsDirty) {
        _store->updateProjectDataInDb(_projectLoaded->id(), _nameEdited, _descEdited, _codeEdited, _clientEdited);
        _editorIsDirty = false;
    }
    qDebug() << "ProjectsViewModel::saveChanges: final";
}

void ProjectsViewModel::emitLoadedProjectSignals()
{
    Q_EMIT(nameChanged());
    _descriptionIsResetting = true;
    Q_EMIT(descChanged());
    _descriptionIsResetting = false;
    Q_EMIT(codeChanged());
    Q_EMIT(clientChanged());
    Q_EMIT(idChanged());
    Q_EMIT(archivedChanged());
}

void ProjectsViewModel::cleanEditedFields()
{
    qDebug() << "ProjectsViewModel::cleanEditedFields";
    // esto no es un cambio que haya que guardar, por lo que no debe lanzar el timer ni actualizar
    // el flag de dirty. Por eso no uso setters.

    _nameEdited = name();
    _descEdited = desc();
    _codeEdited = code();
    _clientEdited = client();
    //calculateParentTextSuggestions();
}

void ProjectsViewModel::slotNotifications(ProjectStore::ProjectNotifications notification, int projectId)
{
    switch (notification) {
        case ProjectStore::PROJECTNOTIF_NEW:
        case ProjectStore::PROJECTNOTIF_IMPORTED: {
            qDebug() << "ProjectsViewModel::slotNotifications: new o imported. insertando en listmodel";
            Project *n = _store->project(projectId, false);
            _listModel->insertNewProject(n->id());
            Q_EMIT(projectIndexChanged(_listModel->indexOf(n->id())));
            break;
        }
        case ProjectStore::PROJECTNOTIF_ARCHIVED:
        case ProjectStore::PROJECTNOTIF_REOPEN: {
            Project *n = _store->project(projectId, false);
            _listModel->changeProjectState(n->id());
            if (notification == ProjectStore::PROJECTNOTIF_REOPEN) {
                qDebug() << "ProjectsViewModel::slotNotifications: notification reopen";
                Q_EMIT(projectIndexChanged(_listModel->indexOf(n->id())));
            }
            break;
        }
        case ProjectStore::PROJECTNOTIF_UPDATEDATA: {
            Project *n = _store->project(projectId, false);
            if (_projectLoaded->id() == n->id()) {
                emitLoadedProjectSignals();
                cleanEditedFields();
            }
            qDebug() << "ProjectsViewModel::slotNotifications: updatedata, id " << n->id() << ", actualizando modelo de lista";
            _listModel->updateData(n->id());
            break;
        }
        default:
            break;
    }
}

void ProjectsViewModel::slotArchivedProjectThresholdChanged()
{
    qDebug() << "ProjectsViewModel::slotArchivedProjectThresholdChanged";
    _listModel->loadModel(_settings->archivedProjectThreshold());
    Q_EMIT(projectIndexChanged(0));
}
