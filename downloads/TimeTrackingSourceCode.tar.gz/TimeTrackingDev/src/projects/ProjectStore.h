/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 30 oct 2023
**
****************************************************************************/

#ifndef SRC_PROJECTS_PROJECTSTORE_H_
#define SRC_PROJECTS_PROJECTSTORE_H_

#include <QString>
#include <QList>

class QSqlTableModel;
class Project;

class ProjectStore : public QObject {
Q_OBJECT
public:
    // fields for browsing into the db model resultset
    enum ProjectFields {
        PROJECT_ID = 0,
        PROJECT_NAME,
        PROJECT_CODE,
        PROJECT_CREATIONTIME,
        PROJECT_CLIENT,
        PROJECT_DESCRIPTION,
        PROJECT_ARCHIVEDATE
    };

    typedef enum ProjectNotifications {
        PROJECTNOTIF_NONE = 0,
        PROJECTNOTIF_NEW,
        PROJECTNOTIF_ARCHIVED,
        PROJECTNOTIF_REOPEN,
        PROJECTNOTIF_UPDATEDATA,
        PROJECTNOTIF_IMPORTED
    } ProjectNotifications;
    Q_ENUM(ProjectNotifications)

    ProjectStore(QObject* parent);
    virtual ~ProjectStore();

    void initialize();

    Project *project(int id, bool loadFromDb);
    Project *last() const;
    void createProjectFromData(const QString &name, const QString &code, const QString &description, const QString &client, qint64 creationTime, qint64 archiveTime);
    /**
     * @brief Creates a new work order into the database using default fields and loads it into
     *        memory.
     *
     * This will be notified with the WONOTIF_NEWWO notification. The new work order can be get using
     * the last() method.
     *
     * @return
     */
    void createNewProject();
    void archiveProject(int id);
    void reopenProject(int id);
    bool updateProjectDataInDb(int id, const QString &name, const QString &description, const QString &code, const QString &client);
    QList<Project*> suggestionsFor(const QString &pattern);
    Project *projectByCode(const QString &code);
    void importProject(const QString &code);

Q_SIGNALS:
    // sends a notification
    void projectNotification(ProjectStore::ProjectNotifications notification, int projectId);

private:
    Project *projectFactoryMethod(int id, const QString &nombre, const QString &desc, const QString &codigo, const QString &client);
    // extracts a piece of data from the resultset of the db model, using a row number for the resultset and a column field
    QVariant sqlData(int rowIndex, ProjectStore::ProjectFields column);
    // this loads the db model with a select based on work order id
    void selectProject(int id);
    void selectProjects(const QString &pattern);

    // this caches the first project that is in the resultset of the db model into memory
    Project *cacheSelected();
    Project *cacheSelected(int rowIndex);

    //select the project into the db model and updates just the archive date (for archive and reopen operations)
    bool updateArchiveDateInDb(int id, const QDateTime &archiveDate);


    QSqlTableModel* _model;
    QMap<int, Project*> _projects;

    // this will hold the last project that received a changed or was notified about
    Project *_last;

    static const qint64 _defaultArchiveTimestamp;
};

#endif /* SRC_PROJECTS_PROJECTSTORE_H_ */
