/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 6 oct 2023
**
****************************************************************************/

#ifndef SRC_DATABASEMAINTENANCE_H_
#define SRC_DATABASEMAINTENANCE_H_

#include <qobject.h>

enum SettingsFields {
    SETTINGSFIELDS_ID = 0,
    SETTINGSFIELDS_NAME,
    SETTINGSFIELDS_VALUE
};

class DatabaseMaintenance: public QObject
{
Q_OBJECT
    public:

        static QString sqlPath();

        DatabaseMaintenance(QObject *parent);
        virtual ~DatabaseMaintenance();

        bool initialize();
        void setVersion(const QString &version);
        bool isInitialized() const;

        static QString _userDataDirectory;

    Q_SIGNALS:
        void newMessage(const QString &message);
        void initialized();

    private Q_SLOTS:
        void slotUserBackup();

    private:
        static QString sqlBackupPath();

        Q_INVOKABLE bool createDatabase();
        Q_INVOKABLE void applySchemaUpdates();
        int schemaVersion();
        void saveSchemaVersion(int newVersion);
        void createUserBackup();
        Q_INVOKABLE void updateSchemaToVersion2();
        Q_INVOKABLE void updateSchemaToVersion3();
        Q_INVOKABLE void updateSchemaToVersion4();

        QString _version;
        bool _isInitialized;

        static const QString _oldSqlPath;
        static const QString _oldSqlBackupPath;
        static const QString _sqlTareas;
        static const QString _sqlTiempo;
        static const QString _sqlWos;
        static const QString _sqlWorkOrders;
        static const QString _sqlSettings;
        static const QString _sqlProjects;
        static const QString _sqlProjectTask;
        static const QString _sqlAlterJiraId;
        static const QString _sqlAlterIdWorkOrder;
};

#endif /* SRC_DATABASEMAINTENANCE_H_ */
