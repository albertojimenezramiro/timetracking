/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 16 feb. 2019
**
****************************************************************************/

#ifndef SRC_REPORTES_DESCRIPTIONMODEL_H_
#define SRC_REPORTES_DESCRIPTIONMODEL_H_

#include <qobject.h>
#include <QDateTime>

class Task;

class DescriptionModel: public QObject {
    Q_OBJECT

public:
    typedef enum DescriptionState {
        STATE_NOTAVAILABLE,
        STATE_LOADING,
        STATE_AVAILABLE
    } DescriptionState;
    Q_ENUM(DescriptionState);

    DescriptionModel(QObject *parent, Task *task);
    virtual ~DescriptionModel();

    DescriptionState state() const;
    void setState(DescriptionState state);
    QString description() const;
    void setDescription(QString desc);
    void markAsUpdated();
    QDateTime UpdateDate() const;
    Task *task() const;

Q_SIGNALS:
    void stateChanged();

private:
    DescriptionState _state;
    QString _description;
    QDateTime _updateDate;
    Task *_task;
};

#endif /* SRC_REPORTES_DESCRIPTIONMODEL_H_ */
