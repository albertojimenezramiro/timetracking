/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 17 oct. 2023
**
****************************************************************************/

#include "RowModel.h"
#include "Report.h"
#include <QDebug>
#include "../projects/Project.h"

RowModel::RowModel(Task *task, WorkOrder *workOrder, const QList<QDateTime> &workingDays, bool accumulatedMode) :
    _task(task),
    _workOrder(workOrder),
    _project(nullptr),
    _isProjectHeader(false),
    _accumulatedMode(accumulatedMode)
{
    if (accumulatedMode) {
        _reports.insert(QDateTime(), new Report());
    } else {
        for (auto day : workingDays) {
            _reports.insert(day, new Report());
        }
    }
}

RowModel::RowModel(Project *project) :
    _task(nullptr),
    _workOrder(nullptr),
    _project(project),
    _isProjectHeader(true),
    _accumulatedMode(false)
{
}

RowModel::~RowModel()
{
}

Task *RowModel::task() const
{
    return _task;
}
WorkOrder *RowModel::workOrder() const
{
    return _workOrder;
}

QDateTime RowModel::key(const QDateTime &day) const
{
    QDateTime key = day;
    key.setTime(QTime(0, 0, 0, 0));
    return key;
}

Report *RowModel::report(const QDateTime &day) const
{
    QDateTime dkey = key(day);
    return _reports.value(dkey, nullptr);
}

bool RowModel::addTime(QDateTime day, qint64 timeMSecs)
{
    bool res = false;
    QDateTime key = _accumulatedMode ? QDateTime() : day;
    Report *r = report(key);
    qDebug() << "RowModel::addTime: intentando sumar "<<timeMSecs<<" msecs a reporte de "<<day<<", "<<r;
    if (r) {
        r->addTime(timeMSecs);
        res = true;
    }
    return res;
}

qint64 RowModel::timeDay(const QDateTime &day) const
{
    qint64 res = 0;
    QDateTime key = _accumulatedMode ? QDateTime() : day;
    Report *r = report(key);
    if (r) {
        res = r->time();
    }
    return res;
}

void RowModel::normalizeReportDay(const QDateTime &day, qint64 diff)
{
    Report *r = report(day);
    if (r) {
        r->normalizeReport(diff);
    }
}

void RowModel::denormalizeReportDay(const QDateTime &day)
{
    Report *r = report(day);
    if (r) {
        r->denormalizeReport();
    }
}

bool RowModel::isNormalizedDay(const QDateTime &day) const
{
    bool res = false;
    Report *r = report(day);
    if (r) {
        res = r->isNormalized();
    }
    return res;
}

Project *RowModel::project() const
{
    return _project;
}

bool RowModel::isProjectHeader() const
{
    return _isProjectHeader;
}

void RowModel::setProjectHeader(bool header)
{
    _isProjectHeader = header;
}

