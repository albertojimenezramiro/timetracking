/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 27 may. 2019
**
****************************************************************************/

#ifndef SRC_REPORTES_REPORT_H_
#define SRC_REPORTES_REPORT_H_

#include <qglobal.h>

class Report {
    //Q_OBJECT

    //Q_PROPERTY(qint64 tiempo READ tiempo NOTIFY tiempoChanged)
    //Q_PROPERTY(qint64 diferencia READ diferencia NOTIFY tiempoChanged)
    //Q_PROPERTY(bool normalizado READ normalizado NOTIFY normalizadoChanged)
public:
    Report();
    virtual ~Report();

    void addTime(qint64 timemsecs);
    qint64 time() const;
    void normalizeReport(qint64 diff);
    void denormalizeReport();
    bool isNormalized() const;
    /*void setTiempo(const qint64 t);
    bool normalizado() const;
    qint64 diferencia() const;
    void sumarDiferenciaNormalizacion(qint64 diff);
    void restarDiferenciaNormalizacion(qint64 diff);
    void borrarDiferenciaNormalizacion();*/

/*Q_SIGNALS:
    void tiempoChanged();
    void normalizadoChanged();*/

private:
    qint64 _time;
    qint64 _diff;
    bool _isNormalized;
    //int _normalizado;
};

#endif /* SRC_REPORTES_REPORT_H_ */
