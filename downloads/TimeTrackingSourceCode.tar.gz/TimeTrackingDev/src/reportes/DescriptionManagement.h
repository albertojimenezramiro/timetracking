/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 16 feb. 2019
**
****************************************************************************/

#ifndef SRC_REPORTES_DESCRIPTIONMANAGEMENT_H_
#define SRC_REPORTES_DESCRIPTIONMANAGEMENT_H_

#include <qobject.h>
#include <QHash>
#ifdef FEATURE_TIMESHEETJIRAINTEGRATION
#include <QProcess>
#endif
#include "DescriptionModel.h"
#include "tareas/TaskStore.h"

class Task;
class TTSettings;

class DescriptionManagement : public QObject {
Q_OBJECT
public:
    enum DescriptionError {
        DESCERROR_NOERROR,
        DESCERROR_BADUSERNAME,
        DESCERROR_BADTOKEN,
        DESCERROR_BADPATH,
        DESCERROR_PROCESSERROR,
        DESCERROR_BADPROCESSEXECUTION,
        DESCERROR_EMPTYDESCRIPTION
    };
    Q_ENUM(DescriptionError);

    DescriptionManagement(QObject *parent, TTSettings *settings, TaskStore *taskStore);
    virtual ~DescriptionManagement();

    DescriptionModel* descriptionModel(Task *task);
    void loadDescription(Task* task);

Q_SIGNALS:
    void descriptionStateChanged(Task* task, DescriptionModel::DescriptionState state);
    void descriptionCopied(Task *task);
    void descriptionError(DescriptionManagement::DescriptionError error);

private Q_SLOTS:
#ifdef FEATURE_TIMESHEETJIRAINTEGRATION
    void slotProcessStarted();
    void slotProcessError(QProcess::ProcessError error);
#endif
    void checkExpirations();
    void slotDescriptionStateChanged();
    void slotTaskNotifications(TaskStore::TaskNotifications notification, int taskId);

private:
#ifdef FEATURE_TIMESHEETJIRAINTEGRATION
    void startGeneration(Task* task, DescriptionModel * descModel);
    void slotProcessFinished(int exitCode, QProcess::ExitStatus status);
    QString parseDescription(QString rawData);
#endif
    void copyToClipboard(DescriptionModel *desc);
    void loadLocalDescription(Task *task);

    QHash<Task*, DescriptionModel*> _descriptions;
    QHash<int, Task*> _tasks;
#ifdef FEATURE_TIMESHEETJIRAINTEGRATION
    QProcess _process;
    Task *_generationOngoing;
#endif
    TTSettings *_settings;
    QList<DescriptionModel*> _expirations;
    TaskStore *_taskStore;
    static const qint64 _expirationTime;
};

#endif /* SRC_REPORTES_DESCRIPTIONMANAGEMENT_H_ */
