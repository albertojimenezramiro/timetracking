/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 17 dic. 2018
**
****************************************************************************/

#ifndef SRC_REPORTES_REPORTTABLEMODEL_H_
#define SRC_REPORTES_REPORTTABLEMODEL_H_

#include <QAbstractTableModel>
#include <QObject>
#include "TTSettings.h"
#include "DescriptionModel.h"
#include "DescriptionManagement.h"

class Task;
class RowModel;
class WorkOrder;
class Report;
class Project;

class ReportTableModel : public QAbstractTableModel
{
    Q_OBJECT
    Q_PROPERTY(bool hasReports READ hasReports NOTIFY hasReportsChanged)
    Q_PROPERTY(int numDays READ numDays NOTIFY numDaysChanged)
    Q_PROPERTY(DescriptionManagement::DescriptionError lastDescriptionError READ lastDescriptionError NOTIFY lastDescriptionErrorChanged)

public:

    enum RoleEnum {
        ROLE_DATETIME = Qt::UserRole + 1,
        ROLE_DAYTOTAL,
        ROLE_TASKCODE,
        ROLE_TASKNAME,
        ROLE_WORKORDERCODE,
        ROLE_WORKORDERNAME,
        ROLE_ISNORMALIZED,
        ROLE_ISDAYNORMALIZED,
        ROLE_TASKDAYREPORTDECIMAL,
        ROLE_TASKTOTAL,
        ROLE_TASKPERCENTAGE,
        ROLE_WEEKTOTAL,
        ROLE_DESCRIPTIONSTATUS,
        ROLE_ISPROJECTHEADER,
        ROLE_PROJECTNAME,
        ROLE_PROJECTCODE,
        ROLE_PROJECTID,
        ROLE_FILTEREDBYPROJECT,
        ROLE_TASKDAYREPORTSEXA,
        ROLE_DAYTOTALSEXA,
        ROLE_WEEKTOTALSEXA,
        ROLE_TASKTOTALSEXA
    };
    Q_ENUM(RoleEnum);

    ReportTableModel(QObject *parent, TTSettings *settings, DescriptionManagement *descriptionManagement);
    virtual ~ReportTableModel();

    void clearModel();
    void clearReports();

    void setWorkingWeekRange(const QDateTime &firstWorkingDay, int numWorkingDays);
    bool inWeekRange(const QDateTime &time) const;
    void addWorkedTimeForTask(Task *task, QDateTime day, qint64 msecs);
    void beginTransactionalLoad();
    void endTransactionalLoad();

    int rowCount(const QModelIndex& = QModelIndex()) const override;
    int columnCount(const QModelIndex& = QModelIndex()) const override;
    Q_INVOKABLE QVariant headerData(int section, Qt::Orientation orientation, int role = Qt::DisplayRole) const override;
    QVariant data(const QModelIndex &, int = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    bool canFetchMore(const QModelIndex &) const override;
    void fetchMore(const QModelIndex &) override;

    Q_INVOKABLE void normalizeSwitched(int rowIndex, int columnIndex);
    void normalizeSwitched(int rowIndex, int columnIndex, bool sendNotifications);
    Q_INVOKABLE void descriptionClicked(int rowIndex);
    Q_INVOKABLE bool isProjectHeader(int rowIndex) const;
    Project *projectToFilter() const;
    void setProjectToFilter(Project *project);
    Q_INVOKABLE bool hasReports() const;
    void setAccumulatedMode(bool mode);
    bool isAccumulated() const;
    QDateTime firstWorkingDay() const;
    QDateTime lastWorkingDay() const;
    int numDays() const;
    DescriptionManagement::DescriptionError lastDescriptionError() const;
    void setLastDescriptionError(DescriptionManagement::DescriptionError newValue);
    Q_INVOKABLE void clearLastDescriptionError();
    void aboutToEditModel();
    void editModelFinished();

Q_SIGNALS:
    void descriptionCopied(int rowIndex);
    void hasReportsChanged();
    void projectToFilterChanged();
    void isAccumulatedChanged();
    void numDaysChanged();
    void lastDescriptionErrorChanged();

private Q_SLOTS:
    void slotWorkingHoursChanged();
    void slotDescriptionStateChanged(Task* task, DescriptionModel::DescriptionState state);
    void slotDescriptionCopied(Task *task);
    void slotDescriptionError(DescriptionManagement::DescriptionError error);

private:
    RowModel *searchForRowModel(Task *task, WorkOrder *wo, int &rowIndex) const;
    RowModel *searchForRowModel(Task *task, int &rowIndex) const;
    int extraColumnsBefore() const;
    int extraColumnsAfter() const;
    qreal convertToDecimalFormat(qint64 timeMSecs) const;
    qreal convertToDecimalFormat(qreal source) const;
    qint64 dayTotal(int columnIndex) const;
    qint64 rowTotal(int rowIndex) const;
    qint64 tableTotal() const;
    void notifyNormalizationSwitch(int rowIndex, int columnIndex);
    void addTimeIntoRow(Task *task, WorkOrder *wo, QDateTime day, qint64 msecs);
    int calculateRowInsertionRange(Task *task, bool &insertCurrentHeader, bool &insertNextHeader) const;
    void insertRowAtIndex(RowModel *rowModel, int rowIndex, bool insertCurrentHeader, bool insertNextHeader);

    TTSettings *_settings;
    QList<QDateTime> _workingDays;
    int _extraRowsBefore;
    int _extraRowsAfter;
    QList<RowModel*> _rows;
    bool _transactionalLoadOngoing;
    QHash<QDateTime, RowModel*> _normalizations;
    DescriptionManagement *_descriptionManagement;
    bool _hasProjectHeaders;
    Project *_projectToFilter;
    bool _accumulatedMode;
    DescriptionManagement::DescriptionError _lastDescriptionError;
    bool _resetOngoing;

};
Q_DECLARE_METATYPE(ReportTableModel*);
#endif /* SRC_REPORTES_REPORTTABLEMODEL_H_ */
