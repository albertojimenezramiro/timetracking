/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 9 oct. 2023
**
****************************************************************************/

#include "ReportViewModel.h"
#include <QDebug>
#include <qqml.h>
#include "TTSettings.h"
#include "ReportTableModel.h"
#include "Reloj.h"
#include "ReportManagement.h"
#include <QVariant>
#include "../tiempo/TimeStore.h"
#include "DescriptionManagement.h"
#include "../projects/Project.h"
#include "Funciones.h"

ReportViewModel::ReportViewModel(QObject* parent, TTSettings *settings, TimeStore *timeStore, TaskStore *taskStore, ProjectStore *projectStore, WorkOrderStore *woStore) :
    QObject(parent),
    _settings(settings),
    _weekSelectorValue(0),
    _isCurrentWeek(true),
    _projectStore(projectStore),
    _numberOfWorkingDays(0)
{
    qDebug() << "ReportViewModel::ReportViewModel";
    qmlRegisterUncreatableType<ReportTableModel>("TimeTracking.models", 1, 0, "ReportTableModel", "No se puede crear un ReportTableModel");
    qmlRegisterUncreatableType<DescriptionManagement>("TimeTracking.models", 1, 0, "DescriptionManagement", "No se puede crear un DescriptionManagement");
    DescriptionManagement *dm = new DescriptionManagement(this, settings, taskStore);
    _tableModel = new ReportTableModel(this, _settings, dm);
    connect(_tableModel, &ReportTableModel::isAccumulatedChanged, this, &ReportViewModel::isAccumulatedChanged);
    connect(_tableModel, &ReportTableModel::projectToFilterChanged, this, &ReportViewModel::projectToFilterNameChanged);
    _management = new ReportManagement(this, _settings, _tableModel, timeStore, taskStore, projectStore, woStore);
    connect(_settings, &TTSettings::workingWeekRangeChanged, this, &ReportViewModel::slotWorkingWeekRangeChanged);
    connect(Reloj::instance(), &Reloj::currentTimeChanged, this, &ReportViewModel::calculateCurrentWeekFlag, Qt::UniqueConnection);
    connect(projectStore, &ProjectStore::projectNotification, this, &ReportViewModel::slotProjectNotification);
}

void ReportViewModel::initialize()
{
    _tableModel->clearModel();
    QDateTime firstDay = _management->firstWorkingDayOfCurrentWeek(_numberOfWorkingDays);
    qDebug() << "ReportViewModel::initialize: referencia "<<firstDay;
    _weekSelectorReference = firstDay;
    loadNewWeek(firstDay);
    qDebug() << "ReportViewModel::initialize";
}

ReportViewModel::~ReportViewModel()
{
}

ReportTableModel *ReportViewModel::tableModel() const
{
    return _tableModel;
}

int ReportViewModel::weekSelectorValue() const
{
    return _weekSelectorValue;
}
void ReportViewModel::setWeekSelectorValue(int newValue)
{
    qDebug() << "ReportViewModel::setWeekSelectorValue: valor " << newValue<<", actual "<<_weekSelectorValue;
    if (newValue != _weekSelectorValue) {
        _weekSelectorValue = newValue;
        Q_EMIT(weekSelectorValueChanged());
        QDateTime newFirstDay = _weekSelectorReference.addDays(7 * newValue);
        qDebug() << "ReportViewModel::setWeekSelectorValue: referencia "<<newFirstDay;
        loadNewWeek(newFirstDay);
        qDebug() << "ReportViewModel::setWeekSelectorValue";
        calculateCurrentWeekFlag();
    }
}

QString ReportViewModel::weekSelectorText(int weekDiffWithToday) const
{
    // calcula el string que sale dentro del spinbox de semanas (202345)
    int numDays;
    QDateTime ref = _management->firstWorkingDayOfCurrentWeek(numDays).addDays(weekDiffWithToday * 7);
    return formatTextYearWeek(ref);
}

QString ReportViewModel::weekLabelText() const
{
    return _weekLabelText;
}

void ReportViewModel::setWeekLabelText(const QString &newValue)
{
    if (_weekLabelText != newValue) {
        _weekLabelText = newValue;
        Q_EMIT(weekLabelTextChanged());
    }
}

QString ReportViewModel::projectToFilterName() const
{
    return _tableModel && _tableModel->projectToFilter() ? _tableModel->projectToFilter()->name() : "";
}

QString ReportViewModel::formatTextYearWeek(const QDateTime &firstDay) const
{
    int yearNum = 0, weekNum = 0;
    weekNum = firstDay.date().weekNumber(&yearNum);
    QString text = QString::number(yearNum) +
                   QString::number(weekNum).rightJustified(2, QChar('0'));
    qDebug()<<"ReportViewModel::formatTextYearWeek: fecha " << firstDay << ", " << text;
    return text;
}

void ReportViewModel::calculateCurrentWeekFlag()
{
    QDateTime now = Reloj::instance()->currentDateTime();
    QDateTime firstDay = _tableModel->firstWorkingDay();
    bool isCurrentWeek = firstDay <= now && firstDay.addDays(7) > now;
    setIsCurrentWeek(isCurrentWeek);
}

bool ReportViewModel::isCurrentWeek() const
{
    return _isCurrentWeek;
}

void ReportViewModel::setIsCurrentWeek(bool value)
{
    if (_isCurrentWeek != value) {
        _isCurrentWeek = value;
        Q_EMIT(isCurrentWeekChanged());
    }
}

void ReportViewModel::loadNewWeek(const QDateTime &firstDay)
{
    QDateTime newLastDay = firstDay.addDays(_numberOfWorkingDays - 1);
    QString labelText = firstDay.toString("dd MMM yyyy") + " - " + newLastDay.toString("dd MMM yyyy");
    qDebug() << "ReportViewModel::loadNewWeek: "<<labelText;
    setWeekLabelText(labelText);
    //cargar los días de la semana laboral
    _tableModel->clearModel();
    _management->loadWeekMetadata(firstDay);
    _management->loadWeekReports(true);
}


///////////////////////
///                 ///
/// BUSINESS-LOGIC  ///
///                 ///
///////////////////////



void ReportViewModel::filterByProject(int projectId)
{
    qDebug() << "ReportViewModel::filterByProject: project " << projectId;
    Project *filter = nullptr;
    if (projectId > 0) {
        filter = _projectStore->project(projectId, false);
    }
    if (_tableModel->projectToFilter() != filter) {
        _tableModel->setProjectToFilter(filter);
        _management->reloadWeekReports();
    }
}

bool ReportViewModel::isFiltered() const
{
    return _tableModel && _tableModel->projectToFilter();
}

void ReportViewModel::slotProjectNotification(ProjectStore::ProjectNotifications notification, int projectId)
{
    Q_UNUSED(projectId);
    switch (notification) {
        case ProjectStore::PROJECTNOTIF_UPDATEDATA: {
            if (_tableModel && _tableModel->projectToFilter() && _tableModel->projectToFilter()->id() == projectId) {
                Q_EMIT(projectToFilterNameChanged());
            }
            break;
        }
        default:
            break;
    }
}

void ReportViewModel::loadAccumulatedReports()
{
    _management->loadAccumulatedReports(true);
}

void ReportViewModel::comeBackFromAccumulatedReports()
{
    _management->comeBackFromAccumulatedReports();
}

bool ReportViewModel::isAccumulated() const
{
    return _tableModel ? _tableModel->isAccumulated() : false;
}

void ReportViewModel::switchProjectReportMode()
{
    if (_tableModel && _tableModel->projectToFilter()) {
        qDebug() << "ReportViewModel::switchProjectReportMode: project " << _tableModel->projectToFilter()->id() << ", accumulated " << _tableModel->isAccumulated();
        if (isAccumulated()) {
            comeBackFromAccumulatedReports();
            calculateCurrentWeekFlag();
        } else {
            loadAccumulatedReports();
        }
    }
}

void ReportViewModel::slotWorkingWeekRangeChanged()
{
    QDateTime firstCurrDay = _tableModel->firstWorkingDay();
    _tableModel->clearModel();
    QDateTime firstDay = _management->firstWorkingDayOfWeek(firstCurrDay, _numberOfWorkingDays);
    qDebug() << "ReportViewModel::slotWorkingWeekRangeChanged: referencia "<<firstDay;
    _weekSelectorReference = firstDay;
    // no queremos usar el setter de weekSelectorValue
    _weekSelectorValue = 0;
    Q_EMIT(weekSelectorValueChanged());
    loadNewWeek(firstDay);
    calculateCurrentWeekFlag();
    qDebug() << "ReportViewModel::slotWorkingWeekRangeChanged: fin";
}

