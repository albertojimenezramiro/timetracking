/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 13 oct. 2018
**
****************************************************************************/

#ifndef REPORTMANAGEMENT_H_
#define REPORTMANAGEMENT_H_

#include <qobject.h>
#include <QDateTime>
#include <QVariant>
#include "TTSettings.h"
#include "../tiempo/TimeStore.h"
#include "../tareas/TaskStore.h"
#include "../projects/ProjectStore.h"
#include "../workorders/WorkOrderStore.h"

class Task;
class ReportTableModel;
class TimeEntry;

class ReportManagement: public QObject {
    Q_OBJECT

public:
    ReportManagement(QObject *parent, TTSettings* settings, ReportTableModel *model, TimeStore *timeStore,
                     TaskStore *taskStore, ProjectStore *projectStore, WorkOrderStore *woStore);
    virtual ~ReportManagement();

    void loadWeekMetadata(const QDateTime ref);
    QDateTime firstWorkingDayOfCurrentWeek(int &numDays) const;
    QDateTime firstWorkingDayOfWeek(const QDateTime &reference, int &numDays) const;
    QDateTime firstWorkingDayOfModel() const;
    QDateTime lastWorkingDayOfModel() const;
    void loadWeekReports(bool transactional);
    void reloadWeekReports();
    void loadAccumulatedReports(bool transactional);
    void comeBackFromAccumulatedReports();

//public Q_SLOTS:


private Q_SLOTS:
    void slotTimeNotification(TimeStore::TimeNotifications notification, qint64 entryId);
    void slotTaskNotification(TaskStore::TaskNotifications notification, int taskId);
    void slotProjectNotification(ProjectStore::ProjectNotifications notification, int projectId);
    void slotWoNotification(WorkOrderStore::WorkOrderNotifications, int woId);
    void processWorkedTimeClockUpdate();
    void slotGroupingChanged();
    void recalculateReports();
    void slotAccumulatedProjectReportsThresholdChanged();


private:
    void processWorkedTimeInterval(Task* task, QDateTime beginning, QDateTime end);
    void processWorkedTimeLastInterval(const TimeEntry* anteriorEntrada);
    void processWorkedTimeNewActiveTask(Task *oldT, Task *newT);
    void processTimeEntryList(QList<TimeEntry*> entries, Project *matchProject);


    TTSettings *_settings;
    ReportTableModel *_model;
    TimeStore* _timeStore;
    Task *_lastActiveTask;
    bool _weekIsComplete;
    // el último instante hasta el cual está el tiempo trabajado contabilizado y metido en el modelo
    QDateTime _lastTimeRefresh;
    QDateTime _tmpFirstDayOfModelWeek; // guardamos el rango semanal cuando pasamos a reportes acumulados, para cuando volvamos

};
Q_DECLARE_METATYPE(ReportManagement*);
#endif /* REPORTMANAGEMENT_H_ */
