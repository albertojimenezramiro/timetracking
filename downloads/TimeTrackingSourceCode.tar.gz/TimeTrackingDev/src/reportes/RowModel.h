/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 17 oct. 2023
**
****************************************************************************/

#ifndef SRC_REPORTES_ROWMODEL_H_
#define SRC_REPORTES_ROWMODEL_H_

#include <QDateTime>
#include <QList>

class Task;
class WorkOrder;
class Report;
class Project;

class RowModel
{
    public:
        RowModel(Task *task, WorkOrder *workOrder, const QList<QDateTime> &workingDays, bool accumulatedMode);
        RowModel(Project *project);
        virtual ~RowModel();

        bool addTime(QDateTime day, qint64 timeMSecs);
        Task *task() const;
        WorkOrder *workOrder() const;
        qint64 timeDay(const QDateTime &day) const;
        void normalizeReportDay(const QDateTime &day, qint64 diff);
        void denormalizeReportDay(const QDateTime &day);
        bool isNormalizedDay(const QDateTime &day) const;
        Project *project() const; // solo para las cabeceras de proyecto
        bool isProjectHeader() const;
        void setProjectHeader(bool header);

    private:
        QDateTime key(const QDateTime &day) const;
        Report *report(const QDateTime &day) const;

        Task *_task;
        WorkOrder *_workOrder;
        QMap<QDateTime, Report*> _reports;
        Project* _project;
        bool _isProjectHeader;
        bool _accumulatedMode;
};

#endif /* SRC_REPORTES_ROWMODEL_H_ */
