/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 27 may. 2019
**
****************************************************************************/
/*
 * Report.cpp
 *
 *  Created on: 27 may. 2019
 *      Author: alberto
 */

#include "Report.h"
#include <QDebug>

Report::Report() :
_time(0),
_diff(0),
_isNormalized(false)
{
}

Report::~Report()
{
}

void Report::addTime(qint64 timemsecs/*, const bool ajustarDiferencia*/)
{
    _time += timemsecs;
    if (_isNormalized) {
        _diff -= timemsecs;
    }
    /*if (_normalizado > 0 && ajustarDiferencia) {
        _diferencia -= t;
    }*/
    //qDebug() << "Reporte::sumarTiempo: tiempo " << _tiempo << ", diff " << _diferencia << ", norm " << _normalizado;
    //Q_EMIT(tiempoChanged());
}

/*void Reporte::setTiempo(const qint64 t)
{
    _tiempo = t;
    _diferencia = 0;
    _normalizado = false;
    Q_EMIT(tiempoChanged());
}*/

qint64 Report::time() const
{
    return _time + _diff;
}

void Report::normalizeReport(qint64 diff)
{
    _diff = diff;
    _isNormalized = true;
}

void Report::denormalizeReport()
{
    _diff = 0;
    _isNormalized = false;
}

bool Report::isNormalized() const
{
    return _isNormalized;
}

/*qint64 Reporte::diferencia() const
{
    return _diferencia;
}

void Reporte::sumarDiferenciaNormalizacion(qint64 diff)
{
    _diferencia += diff;
    Q_EMIT(tiempoChanged());
    _normalizado++;
    Q_EMIT(normalizadoChanged());
}

void Reporte::restarDiferenciaNormalizacion(qint64 diff)
{
    _diferencia -= diff;
    Q_EMIT(tiempoChanged());
    _normalizado--;
    Q_EMIT(normalizadoChanged());
}

void Reporte::borrarDiferenciaNormalizacion()
{
    _diferencia = 0;
    _normalizado = 0;
    Q_EMIT(tiempoChanged());
    Q_EMIT(normalizadoChanged());
}*/
