/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 13 oct. 2018
**
****************************************************************************/

#include "ReportManagement.h"
#include <QDebug>
#include "../tiempo/TimeEntry.h"
#include <QTime>
#include "Reloj.h"
#include "ReportTableModel.h"
#include "Funciones.h"
#include "../tareas/Task.h"

ReportManagement::ReportManagement(QObject *parent, TTSettings *settings, ReportTableModel *model,
                                   TimeStore *timeStore, TaskStore *taskStore, ProjectStore *projectStore,
                                   WorkOrderStore *woStore) :
    QObject(parent),
    _settings(settings),
    _model(model),
    _timeStore(timeStore),
    _lastActiveTask(nullptr),
    _weekIsComplete(false)
{
    qDebug() << "ReportManagement::ReportManagement: settings " << _settings;
    connect(timeStore, &TimeStore::timeNotification, this, &ReportManagement::slotTimeNotification);
    connect(taskStore, &TaskStore::taskNotification, this, &ReportManagement::slotTaskNotification);
    connect(projectStore, &ProjectStore::projectNotification, this, &ReportManagement::slotProjectNotification);
    connect(woStore, &WorkOrderStore::woNotification, this, &ReportManagement::slotWoNotification);
    connect(Reloj::instance(), &Reloj::currentTimeChanged, this, &ReportManagement::processWorkedTimeClockUpdate, Qt::UniqueConnection);
    connect(_settings, &TTSettings::agrupacionReportesChanged, this, &ReportManagement::slotGroupingChanged);
    connect(_settings, &TTSettings::limitesJornadaChanged, this, &ReportManagement::recalculateReports);
    connect(_settings, &TTSettings::decimalesChanged, this, &ReportManagement::recalculateReports);
    connect(_settings, &TTSettings::accumulatedProjectReportsThresholdChanged, this, &ReportManagement::slotAccumulatedProjectReportsThresholdChanged);
}

ReportManagement::~ReportManagement()
{
}

QDateTime ReportManagement::firstWorkingDayOfCurrentWeek(int &numDays) const
{
    QDateTime now = Reloj::currentDateTime();
    now.setTime(QTime(0, 0, 0, 0));
    return firstWorkingDayOfWeek(now, numDays);
}

QDateTime ReportManagement::firstWorkingDayOfWeek(const QDateTime &reference, int &numDays) const
{
    return calcularPrimerDiaSemana(reference, _settings->firstDayOfWeek(), _settings->lastDayOfWeek(), numDays);
}

void ReportManagement::loadWeekMetadata(const QDateTime ref)
{
    // carga la información relacionda con los días de la semana que cubre el día referenciado.
    // no carga ni calcula ningún reporte.
    int numDays = 0;
    QDateTime firstDay = calcularPrimerDiaSemana(ref, _settings->firstDayOfWeek(), _settings->lastDayOfWeek(), numDays);
    firstDay.setTime(QTime(0, 0, 0, 0));
    qDebug() << "ReportManagement::loadWeekMetadata: referencia "<<ref<<", settings para first y last son "
             <<_settings->firstDayOfWeek()<<" "<<_settings->lastDayOfWeek()<<". numdays " << numDays<<", first "<< firstDay;
    _model->setWorkingWeekRange(firstDay, numDays);
}

QDateTime ReportManagement::firstWorkingDayOfModel() const
{
    return _model->firstWorkingDay();
}

QDateTime ReportManagement::lastWorkingDayOfModel() const
{
    return _model->lastWorkingDay();
}

void ReportManagement::loadWeekReports(bool transactional)
{
    _lastTimeRefresh = QDateTime();
    _lastActiveTask = nullptr;
    _weekIsComplete = false;
    if (transactional) {
        _model->beginTransactionalLoad();
    }
    // carga los registros de tiempo de la semana y los recorre para contabilizar los tiempos de cada tarea
    QDateTime firstWorkingDay = firstWorkingDayOfModel(),
              lastWorkingDay = lastWorkingDayOfModel();
    QList<TimeEntry*> entries = _timeStore->loadTimeRange(firstWorkingDay, lastWorkingDay.addDays(1));
    processTimeEntryList(entries, nullptr);
    if (transactional) {
        _model->endTransactionalLoad();
    }
}

void ReportManagement::processTimeEntryList(QList<TimeEntry*> entries, Project *matchProject)
{
    qDebug() << "ReportManagement::processTimeEntryList: numEntradas " << entries.size();
    TimeEntry* anteriorEntrada = 0;
    // recorremos los registros uno a uno y vamos recopilando los intervalos de tiempo y a qué tareas/wo
    // corresponden, para írselos pasando al modelo
    for (TimeEntry* entrada : entries) {
        Task* tarea = entrada->task();
        QDateTime entryTime = entrada->time();
        qDebug()<<"processTimeEntryList: entrada "<<(tarea?(QString::number(tarea->id())+" "+tarea->name()):"-1")<<" "<<entryTime;
        if (tarea) {//comienzo de una tarea
            //si había una tarea comenzada, la tenemos que finalizar y contar
            if (anteriorEntrada && anteriorEntrada->task() && (matchProject == nullptr || anteriorEntrada->task()->project() == matchProject)) {
                qDebug()<<"processTimeEntryList: cambio de tarea activa, sumando intervalo de activa anterior";
                // esto actualiza lastTimeRefresh
                processWorkedTimeInterval(anteriorEntrada->task(), anteriorEntrada->time(), entryTime);
            } else {
                //si no había tarea, no hay nada que hacer ni contar, pero hay que actualizar
                //ultimoCalculo porque la próxima vez que contemos, tiene que ser a partir de aquí
                _lastTimeRefresh = entryTime;
            }
        } else {//final de una tarea
            qDebug()<<"ReportManagement::processTimeEntryList: anteriorEntr "<<anteriorEntrada;
            //usamos la entrada anterior para saber qué tarea ha terminado
            //y cuánto ha durado. comprobamos si la entrada anterior tiene tarea;
            //por si hay dos finales de tarea seguidos por error, al menos no nos
            //colgamos, y en ese caso no es necesario sumar.
            if (anteriorEntrada && anteriorEntrada->task() && (matchProject == nullptr || anteriorEntrada->task()->project() == matchProject)) {
                //con la tarea y el comienzo y final, podemos calcular los
                //agregados y sumarlos al modelo
                qDebug()<<"processTimeEntryList: final de tarea activa, sumando intervalo de activa anterior";
                processWorkedTimeInterval(anteriorEntrada->task(), anteriorEntrada->time(), entryTime);
            } else {
                //no tenemos el comienzo de la tarea, quizá es de otra semana
                //podríamos calcular el intervalo tomando como ref las 00:00 horas
                //pero no sabemos a qué tarea corresponde. Como hemos descartado este intervalo,
                //grabamos ultimoCalculo para no volver a tenerlo en cuenta.
                _lastTimeRefresh = entryTime;
            }
        }
        anteriorEntrada = entrada;
    }
    qDebug()<<"ReportManagement::processTimeEntryList: no hay más entradas";
    //si la última entrada era para empezar tarea, hay que procesarla hasta el instante actual
    if (anteriorEntrada && anteriorEntrada->task() && (matchProject == nullptr || anteriorEntrada->task()->project() == matchProject)) {
        if (anteriorEntrada->time() < lastWorkingDayOfModel().addDays(1)) {
            processWorkedTimeLastInterval(anteriorEntrada);
            qDebug() << "ReportManagement::processTimeEntryList: guardando como last active task la " << anteriorEntrada->task()->id();
            _lastActiveTask = anteriorEntrada->task();
        } else {
            qDebug() << "ReportManagement::processTimeEntryList: la última entrada activa una tarea pero está fuera del rango de la semana cargada";
            _weekIsComplete = true;
        }


    }
    qDebug() << "ReportManagement::processTimeEntryList: lastActiveTask " << (_lastActiveTask ? _lastActiveTask->id() : -1)
             << ", lastTimeRefresh " << _lastTimeRefresh << ", weekIsComplete " << _weekIsComplete;

}

void ReportManagement::reloadWeekReports()
{
    // cuando ocurren algunos cambios interesa más recalcular todos los tiempos de la semana que inspeccionar
    // todos los microcambios necesarios y señalizarlos. Para ello, mantenemos los mismos días de la
    // semana pero borramos todos los reportes y conteos de tiempo, así como las marcas de última
    // tarea y último refresco, porque lo vamos a calcular todo de nuevo para el instante actual.
    _model->beginTransactionalLoad();
    _model->clearReports();
    _lastTimeRefresh = QDateTime();
    _lastActiveTask = nullptr;
    _weekIsComplete = false;
    loadWeekReports(false); // esto recalcula los reportes usando los días de semana ya metidos en el modelo
    _model->endTransactionalLoad();
}

// el comienzo y el final se supone que representan entradas de tiempo del usuario, por lo que
// no hay que aplicar todos los límites de jornada. Este intervalo puede ser de varios días o semanas.
void ReportManagement::processWorkedTimeInterval(Task* task, QDateTime beginning, QDateTime end)
{
    qDebug() << "ReportManagement::processWorkedTimeInterval: tarea "<<task->name()<<": "<<beginning<<" "<<end;
    QDateTime firstWorkingDay = firstWorkingDayOfModel(),
              lastWorkingDay = lastWorkingDayOfModel();
    if (beginning.date() == end.date()) { // mismo día
        if (_model->inWeekRange(beginning)) {
            // como son entradas de tiempo, representan interacciones del usuario, por lo que ya no
            // hay que tener en cuenta los límites de jornada
            qint64 intervalo = beginning.msecsTo(end);
            _lastTimeRefresh = end;
            qDebug()<<"ReportManagement::processWorkedTimeInterval: sumando a "<<task->name()<<" "<<beginning<<" intervalo "<<intervalo;
            _model->addWorkedTimeForTask(task, beginning, intervalo);
        }
    } else { //dias distintos
        //si son varios días, sí que hay que tener en cuenta los límites de jornada
        // trataremos por separado tres casos: el primer día del intervalo, el último y los días interiores
        QDateTime partialBeginning = beginning;
        QTime comienzoJornada = _settings->comienzoJornada(),
              finalJornada = _settings->finalJornada();
        QDateTime partialEnd;
        qDebug()<<"ReportManagement::processWorkedTimeInterval: el intervalo es de varios dias";
        // primer día del intervalo
        if (_model->inWeekRange(beginning)) {
            // para el primer día solo se tiene en cuenta el final de jornada. tenemos que ver si
            // contamos hasta el final automático de jornada o hasta el final del día natural
            if (partialBeginning.time() < finalJornada) { // hasta el mismo día a la hora del final automático de jornada
                partialEnd = partialBeginning;
                partialEnd.setTime(finalJornada);
                qDebug()<<"ReportManagement::processWorkedTimeInterval: usando el final de jornada para el primer dia";
            } else { // hasta el final natural del día
                partialEnd = partialBeginning.addDays(1);
                partialEnd.setTime(QTime(0,0,0,0));
            }
            qint64 diff = partialBeginning.msecsTo(partialEnd);
            qDebug()<<"ReportManagement::processWorkedTimeInterval: sumando intervalo primer dia "<<partialBeginning<<" -- "<<partialEnd<<" == "<<diff;
            _lastTimeRefresh = partialEnd;
            _model->addWorkedTimeForTask(task, beginning, diff);
        }

        //dias interiores
        partialBeginning = beginning.addDays(1);
        // los días de en medio no tienen interacciones, por lo que se cuenta solo
        // entre los limites de jornada
        while (partialBeginning.date() < end.date()) {
            if (_model->inWeekRange(partialBeginning)) {
                partialBeginning.setTime(comienzoJornada);
                partialEnd = partialBeginning;
                partialEnd.setTime(finalJornada);
                qint64 diff = partialBeginning.msecsTo(partialEnd);
                _lastTimeRefresh = partialEnd;
                qDebug()<<"ReportManagement::processWorkedTimeInterval: sumando intervalo dia medio "<<partialBeginning<<" == "<<diff;
                _model->addWorkedTimeForTask(task, partialBeginning, diff);
            }
            partialBeginning = partialBeginning.addDays(1);
        }

        //último dia del intervalo
        partialBeginning = end;
        if (_model->inWeekRange(partialBeginning)) {
            // para el último día solo hay que tener en cuenta el comienzo de jornada, porque
            // el final es una interacción de usuario.
            if (end.time() > comienzoJornada) { // contamos desde el límite automático de jornada
                partialBeginning.setTime(comienzoJornada);
                qDebug()<<"ReportManagement::processWorkedTimeInterval: usando el comienzo de jornada para el último dia";
            } else { // contamos desde el comienzo del día natural
                partialBeginning.setTime(QTime(0,0,0,0));
            }
            qint64 diff = partialBeginning.msecsTo(end);
            _lastTimeRefresh = end;
            qDebug()<<"ReportManagement::processWorkedTimeInterval: sumando intervalo último dia "<<partialBeginning<<" -- "<<end<<" == "<<diff;
            _model->addWorkedTimeForTask(task, partialBeginning, diff);
        }

    }
}

void ReportManagement::processWorkedTimeLastInterval(const TimeEntry* anteriorEntrada)
{
    // procesa el tiempo trabajado desde el anterior refresco hasta el momento actual (sin entrada de tiempo
    // para el momento actual)
    QDateTime current = Reloj::currentDateTime();
    QTime comienzoJornada = _settings->comienzoJornada();
    QTime finalJornada = _settings->finalJornada();
    QDateTime comienzoIntervalo, finalIntervalo;

    // el último intervalo puede ser particularmente grande, incluso de semanas anteriores si la anterior
    // entrada es lo suficientemente antigua. Tenemos que limitar a la semana cargada.
    // como muy pronto, empieza el primer día de la semana laboral, no nos interesan semanas anteriores
    if (anteriorEntrada->time().date() < firstWorkingDayOfModel().date()) {
        comienzoIntervalo = firstWorkingDayOfModel();
        comienzoIntervalo.setTime(comienzoJornada);
    } else {
        comienzoIntervalo = anteriorEntrada->time();
    }
    // termina en el moment actual. si la semana está terminada, termina como muy tarde incluyendo
    // el último día de la semana
    if (_model->isAccumulated()) {
        finalIntervalo = current;
    } else if (current < lastWorkingDayOfModel().addDays(1)) {
        finalIntervalo = current;
    } else {
        finalIntervalo = lastWorkingDayOfModel().addDays(1);
        _weekIsComplete = true;
    }

    qDebug() << "ReportManagement::processWorkedTimeLastInterval: la última entrada ha activado una tarea que hay que contar, "
            << "desde " << comienzoIntervalo << " hasta " << finalIntervalo;



    QDateTime itDay = comienzoIntervalo;
    // - intervalo puede tener varios días
    // - intervalo de solo un dia
    while(itDay.date() <= finalIntervalo.date()) {
        QDateTime comienzoCuenta, finalCuenta;
        if (itDay.date() == comienzoIntervalo.date()) {
            //primer dia del intervalo. itDay es el comienzo y es interacción de usuario.
            //además, podría ser el único día del intervalo, y por tanto también el último.
            comienzoCuenta = itDay;
            if (itDay.time() > finalJornada) {
                // la interacción de usuario es después del final de jornada. por tanto, se
                // cuenta hasta las 00:00 o hasta el current si es menor.
                finalCuenta = comienzoCuenta.addDays(1);
                finalCuenta.setTime(QTime(0, 0, 0, 0));
                qDebug() << "ReportManagement::processWorkedTimeLastInterval: el comienzo del intervalo es "
                        << "mayor al final de jornada; contando hasta el final del día";
            } else {
                // si aún no se ha llegado al final de jornada, contamos hasta esta solo.
                finalCuenta = comienzoCuenta;
                finalCuenta.setTime(finalJornada);
            }
            // si es un intervalo de un solo día, y vamos a rebasar el final del intervalo,
            // usamos el final del intervalo como tope.
            if (finalIntervalo < finalCuenta) {
                finalCuenta = finalIntervalo;
                qDebug() << "ReportManagement::processWorkedTimeLastInterval: el intervalo es un solo día, "
                        << "y el final viene antes, contando hasta el final del intervalo";
            }
        } else {
            //el intervalo cubre varios días y el primero ya se ha procesado.
            //podría ser también el último día del intervalo.
            // los días medios se cuentan de comienzoJornada a finalJornada
            comienzoCuenta = itDay;
            comienzoCuenta.setTime(comienzoJornada);
            finalCuenta = itDay;
            finalCuenta.setTime(finalJornada);

            //si es el último dia, podría pasar que el final del intervalo no haya llegado
            //al comienzo de jornada. En este caso, no hay que contar el último dia.
            //para ello, marcamos la cuenta con dates inválidos.
            if (finalIntervalo < comienzoCuenta) {
                comienzoCuenta = QDateTime();
                finalCuenta = QDateTime();
                qDebug() << "ReportManagement::processWorkedTimeLastInterval: el final del intervalo es anterior "
                        << "al comienzo de jornada; no se cuenta este último día";
            } else {
                //si es el último día, también podría pasar  que el final del intervalo sea antes
                //que el final de jornada, y hay que usarlo como tope entonces
                if (finalIntervalo < finalCuenta) {
                    finalCuenta = finalIntervalo;
                    qDebug() << "ReportManagement::processWorkedTimeLastInterval: el final del intervalo es anterior "
                            << "al final de jornada en el último día; contando hasta el final del intervalo solo";
                }
                //si es el último día pero se ha pasado del final de jornada, se queda como está y
                //se cuenta hasta final de jornada igual que los días intermedios del intervalo
            }
        }
        //para cada día del intervalo sumamos su parte, si es que hay algo que sumar
        if (comienzoCuenta.isValid() && !comienzoCuenta.isNull()) {
            qint64 diff = comienzoCuenta.msecsTo(finalCuenta);
            if (diff > 0) {
                qDebug() << "ReportManagement::processWorkedTimeLastInterval: sumando intervalo desde "
                        << comienzoCuenta << " hasta " << finalCuenta << ": " << diff << " msecs a la tarea "
                        << anteriorEntrada->task()->name();
                _model->addWorkedTimeForTask(anteriorEntrada->task(), comienzoCuenta, diff);
                _lastTimeRefresh = finalCuenta;
            }
        }
        itDay = itDay.addDays(1);
    }
    qDebug() << "ReportManagement::processWorkedTimeLastInterval: ultimoCalculo finalmente queda en "
            << _lastTimeRefresh;
}

void ReportManagement::processWorkedTimeNewActiveTask(Task *oldT, Task *newT)
{
    qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: cambio de tarea "
             << (oldT?oldT->name():"NULL") << " a tarea "
             << (newT?newT->name():"NULL");
    qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: ultimo calculo " << _lastTimeRefresh;
    // un cambio de tarea implica actividad del usuario
    QDateTime current = Reloj::currentDateTime();
    if (oldT) {
        // si había una tarea activa, hay que sumar tiempo hasta el instante actual
        qint64 diff = 0;
        //aquí hay que dejar de suponer que es el dia siguiente, y contar y sumar para cada dia.
        //además, hay que tener en cuenta los límites de jornada.
        if (_lastTimeRefresh.date() == current.date()) {
            diff = _lastTimeRefresh.msecsTo(current);
            qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: mismo dia que último cálculo, "
                     << "contamos hasta current, " << diff << " msecs";
            //aquí no se tienen en cuenta los límites porque es acción de usuario
            _model->aboutToEditModel();
            _model->addWorkedTimeForTask(oldT, _lastTimeRefresh, diff);
            // como hemos sumado hasta current, lo guardamos como último cálculo
            _lastTimeRefresh = current;
        } else {
            //al ser varios días, podemos aplicar el limite de jornada.
            //el primer día
            QTime finalJornada = _settings->finalJornada();
            QDateTime finIntervalo;
            if (_lastTimeRefresh.time() <= finalJornada) {
                qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: primer día, contamos hasta final de jornada";
                //si no habíamos cruzado el final de la jornada, entonces contamos como mucho
                //hasta el final de la jornada
                finIntervalo = _lastTimeRefresh;
                finIntervalo.setTime(finalJornada);
            } else {
                //si ya habíamos cruzado el final de jornada, contamos hasta medianoche
                finIntervalo = _lastTimeRefresh.addDays(1);
                finIntervalo.setTime(QTime(0, 0, 0, 0));
                qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: primer día después de final de jornada, "
                         << "contamos hasta medianoche";
            }
            diff = _lastTimeRefresh.msecsTo(finIntervalo);
            qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: sumando " << diff
                     << " msecs del primer día";
            if (diff > 0) {
                _model->aboutToEditModel();
                _model->addWorkedTimeForTask(oldT, _lastTimeRefresh, diff);
                _lastTimeRefresh = finIntervalo;
            }
            //ahora los días interiores, que suman siempre el tiempo de jornada
            QDateTime diaInterior = _lastTimeRefresh.addDays(1);
            QTime comienzoJornada = _settings->comienzoJornada();
            qint64 tiempoMaximoJornada = comienzoJornada.msecsTo(finalJornada);
            while(diaInterior.date() < current.date()) {
                qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: dia interior " << diaInterior.date()
                         << ", sumamos " << tiempoMaximoJornada << " msecs";
                _model->aboutToEditModel();
                _model->addWorkedTimeForTask(oldT, diaInterior, tiempoMaximoJornada);
                _lastTimeRefresh = diaInterior;
                _lastTimeRefresh.setTime(finalJornada);
                diaInterior = diaInterior.addDays(1);
            }
            //y ahora el último día, el current
            qint64 diff = 0;
            if (current.time() < comienzoJornada) {
                //si aún no hemos llegado al comienzo de jornada, contamos desde medianoche
                diff = QTime(0, 0, 0, 0).msecsTo(current.time());
                qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: current, antes del comienzo de jornada, "
                         << "sumando desde medianoche, " << diff << " msecs";
            } else {
                //si hemos pasado el comienzo de la jornada solo contamos desde este
                diff = comienzoJornada.msecsTo(current.time());
                qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: current, después del comienzo de jornada, "
                         << "sumando desde comienzo de jornada, " << diff << " msecs";
            }
            if (diff > 0) {
                _model->aboutToEditModel();
                _model->addWorkedTimeForTask(oldT, current, diff);
                _lastTimeRefresh = current;
            }
            _weekIsComplete = (current >= lastWorkingDayOfModel().addDays(1));
        }
    } else {
        //como no había una tarea activa, no hay que sumar nada. Pero hay que actualizar
        //la fecha de último cálculo para que se empiece a contar desde ahora la siguiente evaluación
        _lastTimeRefresh = current;
        _weekIsComplete = (current >= lastWorkingDayOfModel().addDays(1));
    }
    // para la nueva tarea solo hay que asegurarse de que hay entradas para las wo y tarea
    // no hay que sumar
    if (newT) {
        qDebug() << "ReportManagement::processWorkedTimeNewActiveTask: cambio de tarea. creamos las estructuras y delegates para la nueva tarea, con tiempo 0";
        _model->aboutToEditModel();
        _model->addWorkedTimeForTask(newT, _lastTimeRefresh, 0);
    }
    _model->editModelFinished();
}

void ReportManagement::processWorkedTimeClockUpdate()
{
    // procesa una nueva actualización del reloj desde el último refresco. Entre medias no ha pasado
    // ninguna acción del usuario.

    QDateTime current = Reloj::currentDateTime();
    QTime comienzoJornada = _settings->comienzoJornada(),
          finalJornada = _settings->finalJornada();
    qint64 diff = 0;
    qDebug() << "ReportManagement::processWorkedTimeClockUpdate: tarea activa " << (_lastActiveTask ? _lastActiveTask->id() : -1)
             <<", ultimo calculo "<<_lastTimeRefresh << ". current " << current;
    // solo hay que modificar los conteos si hay una tarea activa, y sumárselos a ella
    if (_lastActiveTask) {
        // si estamos en el mismo día que el último refresco, tan solo contamos la diferencia entre ambos momentos
        if (current.date() == _lastTimeRefresh.date()) {
            QDateTime nuevaFechaCalculo;
            if (finalJornada < _lastTimeRefresh.time()) {
                // ya se ha contado tiempo tras el final de jornada, así que
                // no se tiene en cuenta
                diff = _lastTimeRefresh.msecsTo(current);
                nuevaFechaCalculo = current;
                qDebug() << "ReportManagement::processWorkedTimeClockUpdate: contando más allá del final de jornada";
            } else {
                if (finalJornada <= current.time()) {
                    // se ha alcanzado el final de jornada desde el último ajuste,
                    // contamos hasta el final de jornada solo.
                    nuevaFechaCalculo = current;
                    nuevaFechaCalculo.setTime(finalJornada);
                    diff = _lastTimeRefresh.msecsTo(nuevaFechaCalculo);
                    qDebug() << "ReportManagement::processWorkedTimeClockUpdate: contando hasta el final de jornada";
                } else {
                    // el final de jornada no ha llegado aún.
                    // si ultimoCalculo es de hoy, no hay que cambiar la hora
                    diff = _lastTimeRefresh.msecsTo(current);
                    nuevaFechaCalculo = current;
                    qDebug() << "ReportManagement::processWorkedTimeClockUpdate: contando hasta el momento actual: " << diff;
                }
            }
            if (diff > 0) {
                _model->addWorkedTimeForTask(_lastActiveTask, _lastTimeRefresh, diff);
                _lastTimeRefresh = nuevaFechaCalculo;
            }
        } else { // varios dias.
            // contamos primero hasta el final del primer dia, mirando si hay que contar el final de jornada
            // esto solo lo hacemos si el primer día está dentro de los días de la semana procesada.
            if (_model->inWeekRange(_lastTimeRefresh)) {
                QDateTime finalDia = _lastTimeRefresh;
                if (_lastTimeRefresh.time() <= finalJornada) {
                    finalDia.setTime(finalJornada);
                    qDebug() << "ReportManagement::processWorkedTimeClockUpdate: " << _lastTimeRefresh.date()
                             << " se cuenta solo hasta final de jornada";
                } else {
                    finalDia = finalDia.addDays(1);
                    finalDia.setTime(QTime(0, 0, 0, 0));
                    qDebug() << "ReportManagement::processWorkedTimeClockUpdate: " << _lastTimeRefresh.date()
                             << " se cuenta completo";
                }
                diff = _lastTimeRefresh.msecsTo(finalDia);
                if (diff > 0) {
                    _model->addWorkedTimeForTask(_lastActiveTask, _lastTimeRefresh, diff);
                    _lastTimeRefresh = finalDia;
                }
            }

            QDateTime d = _lastTimeRefresh.addDays(1);
            diff = comienzoJornada.msecsTo(finalJornada); // la duración total de jornada
            //se cuentan los días interiores, que siempre suman el mismo tiempo, la duración de la jornada
            bool enRango = _model->inWeekRange(d);
            while (enRango && d.date() < current.date()) {
                _model->addWorkedTimeForTask(_lastActiveTask, d, diff);
                d = d.addDays(1);
                _lastTimeRefresh = d;
                _lastTimeRefresh.setTime(finalJornada);
                enRango = _model->inWeekRange(d);
            }

            if (_model->inWeekRange(current)) {
                // y después contamos el último día (el día actual). Si aún no se ha llegado hasta el comienzo
                // de la jornada no se cuenta. Además, se mira si se cuenta hasta el final
                // de jornada, o hasta el final del día.
                QDateTime principioDia = current;
                QDateTime finalDia = current;
                if (current.time() > comienzoJornada) {
                    principioDia.setTime(comienzoJornada);
                    qDebug() << "ReportManagement::processWorkedTimeClockUpdate: " << current.date() << " se cuenta "
                             << "solo desde el comienzo de jornada";
                    if (current.time() > finalJornada) {
                        finalDia.setTime(finalJornada);
                        qDebug() << "ReportManagement::processWorkedTimeClockUpdate: " << current.date() << " se cuenta "
                                 << "solo hasta el final de jornada";
                    }
                }
                diff = principioDia.msecsTo(finalDia);
                if (diff > 0) {
                    _lastTimeRefresh = finalDia;
                    _model->addWorkedTimeForTask(_lastActiveTask, current, diff);
                }
            }
        }
    }
    // en cualquier caso, si hemos sobrepasado el rango de la semana cargada, la semana está completa
    _weekIsComplete = (current >= lastWorkingDayOfModel().addDays(1));
    qDebug() << "ReportManagement::processWorkedTimeClockUpdate: lastActiveTask " << (_lastActiveTask ? _lastActiveTask->id() : -1)
             << ", lastTimeRefresh " << _lastTimeRefresh << ", weekIsComplete " << _weekIsComplete;
}

void ReportManagement::slotTimeNotification(TimeStore::TimeNotifications notification, qint64 entryId)
{
    Q_UNUSED(entryId);
    qDebug() << "ReportManagement::slotTimeNotification: notif "<<notification;
    switch (notification) {
        case TimeStore::TIMENOTIF_NEWENTRY: {
            // if the loaded week is complete, then new entries won't change anything here
            qDebug() << "ReportManagement::slotTimeNotification: nuevo registro de tiempo. weekComplete "
                     << _weekIsComplete << ", lastActiveTask " << _lastActiveTask;
            if (!_weekIsComplete) {
                TimeEntry *lastTimeEntry = _timeStore->mostRecentEntry();
                if (_lastActiveTask != lastTimeEntry->task()) {
                    Task *oldActiveTask = _lastActiveTask;
                    _lastActiveTask = lastTimeEntry->task();
                    processWorkedTimeNewActiveTask(oldActiveTask, _lastActiveTask);
                }
            }
            break;
        }
        case TimeStore::TIMENOTIF_UPDATEDATA: {
            recalculateReports();
            break;
        }
        default:
            break;
    }
}

void ReportManagement::slotTaskNotification(TaskStore::TaskNotifications notification, int taskId)
{
    Q_UNUSED(taskId);
    qDebug() << "ReportManagement::slotTaskNotification: notif "<<notification;
    switch (notification) {
        case TaskStore::TASKNOTIF_UPDATEDATA: {
            recalculateReports();
            break;
        }
        default:
            break;
    }
}

void ReportManagement::slotProjectNotification(ProjectStore::ProjectNotifications notification, int projectId)
{
    Q_UNUSED(projectId);
    qDebug() << "ReportManagement::slotProjectNotification: notif "<<notification;
    switch (notification) {
        case ProjectStore::PROJECTNOTIF_UPDATEDATA: {
            recalculateReports();
            break;
        }
        default:
            break;
    }
}

void ReportManagement::slotWoNotification(WorkOrderStore::WorkOrderNotifications notification, int woId)
{
    Q_UNUSED(woId);
        qDebug() << "ReportManagement::slotWoNotification: notif "<<notification;
        switch (notification) {
            case WorkOrderStore::WONOTIF_UPDATEDATA: {
                recalculateReports();
                break;
            }
            default:
                break;
        }
}

void ReportManagement::loadAccumulatedReports(bool transactional)
{
    Project *filter = _model->projectToFilter();
    if (filter) {
        if (!_model->isAccumulated()) { // solo guardamos el primer día de la semana si estábamos en reportes semanales
            _tmpFirstDayOfModelWeek = firstWorkingDayOfModel();
        }
        qDebug() << "ReportManagement::loadAccumulatedReports: primer dia de semana guardado " << _tmpFirstDayOfModelWeek;
        if (transactional) {
            _model->beginTransactionalLoad();
        }
        _model->clearModel();
        _model->setAccumulatedMode(true);
        _model->setWorkingWeekRange(QDateTime(), 0); // ninguna columna de días. solo la de totales.
        _lastTimeRefresh = QDateTime();
        _lastActiveTask = nullptr;
        _weekIsComplete = false;
        int daysThreshold = _settings->accumulatedProjectReportsThreshold();
        QDateTime endTimeInterval = Reloj::currentDateTime(),
                beginTimeInterval = endTimeInterval.addDays(-daysThreshold);
        QList<TimeEntry*> entries = _timeStore->loadTimeRange(beginTimeInterval, endTimeInterval);
        qDebug() << "ReportManagement::loadAccumulatedReports: procesando acumulado para el proyecto en el rango "
                 << beginTimeInterval << " - " << endTimeInterval;
        processTimeEntryList(entries, filter);
        if (transactional) {
            _model->endTransactionalLoad();
        }
    }
}

void ReportManagement::comeBackFromAccumulatedReports()
{
    // borra el modelo, mete los metadatos de la semana y vuelve a cargar los reportes
    // semanales, filtrados por el mismo proyecto
    _model->clearModel();
    _model->setAccumulatedMode(false);
    loadWeekMetadata(_tmpFirstDayOfModelWeek);
    loadWeekReports(true);
    _tmpFirstDayOfModelWeek = QDateTime();
}

void ReportManagement::slotGroupingChanged()
{
    TTSettings::AgrupacionReportes gr = _settings->agrupacionReportes();
    qDebug() << "ReportManagement::slotGroupingChanged: grouping "<<gr<<", accum "<<_model->isAccumulated()
             << ", projectToFilter " << _model->projectToFilter();
    if (_model->isAccumulated()) {
        if (gr == TTSettings::AGRUPAR_WOS) {
            // si el agrupamiento es por wos, entonces no se puede mantener el filtrado por proyecto
            // ni el acumulado. volvemos a un reporte de semana.
            _model->clearModel();
            _model->setAccumulatedMode(false);
            _model->setProjectToFilter(nullptr);
            loadWeekMetadata(_tmpFirstDayOfModelWeek);
            loadWeekReports(true);
        } else {
            // para cualquier otro agrupamiento, podemos mantener el filtrado por proyecto y el
            // acumulado, pero hay que recalcular
            loadAccumulatedReports(true);
        }
    } else if (_model->projectToFilter() == nullptr) {
        // si es un reporte semanal normal sin filtrado, entonces simplemente recargamos
        reloadWeekReports();
    } else {
        if (gr == TTSettings::AGRUPAR_WOS) {
            // si el agrupamiento es por wos, entonces no se puede mantener el filtrado por proyecto.
            _model->clearReports();
            _model->setProjectToFilter(nullptr);
            loadWeekReports(true);
        } else {
            // para cualquier otro agrupamiento, podemos mantener el filtrado por proyecto, pero hay que recalcular
            _model->clearReports();
            loadWeekReports(true);
        }
    }
}

void ReportManagement::recalculateReports()
{
    if (_model->isAccumulated()) {
        loadAccumulatedReports(true);
    } else {
        reloadWeekReports();
    }
}

void ReportManagement::slotAccumulatedProjectReportsThresholdChanged()
{
    qDebug() << "ReportManagement::slotAccumulatedProjectReportsThresholdChanged: isAccumulated " << _model->isAccumulated();
    if (_model->isAccumulated()) {
        loadAccumulatedReports(true);
    }
}

