/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 9 oct. 2023
**
****************************************************************************/

#ifndef SRC_REPORTES_REPORTVIEWMODEL_H_
#define SRC_REPORTES_REPORTVIEWMODEL_H_

#include <QObject>
#include <QDateTime>
#include "../projects/ProjectStore.h"

class TTSettings;
class ReportTableModel;
class ReportManagement;
class TimeStore;
class TaskStore;
class WorkOrderStore;
class DescriptionManagement;
class Project;

class ReportViewModel : public QObject
{
    Q_OBJECT

    // data from loaded task

    Q_PROPERTY(ReportTableModel* tableModel READ tableModel CONSTANT)
    Q_PROPERTY(int weekSelectorValue READ weekSelectorValue WRITE setWeekSelectorValue NOTIFY weekSelectorValueChanged)
    Q_PROPERTY(QString weekLabelText READ weekLabelText NOTIFY weekLabelTextChanged)
    Q_PROPERTY(bool isCurrentWeek READ isCurrentWeek NOTIFY isCurrentWeekChanged)
    Q_PROPERTY(QString projectToFilterName READ projectToFilterName NOTIFY projectToFilterNameChanged)
    Q_PROPERTY(bool isFiltered READ isFiltered NOTIFY projectToFilterNameChanged)
    Q_PROPERTY(bool isAccumulated READ isAccumulated NOTIFY isAccumulatedChanged)

    public:
        ReportViewModel(QObject* parent, TTSettings *settings, TimeStore *timeStore, TaskStore *taskStore, ProjectStore *projectStore, WorkOrderStore *woStore);
        virtual ~ReportViewModel();

        ReportTableModel *tableModel() const;
        int weekSelectorValue() const;
        void setWeekSelectorValue(int newValue);
        Q_INVOKABLE QString weekSelectorText(int weekDiffWithToday) const;
        QString weekLabelText() const;
        void setWeekLabelText(const QString &newText);
        bool isCurrentWeek() const;
        void setIsCurrentWeek(bool value);
        Q_INVOKABLE void filterByProject(int projectId);
        QString projectToFilterName() const;
        bool isFiltered() const;
        bool isAccumulated() const;
        Q_INVOKABLE void switchProjectReportMode();

    public Q_SLOTS:
        void initialize();


    Q_SIGNALS:
        void weekSelectorValueChanged();
        void weekLabelTextChanged();
        void isCurrentWeekChanged();
        void projectToFilterNameChanged();
        void isAccumulatedChanged();

    /*private Q_SLOTS:
        void slotNotifications(TimeStore::TimeNotifications notification, qint64 entryId);*/
    private Q_SLOTS:
        void calculateCurrentWeekFlag();
        void slotProjectNotification(ProjectStore::ProjectNotifications notification, int projectId);
        void slotWorkingWeekRangeChanged();

    private:
        QString formatTextYearWeek(const QDateTime &firstDay) const;
        void loadNewWeek(const QDateTime &firstDay);
        void loadAccumulatedReports();
        void comeBackFromAccumulatedReports();

        ReportTableModel *_tableModel;
        TTSettings *_settings;
        ReportManagement *_management;
        int _weekSelectorValue;
        QString _weekLabelText;
        bool _isCurrentWeek;
        QDateTime _weekSelectorReference;
        ProjectStore *_projectStore;
        int _numberOfWorkingDays;

};

#endif /* SRC_REPORTES_REPORTVIEWMODEL_H_ */
