/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 16 feb. 2019
**
****************************************************************************/

#include "DescriptionManagement.h"
#include "tareas/Task.h"
#include <qqml.h>
#include <QDebug>
#include "TTSettings.h"
#include <QClipboard>
#include <QGuiApplication>
#include "Reloj.h"
#include <QFile>
#include <QList>

const qint64 DescriptionManagement::_expirationTime = 120; // segundos

DescriptionManagement::DescriptionManagement(QObject *parent, TTSettings *settings, TaskStore *taskStore) :
QObject(parent),
#ifdef FEATURE_TIMESHEETJIRAINTEGRATION
_generationOngoing(nullptr),
#endif
_settings(settings),
_taskStore(taskStore)
{
    qmlRegisterUncreatableType<DescriptionModel>("TimeTracking.models", 1, 0, "DescriptionModel", "No se puede crear un DescriptionModel");
    connect(taskStore, &TaskStore::taskNotification, this, &DescriptionManagement::slotTaskNotifications, Qt::QueuedConnection);
}

DescriptionManagement::~DescriptionManagement()
{
}

DescriptionModel* DescriptionManagement::descriptionModel(Task *task)
{
    // obtiene (y crea) el modelo de descripción para la tarea dada
    qDebug() << "DescriptionManagement::descriptionModel: tarea " << (task ? task->id() : -1)
             << ", " << (task ? task->name() : "NULL");
    DescriptionModel* desc = _descriptions.value(task, nullptr);
    if (!desc) {
        desc = new DescriptionModel(this, task);
        _descriptions.insert(task, desc);
        _tasks.insert(task->id(), task);
        connect(desc, &DescriptionModel::stateChanged, this, &DescriptionManagement::slotDescriptionStateChanged);
    }
    qDebug() << "DescriptionManagement::descriptionModel: devolviendo desc con estado "
             << desc->state();
    return desc;
}

void DescriptionManagement::loadDescription(Task* task)
{
    // intenta cargar la descripción en el portapapeles si es posible, o arrancar el proceso de
    // generación de la descripción para que se termine copiando.
    DescriptionModel *desc = descriptionModel(task);
    qDebug() << "GestionDescripciones::cargarDescripcion: tarea " << task->name()
             << "; cargando desc en estado " << desc->state();
    if (desc->state() == DescriptionModel::STATE_AVAILABLE) {
        copyToClipboard(desc); // si ya tenemos disponible la descripción, la copiamos directamente
    } else if (desc->state() == DescriptionModel::STATE_NOTAVAILABLE) {
#ifdef FEATURE_TIMESHEETJIRAINTEGRATION
        if (task->code().isEmpty()) {
#else
        if (true) {
#endif
            loadLocalDescription(task); // si no está disponible pero es una descripción local, la generamos y copiamos
        }
#ifdef FEATURE_TIMESHEETJIRAINTEGRATION
        else {
            // si no está disponible y es una descripción de Jira, entonces intentamos usar el proceso auxiliar.
            // si el proceso no está ocupado, usarlo para hacer la query y cambiar el modelo descripcion a cargando
            //conectar slot con el resultado y cambiar el modelo de nuevo y insertarle el resultado
            if (_process.state() == QProcess::NotRunning) {
                startGeneration(task, desc);
            } else {
                qDebug() << "GestionDescripciones::cargarDescripcion: ya hay una carga en curso";
            }
        }
#endif
    }
}

void DescriptionManagement::loadLocalDescription(Task *task)
{
    // cargaremos una descripción local en el portapepeles. usaremos la primera linea de la descripción.
    DescriptionModel *desc = _descriptions.value(task, nullptr);
    if (desc) {
        qDebug() << "DescriptionManagement::loadLocalDescription: tarea " << task->id()
                 << " " << task->name() << " sin code, seteando estado disponible";
        QStringList lineas = task->description().split('\n');
        // copiamos solo la primera linea; así podemos usar la primera linea para
        // forzar la desc que queremos copiar al unit4, y usamos el resto de lineas
        // para una descripción en cristiano.
        QString descStr = lineas.isEmpty() ? "" : lineas.first();
        desc->setDescription(descStr);
        desc->setState(DescriptionModel::STATE_AVAILABLE);
        desc->markAsUpdated();
        copyToClipboard(desc);
    }
}

#ifdef FEATURE_TIMESHEETJIRAINTEGRATION
void DescriptionManagement::startGeneration(Task *task, DescriptionModel * descModel)
{
    connect(&_process, &QProcess::started, this, &DescriptionManagement::slotProcessStarted, Qt::UniqueConnection);
    connect(&_process, &QProcess::errorOccurred, this, &DescriptionManagement::slotProcessError, Qt::UniqueConnection);
    QString procesoPath = _settings->descripcionesPath();
    QString jiraUser = _settings->usuarioJira();
    QString jiraToken = _settings->tokenJira();
    QStringList args;
    if (jiraUser.isEmpty()) {
        qWarning() << "DescriptionManagement::startGeneration: Error: no hay un usuario válido para Jira";
        Q_EMIT(descriptionError(DESCERROR_BADUSERNAME));
    } else if (jiraToken.isEmpty()) {
        qWarning() << "DescriptionManagement::startGeneration: Error: no hay un token válido para Jira";
        Q_EMIT(descriptionError(DESCERROR_BADTOKEN));
    } else if (!QFile::exists(procesoPath)) {
        qWarning() << "DescriptionManagement::startGeneration: Error: no existe ningún fichero " << procesoPath;
        Q_EMIT(descriptionError(DESCERROR_BADPATH));
    } else {
        descModel->setState(DescriptionModel::STATE_LOADING);
        args << "-u" << jiraUser
             << "-t" << jiraToken
             << "-q" << QString("key = %1").arg(task->code());
        qDebug() << "GestionDescripciones::iniciarCarga: Arrancando proceso " << procesoPath << " con params " << args
                 << " para desc de tarea " << task->id() << " " << task->name();

        _generationOngoing = task;
        _process.start(procesoPath, args);
    }
}


void DescriptionManagement::slotProcessStarted()
{
    qDebug() << "proceso started, conectando a finished";
    connect(&_process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
        [=](int exitCode, QProcess::ExitStatus exitStatus){ slotProcessFinished(exitCode, exitStatus); });
}

void DescriptionManagement::slotProcessError(QProcess::ProcessError error)
{
    qWarning() << "El proceso de las descripciones ha dado error: " << error;
    DescriptionModel *desc = _descriptions.value(_generationOngoing, nullptr);
    if (desc) {
        desc->setState(DescriptionModel::STATE_NOTAVAILABLE);
    }
    _generationOngoing = nullptr;
    Q_EMIT(descriptionError(DESCERROR_PROCESSERROR));
}

void DescriptionManagement::slotProcessFinished(int exitCode, QProcess::ExitStatus status)
{
    // cuando el proceso de generación de descripción termina, capturamos toda la salida y la parseamos
    // para obtener la descripción. Con ella, actualizamos el modelo y copiamos al portapapeles.
    QString descripcion = "";
    bool errorNotified = false;
    if (status == QProcess::NormalExit && exitCode == 0) {
        QString datos = QString(_process.readAllStandardOutput());
        qDebug() << "salida: " << datos;
        descripcion = parseDescription(datos);
    } else {
        qWarning() << "El proceso de las descripciones ha terminado de forma anormal: exitCode "
                   << exitCode << ", status " << status;
        qWarning() << "salida "<<_process.readAllStandardError() << " "<<_process.readAllStandardOutput();
        Q_EMIT(descriptionError(DESCERROR_BADPROCESSEXECUTION));
        errorNotified = true;
    }
    DescriptionModel *desc = _descriptions.value(_generationOngoing, nullptr);
    if (desc) {
        if (descripcion.isEmpty()) {
            desc->setState(DescriptionModel::STATE_NOTAVAILABLE);
            if (!errorNotified) {
                Q_EMIT(descriptionError(DESCERROR_EMPTYDESCRIPTION));
            }
        } else {
            qDebug() << "DescriptionManagement::slotProcessFinished: tarea " << _generationOngoing->id()
                     << " " << _generationOngoing->name();
            desc->setDescription(descripcion);
            desc->setState(DescriptionModel::STATE_AVAILABLE);
            desc->markAsUpdated();
            copyToClipboard(desc);
            _expirations.removeOne(desc);
            _expirations.append(desc);
            connect(Reloj::instance(), &Reloj::currentTimeChanged, this, &DescriptionManagement::checkExpirations, Qt::UniqueConnection);
        }
    }
    _generationOngoing = nullptr;
}



QString DescriptionManagement::parseDescription(QString datos)
{
    QStringList lines = datos.split("\n", QString::SkipEmptyParts);
    QString tag = "Description:";
    QString desc = "";
    for (auto line : lines) {
        if (line.contains(tag)) {
            int index = line.indexOf(tag) + tag.size();
            int lastChars = line.size() - index;
            if (lastChars > 0) {
                desc = line.right(line.size() - index);
            }
        }
    }
    return desc.trimmed();
}
#endif

void DescriptionManagement::copyToClipboard(DescriptionModel *desc)
{
    QClipboard *clipboard = QGuiApplication::clipboard();
    clipboard->setText(desc->description());
    Q_EMIT(descriptionCopied(desc->task()));
}

void DescriptionManagement::checkExpirations()
{
    qDebug() << "GestionDescripciones::comprobarExpiracion: comprobando expiración de "
             << _expirations.size() << " descripciones de tarea";
    bool continuarComprobando = !_expirations.isEmpty();
    while (continuarComprobando) {
        DescriptionModel *desc = _expirations.first();
        QDateTime limite = desc->UpdateDate().addSecs(_expirationTime);
        continuarComprobando = Reloj::instance()->currentTime() > limite;
        if (continuarComprobando) {
            _expirations.removeAt(0);
            desc->setState(DescriptionModel::STATE_NOTAVAILABLE);
            if (_expirations.isEmpty()) {
                continuarComprobando = false;
            }
        }
    }
    if (_expirations.isEmpty()) {
        qDebug() << "GestionDescripciones::comprobarExpiracion: desconectando comprobaciones";
        disconnect(Reloj::instance(), &Reloj::currentTimeChanged, this, &DescriptionManagement::checkExpirations);
    }
}

void DescriptionManagement::slotDescriptionStateChanged()
{
    DescriptionModel *descModel = dynamic_cast<DescriptionModel*>(sender());
    qDebug() << "DescriptionManagement::slotDescriptionStateChanged";
    if (descModel) {
        qDebug() << "DescriptionManagement::slotDescriptionStateChanged: "<<descModel->state();
        Q_EMIT(descriptionStateChanged(descModel->task(), descModel->state()));
    }
}

void DescriptionManagement::slotTaskNotifications(TaskStore::TaskNotifications notification, int taskId)
{
    // cuando se edita una tarea, su código puede haber cambiado. Esto invalida su descripción si no es local.
    // por tanto, invalidamos su descripción si estaba ya cacheada.
    switch (notification) {
        case TaskStore::TASKNOTIF_UPDATEDATA: {
            Task *n = _taskStore->task(taskId, false);
            DescriptionModel *desc = _descriptions.value(n, nullptr);
            if (desc) {
                desc->setState(DescriptionModel::STATE_NOTAVAILABLE);
                _expirations.removeAll(desc);
            }
            break;
        }
        default:
            break;
    }
}
