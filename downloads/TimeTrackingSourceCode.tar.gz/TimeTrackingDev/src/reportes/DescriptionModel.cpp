/****************************************************************************
**
** Copyright 2019-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 16 feb. 2019
**
****************************************************************************/

#include "DescriptionModel.h"
#include <QDebug>
#include "Reloj.h"
#include "../tareas/Task.h"

DescriptionModel::DescriptionModel(QObject *parent, Task *task) :
QObject(parent),
_state(STATE_NOTAVAILABLE),
_task(task)
{

}
DescriptionModel::~DescriptionModel()
{
}

DescriptionModel::DescriptionState DescriptionModel::state() const
{
    return _state;
}

void DescriptionModel::setState(DescriptionState state)
{
    qDebug() << "setState "<<state;
    if (state != _state) {
        _state = state;
        Q_EMIT(stateChanged());
    }
}

QString DescriptionModel::description() const
{
    return _description;
}

void DescriptionModel::setDescription(QString desc)
{
    qDebug() << "nueva descripcion " << desc;
    _description = desc;
}

void DescriptionModel::markAsUpdated()
{
    _updateDate = Reloj::instance()->currentTime();
}

QDateTime DescriptionModel::UpdateDate() const
{
    return _updateDate;
}

Task *DescriptionModel::task() const
{
    return _task;
}
