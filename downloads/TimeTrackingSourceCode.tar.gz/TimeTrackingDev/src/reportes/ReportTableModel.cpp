/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 17 dic. 2018
**
****************************************************************************/

#include "ReportTableModel.h"
#include <QDebug>
#include "Reloj.h"
#include <QString>
#include "../tareas/Task.h"
#include "../workorders/WorkOrder.h"
#include "RowModel.h"
#include <QModelIndex>
#include "Report.h"
#include "Funciones.h"
#include "../projects/Project.h"

ReportTableModel::ReportTableModel(QObject *parent, TTSettings *settings, DescriptionManagement *descriptionManagement) :
    QAbstractTableModel(parent),
    _settings(settings),
    _extraRowsBefore(1),
    _extraRowsAfter(1),
    _transactionalLoadOngoing(false),
    _descriptionManagement(descriptionManagement),
    _hasProjectHeaders(false),
    _projectToFilter(nullptr),
    _accumulatedMode(false),
    _lastDescriptionError(DescriptionManagement::DESCERROR_NOERROR),
    _resetOngoing(false)
{
    connect(_settings, &TTSettings::horasTrabajoChanged, this, &ReportTableModel::slotWorkingHoursChanged);
    connect(_descriptionManagement, &DescriptionManagement::descriptionStateChanged, this, &ReportTableModel::slotDescriptionStateChanged);
    connect(_descriptionManagement, &DescriptionManagement::descriptionCopied, this, &ReportTableModel::slotDescriptionCopied);
    connect(_descriptionManagement, &DescriptionManagement::descriptionError, this, &ReportTableModel::slotDescriptionError);
}

ReportTableModel::~ReportTableModel()
{
}

QHash<int, QByteArray> ReportTableModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[ROLE_DATETIME] = "datetime";
        roles[ROLE_DAYTOTAL] = "dayTotal";
        roles[ROLE_TASKCODE] = "taskCode";
        roles[ROLE_TASKNAME] = "taskName";
        roles[ROLE_WORKORDERCODE] = "workOrderCode";
        roles[ROLE_WORKORDERNAME] = "workOrderName";
        roles[ROLE_ISNORMALIZED] = "isNormalized";
        roles[ROLE_ISDAYNORMALIZED] = "isDayNormalized";
        roles[ROLE_TASKDAYREPORTDECIMAL] = "reportDecimal";
        roles[ROLE_TASKTOTAL] = "taskTotal";
        roles[ROLE_TASKPERCENTAGE] = "taskPercentage";
        roles[ROLE_WEEKTOTAL] = "weekTotal";
        roles[ROLE_DESCRIPTIONSTATUS] = "descriptionStatus";
        roles[ROLE_ISPROJECTHEADER] = "isProjectHeader";
        roles[ROLE_PROJECTNAME] = "projectName";
        roles[ROLE_PROJECTCODE] = "projectCode";
        roles[ROLE_PROJECTID] = "projectId";
        roles[ROLE_FILTEREDBYPROJECT] = "isFilteredByProject";
        roles[ROLE_TASKDAYREPORTSEXA] = "reportSexagesimal";
        roles[ROLE_DAYTOTALSEXA] = "dayTotalSexa";
        roles[ROLE_WEEKTOTALSEXA] = "weekTotalSexa";
        roles[ROLE_TASKTOTALSEXA] = "taskTotalSexa";
    }
    return roles;
}

int ReportTableModel::rowCount(const QModelIndex & parent) const
{
    if (parent.isValid()) {
        return 0;
    }
    int rows = _rows.size() + _extraRowsAfter + _extraRowsBefore;
    return rows;
}

int ReportTableModel::columnCount(const QModelIndex &parent) const
{
    if (parent.isValid()) {
        return 0;
    }
    //qDebug() << "ReportTableModel::columnCount: " << _workingDays.size() << " "<<extraColumnsAfter()<<" "<<extraColumnsBefore();
    int columns = _workingDays.size() + extraColumnsAfter() + extraColumnsBefore();
    return columns;
}

QVariant ReportTableModel::headerData(int section, Qt::Orientation orientation, int role) const
{
    QVariant res = QVariant();

    if (orientation == Qt::Horizontal) {
        int colIndex = section - extraColumnsBefore();
        if (role == ROLE_DATETIME && colIndex >= 0 && colIndex < _workingDays.size()) {
            res = QVariant::fromValue(_workingDays.value(colIndex));
        } else if (role == ROLE_DAYTOTAL) {

        }
    } else {
        res = QVariant::fromValue(QString("vertical"));
    }
    return res;
}

QVariant ReportTableModel::data(const QModelIndex &modelIndex, int role) const
{
    int rowIndex = modelIndex.row();
    int columnIndex = modelIndex.column();
    //qDebug() << "ReportTableModel::data: row "<<rowIndex<<", column "<<columnIndex << " "<<role;
    int columnTableIndex = columnIndex - extraColumnsBefore();
    int rowTableIndex = rowIndex - _extraRowsBefore;
    QDateTime columnDay;
    if (columnTableIndex >= 0 && columnTableIndex < _workingDays.size()) {
        columnDay = _workingDays.value(columnTableIndex);
    }
    if (rowIndex == 0) {
        if (columnTableIndex >= 0 && columnTableIndex < _workingDays.size() && role == ROLE_DATETIME) {
            return QVariant::fromValue(columnDay);
        }
    } else if (rowTableIndex < _rows.size()) {
        RowModel *rowModel = _rows.value(rowTableIndex);
        Task *t = rowModel->task();
        WorkOrder *w = rowModel->workOrder();
        Project *proj = rowModel->isProjectHeader() ? rowModel->project() : (t ? t->project() : nullptr);
        if (role == ROLE_TASKCODE) {
            QString s = t ? t->code() : "";
            return QVariant::fromValue(s);
        } else if (role == ROLE_TASKNAME) {
            QString s = t ? t->name() : "";
            return QVariant::fromValue(s);
        } else if (role == ROLE_WORKORDERCODE) {
            QString s = "";
            if (w) {
                if (w->code().trimmed().isEmpty()) {
                    s = "<orden sin código>";
                } else {
                    s = w->code().trimmed();
                }
            } else {
                s = "<sin orden de trabajo>";
            }
            return QVariant::fromValue(s);
        } else if (role == ROLE_WORKORDERNAME) {
            QString s = "";
            if (w) {
                if (w->name().trimmed().isEmpty()) {
                    s = "<orden sin nombre>";
                } else {
                    s = w->name().trimmed();
                }
            }
            return QVariant::fromValue(s);
        } else if (role == ROLE_ISNORMALIZED) {
            return QVariant::fromValue(rowModel->isNormalizedDay(columnDay));
        } else if (role == ROLE_ISDAYNORMALIZED) {
            return QVariant::fromValue(_normalizations.contains(columnDay));
        } else if (role == ROLE_TASKDAYREPORTDECIMAL) {
            qint64 timemsecs = rowModel->timeDay(columnDay);
            qreal hours = convertToDecimalFormat(timemsecs);
            //qDebug() << "ReportTableModel::data: reporte taskday para " << columnDay<< " == " << hours;
            return QVariant::fromValue(hours);
        } else if (role == ROLE_TASKDAYREPORTSEXA) {
            qint64 timemsecs = rowModel->timeDay(columnDay);
            QString sexa = toSexagesimal(timemsecs, false);
            //qDebug() << "ReportTableModel::data: reporte taskday para " << columnDay<< " sexa == " << sexa;
            return QVariant::fromValue(sexa);
        } else if (role == ROLE_TASKTOTAL) {
            qint64 timetotal = 0;
            if (_accumulatedMode) {
                timetotal = rowModel->timeDay(QDateTime());
            } else {
                timetotal = rowTotal(rowIndex);
            }
            qreal hours = convertToDecimalFormat(timetotal);
            return QVariant::fromValue(hours);
        } else if (role == ROLE_TASKTOTALSEXA) {
            qint64 timetotal = 0;
            if (_accumulatedMode) {
                timetotal = rowModel->timeDay(QDateTime());
            } else {
                timetotal = rowTotal(rowIndex);
            }
            QString hours = toSexagesimal(timetotal, false);
            return QVariant::fromValue(hours);
        } else if (role == ROLE_TASKPERCENTAGE) {
            qreal taskTotal = _accumulatedMode ? ((qreal)rowModel->timeDay(QDateTime())) : ((qreal)rowTotal(rowIndex));
            qreal total = (qreal)tableTotal();
            qreal perc = (taskTotal / total) * 100;
            perc = roundTo(perc, _settings->decimales());
            //qDebug() << "ReportTableModel::data: reporte porcentaje "<<taskTotal<<", "<<total<<", "<<perc;
            return QVariant::fromValue(perc);
        } else if (role == ROLE_DESCRIPTIONSTATUS) {
            int e = 0;
            if (rowModel && rowModel->task()) {
                DescriptionModel *m = _descriptionManagement->descriptionModel(rowModel->task());
                e = (int)m->state();
            } else {
                qCritical() << "Atención!! RowModel sin task en una fila de tarea: row " << rowIndex;
            }
            return QVariant::fromValue(e);
        } else if (role == ROLE_ISPROJECTHEADER) {
            return QVariant::fromValue(rowModel->isProjectHeader());
        } else if (role == ROLE_PROJECTNAME) {
            QString n = "Sin proyecto";
            if (proj) {
                if (proj->name().trimmed().isEmpty()) {
                    n = "<proyecto sin nombre>";
                } else {
                    n = proj->name().trimmed();
                }
            }
            return QVariant::fromValue(n);
        } else if (role == ROLE_PROJECTCODE) {
            return QVariant::fromValue(proj ? proj->code() : "");
        } else if (role == ROLE_PROJECTID) {
            return QVariant::fromValue(proj ? proj->id() : -1);
        } else if (role == ROLE_FILTEREDBYPROJECT) {
            return QVariant::fromValue(_projectToFilter != nullptr);
        }
    } else {
        if (role == ROLE_DAYTOTAL) {
            qint64 timetotal = dayTotal(columnIndex);
            qreal hours = convertToDecimalFormat(timetotal);
            return QVariant::fromValue(hours);
        } else if (role == ROLE_WEEKTOTAL) {
            qint64 timetotal = tableTotal();
            qreal hours = convertToDecimalFormat(timetotal);
            return QVariant::fromValue(hours);
        } else if (role == ROLE_DAYTOTALSEXA) {
            qint64 timetotal = dayTotal(columnIndex);;
            QString sexa = toSexagesimal(timetotal, false);
            //qDebug() << "ReportTableModel::data: reporte taskday para " << columnDay<< " sexa == " << sexa;
            return QVariant::fromValue(sexa);
        } else if (role == ROLE_WEEKTOTALSEXA) {
            qint64 timetotal = tableTotal();
            QString hours = toSexagesimal(timetotal, false);
            return QVariant::fromValue(hours);
        }
    }
    return QVariant();
}

bool ReportTableModel::canFetchMore(const QModelIndex &) const
{
    bool can = false;
    return can;
}

void ReportTableModel::fetchMore(const QModelIndex &)
{
}


// =================================================================================================
// =================================================================================================
// =================================================================================================
// =================================================================================================
// =================================================================================================
// =================================================================================================

qreal ReportTableModel::convertToDecimalFormat(qint64 timeMSecs) const
{
    // convierte una cantidad de milisegundos en una cantidad decimal en horas usando la preferencia de decimales
    int dec = _settings->decimales();
    qreal hours = ((qreal)timeMSecs) / ((qreal)(3600 * 1000));
    //qDebug() << "ReportTableModel::convertToDecimalFormat: tiempo "<<timeMSecs<<" msecs, pref decimales "<<dec<<", horas "<<hours;
    hours = roundTo(hours, dec);
    //qDebug() << "ReportTableModel::convertToDecimalFormat: redondeado " << hours;
    return hours;
}

void ReportTableModel::clearModel()
{
    qDebug() << "ReportTableModel::clearModel";
    beginResetModel();
    clearReports();
    _workingDays.clear();
    Q_EMIT(numDaysChanged());
    endResetModel();
}

void ReportTableModel::clearReports()
{
    qDebug() << "ReportTableModel::clearReports";
    _normalizations.clear();
    for (auto row : _rows) {
        delete row;
    }
    _rows.clear();
    _hasProjectHeaders = false;
    if (!_transactionalLoadOngoing) {
        Q_EMIT(hasReportsChanged());
    }
}

void ReportTableModel::setWorkingWeekRange(const QDateTime &firstWorkingDay, int numWorkingDays)
{
    qDebug() << "ReportTableModel::setWorkingWeekRange";
    // configura y rellena la lista de días laborables. señaliza las columnas del modelo.
    if (_workingDays.isEmpty()) {
        int numColumns = numWorkingDays + extraColumnsAfter() + extraColumnsBefore();
        qDebug() << "ReportTableModel::setWorkingWeekRange: insertando "<<numColumns<<" columnas";
        if (!_transactionalLoadOngoing) {
            beginInsertColumns(QModelIndex(), 0, numColumns-1);
        }
        for (int i = 0; i < numWorkingDays; i++) {
            QDateTime dayKey = firstWorkingDay.addDays(i);
            _workingDays.append(dayKey);
        }
        qDebug() << "ReportTableModel::setWorkingWeekRange: dias insertados " << _workingDays;
        Q_EMIT(numDaysChanged());
        if (!_transactionalLoadOngoing) {
            endInsertColumns();
        }
    }
}

bool ReportTableModel::inWeekRange(const QDateTime &time) const
{
    bool res = false;
    if (_workingDays.size() > 1) {
        res = time.date() >= _workingDays.first().date() && time.date() <= _workingDays.last().date();
    } else if (_accumulatedMode) {
        res = true;
    }
    return res;
}

RowModel *ReportTableModel::searchForRowModel(Task *task, WorkOrder *wo, int &rowIndex) const
{
    bool found = false;
    int index = 0;
    RowModel *currentRow = nullptr;
    TTSettings::AgrupacionReportes groupBy = _settings->agrupacionReportes();
    while (!found && index < _rows.size()) {
        currentRow = _rows.value(index);
        // dependiendo de la configuración de agrupamiento tendremos:
        // 1 un único RowModel por cada tarea (aunque tenga varias work orders) si se agrupa por tareas
        // 2 un único RowModel por cada work order (aunque varias tareas tengan esa work order) si se agrupa por work order
        // 3 un RowModel por cada combinación existente de tarea y work order
        found = (groupBy == TTSettings::AGRUPAR_TAREAS && currentRow->task() == task) ||
                (groupBy == TTSettings::AGRUPAR_WOS && currentRow->workOrder() == wo) ||
                (groupBy == TTSettings::AGRUPAR_MIXTO && currentRow->task() == task && currentRow->workOrder() == wo);
        rowIndex = index;
        index++;
    }
    return (found ? currentRow : nullptr);
}

RowModel *ReportTableModel::searchForRowModel(Task *task, int &rowIndex) const
{
    bool found = false;
    int index = 0;
    RowModel *currentRow = nullptr;
    while (!found && index < _rows.size()) {
        currentRow = _rows.value(index);
        found = currentRow->task() == task;
        rowIndex = index;
        index++;
    }
    return (found ? currentRow : nullptr);
}

void ReportTableModel::addTimeIntoRow(Task *task, WorkOrder *wo, QDateTime day, qint64 msecs)
{
    // obtiene el RowModel correspondiente a la tarea y/o orden de trabajo dada y le agrega el tiempo,
    // mandando las señales correspondientes. Si no hay RowModel, se crea y se mandan las señales también.
    int rowIndex = -1;
    qDebug() << "ReportTableModel::addTimeIntoRow: sumando tiempo de tarea " << (task ? task->id() : -1)
             << " y orden " << (wo ? wo->id() : -1) << " para el dia " << day << "... " << msecs << " msecs";
    RowModel *rowModel = searchForRowModel(task, wo, rowIndex);
    bool notifyNewRow = false;
    int newRowIndex = -1;
    if (rowModel == nullptr) {
        bool insertCurrentHeader = false;
        bool insertNextHeader = false;
        newRowIndex = calculateRowInsertionRange(task, insertCurrentHeader, insertNextHeader);//_rows.size() + _extraRowsBefore;
        if (!_transactionalLoadOngoing && !_resetOngoing) {
            notifyNewRow = true;
            int newRowIndexEnd = newRowIndex + (insertCurrentHeader ? 1 : 0) + (insertNextHeader ? 1 : 0);
            int rowBeginRange = newRowIndex + _extraRowsBefore;
            int rowEndRange = newRowIndexEnd + _extraRowsBefore;
            qDebug() << "ReportTableModel::addTimeIntoRow: señalizando nueva fila con index " << rowBeginRange << " - " << rowEndRange;
            beginInsertRows(QModelIndex(), rowBeginRange, rowEndRange);
        }
        // si no existe RowModel, se crea y se señaliza el beginInsert
        rowModel = new RowModel(task, wo, _workingDays, _accumulatedMode);
        insertRowAtIndex(rowModel, newRowIndex, insertCurrentHeader, insertNextHeader);
    }
    rowModel->addTime(day, msecs);
    // se notifica, o bien el endInsert si se ha creado fila nueva, o bien el dataChanged de la celda
    // y del total de fila si solo se ha sumado tiempo
    if (notifyNewRow) {
        endInsertRows();
        Q_EMIT(hasReportsChanged());
    } else if (!_transactionalLoadOngoing && !_resetOngoing) {
        QDateTime key = day;
        key.setTime(QTime(0,0,0,0));
        int columnIndex = _workingDays.indexOf(key) + extraColumnsBefore();
        rowIndex += _extraRowsBefore;
        qDebug() << "ReportTableModel::addTimeIntoRow: señalizando dataChanged, rowIndex "<<rowIndex<<", colIndex "<<columnIndex;
        Q_EMIT(dataChanged(index(rowIndex, columnIndex), index(rowIndex, columnIndex)));
        // notificamos cambio en el total de la fila también
        int columnIndexForTotals = extraColumnsBefore() + _workingDays.size();
        qDebug() << "ReportTableModel::addTimeIntoRow: señalizando dataChanged del total de fila, rowIndex "<<rowIndex<<", colIndex "<<columnIndexForTotals;
        Q_EMIT(dataChanged(index(rowIndex, columnIndexForTotals), index(rowIndex, columnIndexForTotals)));
    }
}

void ReportTableModel::addWorkedTimeForTask(Task *task, QDateTime day, qint64 msecs)
{
    bool projectIsCorrect = false;
    if (_projectToFilter == nullptr || (task->project() == _projectToFilter)) {
        projectIsCorrect = true;
    }
    qDebug() << "ReportTableModel::addWorkedTimeForTask: time " << msecs << ", task " << (task ? task->id() : -1) << ", day "
             << day << ", project " << (task? task->project():nullptr) << ", projectToFilter "
             <<_projectToFilter << ". projectIsCorrect " << projectIsCorrect;

    if (inWeekRange(day) && projectIsCorrect) { // si el día no pertenece al rango del modelo, no hay que cambiar nada
        TTSettings::AgrupacionReportes groupBy = _settings->agrupacionReportes();
        if (groupBy == TTSettings::AGRUPAR_TAREAS) {
            addTimeIntoRow(task, nullptr, day, msecs);
        } else {
            QMap<WorkOrder *,int> wos = task->workOrderMap();
            if (wos.isEmpty()) {
                // si no hay work orders, hacemos qeu exista una entrada de workorder nula con el 100%
                wos.insert(nullptr, 100);
            }
            for (auto wo : wos.keys()) {
                int percentage = wos.value(wo);
                qint64 woTime = msecs * percentage / 100;
                Task *t = groupBy == TTSettings::AGRUPAR_WOS ? nullptr : task;
                addTimeIntoRow(t, wo, day, woTime);
            }
        }
        // ahora debemos señalizar cambios en los totales del día, de las filas, y del total total de la tabla:
        if (!_transactionalLoadOngoing && !_resetOngoing) {
            int rowIndexForTotals = _extraRowsBefore + _rows.size();
            int columnIndexForTotals = extraColumnsBefore() + _workingDays.size();
            qDebug() << "ReportTableModel::addWorkedTimeForTask: señalizando dataChanged del total total, rowIndex "
                     << rowIndexForTotals << ", colIndex " << columnIndexForTotals;
            Q_EMIT(dataChanged(index(rowIndexForTotals, columnIndexForTotals), index(rowIndexForTotals, columnIndexForTotals)));// total total
            qDebug() << "ReportTableModel::addWorkedTimeForTask: fin dataChanged total total";
            QDateTime key = day;
            key.setTime(QTime(0,0,0,0));
            int columnIndex = _workingDays.indexOf(key) + extraColumnsBefore();
            qDebug() << "ReportTableModel::addWorkedTimeForTask: señalizando dataChanged del total de columna, rowIndex "
                     << rowIndexForTotals << ", colIndex " << columnIndex;
            Q_EMIT(dataChanged(index(rowIndexForTotals, columnIndex), index(rowIndexForTotals, columnIndex)));// total for day
            qDebug() << "ReportTableModel::addWorkedTimeForTask: fin dataChanged total de columna";
            // cuando se suma tiempo a un total de fila, hay que señalizar cambio en el role de porcentaje del resto de filas también
            int lastRow = _extraRowsBefore + _rows.size() - 1;
            QVector<int> roles; roles << ROLE_TASKPERCENTAGE; // solo para el role de porcentajes
            qDebug() << "ReportTableModel::addWorkedTimeForTask: señalizando dataChanged del role porcentaje de todos los totale de fila. colIndex "
                     << columnIndexForTotals << ", rows " << _extraRowsBefore << " - " << lastRow;
            Q_EMIT(dataChanged(index(_extraRowsBefore, columnIndexForTotals), index(lastRow, columnIndexForTotals), roles));
            qDebug() << "ReportTableModel::addWorkedTimeForTask: fin dataChanged del role porcentaje";
        }
    }
}

qint64 ReportTableModel::dayTotal(int columnIndex) const
{
    // para obtener el total de un día, hacemos llamadas al método data() para cada una de las filas de la
    // columna correspondiente, y vamos sumando. Por tanto, columnIndex es el índice global de columna real.
    qint64 accumulated = 0;
    //qDebug() << "ReportTableModel::dayTotal: columnIndex "<<columnIndex<< ". reportUnit " << _settings->reportUnit();
    if (_settings->reportUnit() == TTSettings::REPORTUNIT_DECIMAL) {
        for (int rowIndex = _extraRowsBefore; rowIndex < (_extraRowsBefore + _rows.size()); rowIndex++) {
            QVariant timePerRow = data(index(rowIndex, columnIndex), ROLE_TASKDAYREPORTDECIMAL);
            accumulated += (timePerRow.toReal() * 3600 * 1000); // en milisegundos
        }
    } else {
        int hours = 0,
            minutes = 0;
        for (int rowIndex = _extraRowsBefore; rowIndex < (_extraRowsBefore + _rows.size()); rowIndex++) {
            QString timePerRow = data(index(rowIndex, columnIndex), ROLE_TASKDAYREPORTSEXA).toString();
            QStringList tk = timePerRow.split(":");
            hours += tk.value(0).toInt();
            minutes += tk.value(1).toInt();
        }
        accumulated = hours * 3600 * 1000;
        accumulated += (minutes * 60 * 1000);
    }
    //qDebug() << "ReportTableModel::dayTotal: columnIndex "<<columnIndex<<" == "<<accumulated;
    return accumulated;
}

qint64 ReportTableModel::rowTotal(int rowIndex) const
{
    qint64 accumulated = 0;
    //qDebug() << "ReportTableModel::rowTotal: rowIndex "<<rowIndex << ". reportUnit " << _settings->reportUnit();
    if (_settings->reportUnit() == TTSettings::REPORTUNIT_DECIMAL) {
        // para obtener el total de una fila, hacemos llamadas al método data() para cada una de las columnas de la
        // misma, y vamos sumando. Por tanto, rowIndex es el índice global de fila real.
        for (int columnIndex = extraColumnsBefore(); columnIndex < (extraColumnsBefore() + _workingDays.size()); columnIndex++) {
            QVariant totalPerColumn = data(index(rowIndex, columnIndex), ROLE_TASKDAYREPORTDECIMAL);
            accumulated += (totalPerColumn.toReal() * 3600 * 1000); // en milisegundos
        }
    } else {
        int hours = 0,
            minutes = 0;
        for (int columnIndex = extraColumnsBefore(); columnIndex < (extraColumnsBefore() + _workingDays.size()); columnIndex++) {
            QString str = data(index(rowIndex, columnIndex), ROLE_TASKDAYREPORTSEXA).toString();
            QStringList tk = str.split(":");
            hours += tk.value(0).toInt();
            minutes += tk.value(1).toInt();
        }
        accumulated = hours * 3600 * 1000;
        accumulated += (minutes * 60 * 1000);
    }
    //qDebug() << "ReportTableModel::rowTotal: rowIndex "<<rowIndex<< " == "<<accumulated;
    return accumulated;
}

qint64 ReportTableModel::tableTotal() const
{
    // para obtener el total, pediremos y sumaremos todos los totales de día usando el método data
    qint64 accumulated = 0;
    //qDebug() << "ReportTableModel::tableTotal";
    int columnIndexForTotals = extraColumnsBefore() + _workingDays.size();
    if (_settings->reportUnit() == TTSettings::REPORTUNIT_DECIMAL) {
        for (int rowIndex = _extraRowsBefore; rowIndex < (_extraRowsBefore + _rows.size()); rowIndex++) {
            QVariant totalPerRow = data(index(rowIndex, columnIndexForTotals), ROLE_TASKTOTAL);
            accumulated += (totalPerRow.toReal() * 3600 * 1000); // en milisegundos
        }
    } else {
        int hours = 0,
            minutes = 0;
        for (int rowIndex = _extraRowsBefore; rowIndex < (_extraRowsBefore + _rows.size()); rowIndex++) {
            QString totalPerRow = data(index(rowIndex, columnIndexForTotals), ROLE_TASKTOTALSEXA).toString();
            QStringList tk = totalPerRow.split(":");
            hours += tk.value(0).toInt();
            minutes += tk.value(1).toInt();
        }
        accumulated = hours * 3600 * 1000;
        accumulated += (minutes * 60 * 1000);
    }
    //qDebug() << "ReportTableModel::tableTotal: == "<<accumulated;
    return accumulated;
}

void ReportTableModel::beginTransactionalLoad()
{
    qDebug() << "ReportTableModel::beginTransactionalLoad ";
    _transactionalLoadOngoing = true;
    beginResetModel();
}
void ReportTableModel::endTransactionalLoad()
{
    qDebug() << "ReportTableModel::endTransactionalLoad ";
    _transactionalLoadOngoing = false;
    endResetModel();
    Q_EMIT(hasReportsChanged());
}

int ReportTableModel::extraColumnsBefore() const
{
    TTSettings::AgrupacionReportes groupBy = _settings->agrupacionReportes();
    int extraColumnsBefore = groupBy == TTSettings::AGRUPAR_MIXTO ? 2 : 1;
    return extraColumnsBefore;
}

int ReportTableModel::extraColumnsAfter() const
{
    TTSettings::AgrupacionReportes groupBy = _settings->agrupacionReportes();
    int extraColumnsAfter = groupBy == TTSettings::AGRUPAR_WOS ? 1 : 2;
    return extraColumnsAfter;
}

void ReportTableModel::normalizeSwitched(int rowIndex, int columnIndex)
{
    normalizeSwitched(rowIndex, columnIndex, true);
}

void ReportTableModel::normalizeSwitched(int rowIndex, int columnIndex, bool sendNotifications)
{
    qDebug() << "ReportTableModel::normalizeSwitched: " << rowIndex<<" "<<columnIndex;
    int rowTableIndex = rowIndex - _extraRowsBefore;
    int columnTableIndex = columnIndex - extraColumnsBefore();
    if (rowTableIndex >= 0 && rowTableIndex < _rows.size() && columnTableIndex >= 0 && columnTableIndex < _workingDays.size()) {
        RowModel *rowModel = _rows.value(rowTableIndex);
        QDateTime columnDay = _workingDays.value(columnTableIndex);
        if (rowModel->isNormalizedDay(columnDay)) {
            // si ya está normalizado, hay que denormalizarlo y volverlo al tiempo normal
            rowModel->denormalizeReportDay(columnDay);
            _normalizations.remove(columnDay);
            if (sendNotifications) {
                notifyNormalizationSwitch(rowIndex, columnIndex);
            }
        } else {
            // si no está normalizado lo tenemos que normalizar. necesitamos saber el total trabajado del día
            qint64 totalForDay = dayTotal(columnIndex);
            int dayIndexForPreference = (_settings->firstDayOfWeek() - 1 + columnTableIndex) % 7;
            // esto es lo que se supone que se tiene que trabajar este día
            qint64 workDayDuration = (_settings->horasTrabajo().value(dayIndexForPreference).toReal() / 10) * 60 * 60 * 1000;
            qint64 diff = workDayDuration - totalForDay; // la diferencia que hay que compensar
            rowModel->normalizeReportDay(columnDay, diff);
            _normalizations.insert(columnDay, rowModel);
            // tenemos que señalizar cambios en la celda normalizada, en su total de columna, su total de fila,
            // el total de tabla y en todos los porcentajes
            if (sendNotifications) {
                notifyNormalizationSwitch(rowIndex, columnIndex);
            }
        }
    } else {
        qWarning() << "error con los índices "<<rowTableIndex << " "<<columnTableIndex;
    }

}

void ReportTableModel::notifyNormalizationSwitch(int rowIndex, int columnIndex)
{
    // tenemos que señalizar cambios en la celda normalizada, en su total de columna, su total de fila,
    // el total de tabla y en todos los porcentajes
    qDebug() << "ReportTableModel::normalizeSwitched: señalizando dataChanged de celda normalizada, rowIndex "<<rowIndex<<", colIndex "<<columnIndex;
    Q_EMIT(dataChanged(index(rowIndex, columnIndex), index(rowIndex, columnIndex)));// celda normalizada
    int rowIndexForTotals = _extraRowsBefore + _rows.size();
    int columnIndexForTotals = extraColumnsBefore() + _workingDays.size();
    qDebug() << "ReportTableModel::normalizeSwitched: señalizando dataChanged del total total, rowIndex "<<rowIndexForTotals<<", colIndex "<<columnIndexForTotals;
    Q_EMIT(dataChanged(index(rowIndexForTotals, columnIndexForTotals), index(rowIndexForTotals, columnIndexForTotals)));// total total
    qDebug() << "ReportTableModel::normalizeSwitched: señalizando dataChanged del total de columna, rowIndex "<<rowIndexForTotals<<", colIndex "<<columnIndex;
    Q_EMIT(dataChanged(index(rowIndexForTotals, columnIndex), index(rowIndexForTotals, columnIndex)));// total for day
    qDebug() << "ReportTableModel::normalizeSwitched: señalizando dataChanged de total de fila, rowIndex "<<rowIndex<<", colIndex "<<columnIndexForTotals;
    Q_EMIT(dataChanged(index(rowIndex, columnIndexForTotals), index(rowIndex, columnIndexForTotals)));// total de fila
    // cuando se cambia un total de fila, hay que señalizar cambio en el role de porcentaje del resto de filas también
    qDebug() << "ReportTableModel::normalizeSwitched: señalizando dataChanged del role porcentaje de todos los totale de fila. colIndex "<<columnIndexForTotals;
    int lastRow = _extraRowsBefore + _rows.size() - 1;
    QVector<int> roles; roles << ROLE_TASKPERCENTAGE; // solo para el role de porcentajes
    Q_EMIT(dataChanged(index(_extraRowsBefore, columnIndexForTotals), index(lastRow, columnIndexForTotals), roles));
    // debemos señalizar también el cambio en el role de isDayNormalized para el resto de tareas del día
    qDebug() << "ReportTableModel::normalizeSwitched: señalizando dataChanged del role isDayNormalized del resto de filas del mismo día. colIndex "<<columnIndex;
    roles.clear(); roles << ROLE_ISDAYNORMALIZED;
    Q_EMIT(dataChanged(index(_extraRowsBefore, columnIndex), index(lastRow, columnIndex), roles));
}

void ReportTableModel::slotWorkingHoursChanged()
{
    // si cambia la duración de la jornada solo afecta a los reportes que estén normalizados (porque el
    // resto mide tiempo real de trabajo y eso no cambia).
    QList<QDateTime> normalizedDays = _normalizations.keys();
    for (auto day: normalizedDays) {
        int columnIndex = _workingDays.indexOf(day) + extraColumnsBefore();
        int rowIndex = _rows.indexOf(_normalizations.value(day)) + _extraRowsBefore;
        // para volver a calcular la normalización, simplemente denormalizamos y volvemos a normalizar
        normalizeSwitched(rowIndex, columnIndex, false);
        normalizeSwitched(rowIndex, columnIndex, true);
    }
}

void ReportTableModel::descriptionClicked(int rowIndex)
{
    int rowTableIndex = rowIndex - _extraRowsBefore;
    if (rowTableIndex >= 0 && rowTableIndex < _rows.size()) {
        RowModel *rowModel = _rows.value(rowTableIndex);
        Task *task = rowModel->task();
        _descriptionManagement->loadDescription(task);
    }
}

void ReportTableModel::slotDescriptionStateChanged(Task* task, DescriptionModel::DescriptionState state)
{
    Q_UNUSED(state);
    int rowIndex = -1;
    RowModel * rowModel = searchForRowModel(task, rowIndex);
    qDebug() << "ReportTableModel::slotDescriptionStateChanged: "<<rowModel << rowIndex;
    if (rowModel) {
        QVector<int> roles; roles << ROLE_DESCRIPTIONSTATUS;
        int columnIndex = extraColumnsBefore() + _workingDays.size() + extraColumnsAfter() - 1; // última columna
        rowIndex += _extraRowsBefore;
        qDebug() << "ReportTableModel::slotDescriptionStateChanged: señalizando cambio en role descriptionStatus. rowIndex "<<rowIndex<<", colIndx "<<columnIndex;
        Q_EMIT(dataChanged(index(rowIndex, columnIndex), index(rowIndex, columnIndex), roles));
    }
}

void ReportTableModel::slotDescriptionCopied(Task *task)
{
    int rowIndex = -1;
    RowModel * rowModel = searchForRowModel(task, rowIndex);
    if (rowModel) {
        rowIndex += _extraRowsBefore;
        Q_EMIT(descriptionCopied(rowIndex));
    }
}

void ReportTableModel::slotDescriptionError(DescriptionManagement::DescriptionError error)
{
    qDebug() << "ReportTableModel::slotDescriptionError: error " << error;
    setLastDescriptionError(error);
}

int ReportTableModel::calculateRowInsertionRange(Task *task, bool &insertCurrentHeader, bool &insertNextHeader) const
{
    // calculamos en qué índice insertamos la nueva fila. si el agrupamiento es por work orders, podemos
    // insertarla al final y nunca llevará cabecera de proyecto. En caso contrario, tenemos que mirar
    // de insertarla de manera ordenada, detrás de la última del mismo proyecto. Si es la primera de su
    // proyecto, habrá que meter también una fila de cabecera de proyecto. Si es la primera que tiene
    // proyecto y había otras sin proyecto, hay que meter también fila de cabecera de proyecto para las
    // de sin proyecto. Las que tienen proyecto siempre van antes.
    int newRowIndex = -1;
    qDebug() << "ReportTableModel::calculateRowInsertionRange: task " << (task ? task->id() : -1) << ", project "<<(task ? task->project() : nullptr);
    TTSettings::AgrupacionReportes groupBy = _settings->agrupacionReportes();
    if (groupBy == TTSettings::AGRUPAR_WOS) {
        // no se usan cabeceras de proyecto. Por tanto, se inserta al final.
        insertCurrentHeader = false;
        insertNextHeader = false;
        newRowIndex = _rows.size();
    } else if (_projectToFilter != nullptr) {
        // si estamos filtrando por proyecto, esta tarea debería ser del proyecto y la pondremos
        // al final, sin cabeceras
        insertCurrentHeader = false;
        insertNextHeader = false;
        newRowIndex = _rows.size();
    } else {
        Project *taskProject = task->project();
        if (taskProject) {
            // buscamos si ya hay filas para el mismo proyecto
            int currentIndex = 0;
            bool foundSameProject = false;
            while (currentIndex < _rows.size() && newRowIndex == -1) {
                RowModel *currentRow = _rows.value(currentIndex);
                if (currentRow->isProjectHeader()) {
                    // si es la primera cabecera, no hemos mirado nada aún y debemos seguir
                    if (currentIndex > 0) {
                        // para el resto de cabeceras, indica un cambio de proyecto
                        // miramos si el anterior era el de nuestra fila, porque entonces toca insertar.
                        // Si no era, seguiremos buscando. Como muy tarde,
                        // insertaremos cuando encontremos una fila sin proyecto, o al final del todo.
                        if (foundSameProject) {
                            newRowIndex = currentIndex;
                            insertCurrentHeader = false; // ya teníamos filas de este proyecto
                            insertNextHeader = false; // ya estamos en esta cabecera
                        } else if (currentRow->project() == nullptr) {
                            // si es cabecera de proyecto sin proyecto, entonces es la cabecera de las
                            // filas que no tienen proyecto. Las de proyectos deben estar por encima, así que
                            // insertamos ya
                            newRowIndex = currentIndex;
                            insertCurrentHeader = true; // porque es proyecto nuevo
                            insertNextHeader = false; // ya estamos en esta cabecera
                        }
                    }
                } else if (currentRow->task()->project() == nullptr) {
                    if (!_hasProjectHeaders) {
                        // si encontramos la primera fila sin proyecto, entonces la nueva fila irá aquí (siempre será la 0).
                        newRowIndex = currentIndex;
                        insertCurrentHeader = !foundSameProject;
                        insertNextHeader = true;
                    }
                } else {
                    // si las filas tienen proyecto vamos pasando, pero si es el mismo proyecto que
                    // la nueva fila lo marcamos para saber qué hacer con la cabecera más adelante.
                    if (currentRow->task()->project() == taskProject) {
                        foundSameProject = true;
                    }
                }
                currentIndex++;
            }
            if (newRowIndex == -1) {
                newRowIndex = _rows.size();
                insertCurrentHeader = !foundSameProject;
                insertNextHeader = false;
            }
        } else {
            // si no tiene proyecto, la insertamos al final
            newRowIndex = _rows.size();
            insertNextHeader = false;
            if (_rows.size() == 0) {
                // si no había ninguna, no insertamos fila de cabecera, porque no tiene proyecto
                insertCurrentHeader = false;
            } else {
                // miramos la anterior, insertamos cabecera si la anterior tenía proyecto
                RowModel *prev = _rows.value(_rows.size()-1);
                if (prev->isProjectHeader()) {
                    qCritical() << "Error de coherencia en el modelo! hay una cabecera de proyecto sin modelos de fila detrás";
                }
                insertCurrentHeader = (prev->task()->project() != nullptr);
            }
        }
    }
    qDebug() << "ReportTableModel::calculateRowInsertionRange: rowIndex (en _rows) " << newRowIndex
             << ", insertCurrentHeader " << insertCurrentHeader << ", insertNextHeader " << insertNextHeader;
    return newRowIndex;
}

void ReportTableModel::insertRowAtIndex(RowModel *rowModel, int rowIndex, bool insertCurrentHeader, bool insertNextHeader)
{
    qDebug() << "ReportTableModel::insertRowAtIndex: index (en _rows) " << rowIndex << ", insertCurrHeader " << insertCurrentHeader
             << ", insertNextHeader " << insertNextHeader << ", _rows size " << _rows.size();
    // se inserta el modelo de fila en la posición dada y se hace lo necesario para insertar las cabeceras que toque
    bool appendToEnd = rowIndex == _rows.size();
    int indexOfNextRow = rowIndex + 1;
    int indexToInsert = rowIndex;
    qDebug() << "ReportTableModel::insertRowAtIndex: appendToEnd " << appendToEnd << ", indexNextRow "
             << indexOfNextRow << ", indexToInsert " << indexToInsert;
    if (insertCurrentHeader) {
        // insertamos fila cabecera para el rowModel
        qDebug() << "ReportTableModel::insertRowAtIndex: metemos RowModel de cabecera de proyecto";
        RowModel *currHeader = new RowModel(rowModel->task()->project());
        if (appendToEnd) {
            _rows.append(currHeader);
        } else {
            _rows.insert(indexToInsert, currHeader);
            indexToInsert++;
        }
        indexOfNextRow++;
        _hasProjectHeaders = true;
    }
    // insertamos el rowModel
    qDebug() << "ReportTableModel::insertRowAtIndex: metemos un RowModel. rowIndex (en _rows) " << rowIndex << ", is header " << rowModel->isProjectHeader();
    if (appendToEnd) {
        _rows.append(rowModel);
    } else {
        _rows.insert(indexToInsert, rowModel);
        indexToInsert++;
    }
    if (insertNextHeader) {
        // insertamos cabecera para los siguientes rowModels
        qDebug() << "ReportTableModel::insertRowAtIndex: metemos un RowModel de cabecera de proyecto.";
        RowModel *next = _rows.value(indexOfNextRow); // para obtener el proyecto
        RowModel *nextHeader = new RowModel(next->task()->project());
        if (appendToEnd) {
            _rows.append(nextHeader);
        } else {
            _rows.insert(indexToInsert, nextHeader);
        }
        _hasProjectHeaders = true;
    }
}

bool ReportTableModel::isProjectHeader(int rowIndex) const
{
    bool res = false;
    int rowIndexInList = rowIndex - _extraRowsBefore;
    if (rowIndexInList >= 0 && rowIndexInList < _rows.size()) {
        RowModel *rm = _rows.value(rowIndexInList);
        res = rm->isProjectHeader();
    }
    return res;
}

Project *ReportTableModel::projectToFilter() const
{
    return _projectToFilter;
}

void ReportTableModel::setProjectToFilter(Project *project)
{
    if (_projectToFilter != project) {
        _projectToFilter = project;
        Q_EMIT(projectToFilterChanged());
    }

}

bool ReportTableModel::hasReports() const
{
    return _rows.size() > 0;
}

void ReportTableModel::setAccumulatedMode(bool mode)
{
    if (_accumulatedMode != mode) {
        _accumulatedMode = mode;
        Q_EMIT(isAccumulatedChanged());
    }
}

bool ReportTableModel::isAccumulated() const
{
    return _accumulatedMode;
}

QDateTime ReportTableModel::firstWorkingDay() const
{
    QDateTime firstDay;
    if (!_workingDays.isEmpty()) {
        firstDay = _workingDays.value(0);
    }
    return firstDay;
}

QDateTime ReportTableModel::lastWorkingDay() const
{
    QDateTime lastDay;
    if (!_workingDays.isEmpty()) {
        lastDay = _workingDays.value(_workingDays.size() - 1);
    }
    return lastDay;
}

int ReportTableModel::numDays() const
{
    return _workingDays.size();
}

DescriptionManagement::DescriptionError ReportTableModel::lastDescriptionError() const
{
    return _lastDescriptionError;
}

void ReportTableModel::setLastDescriptionError(DescriptionManagement::DescriptionError newValue)
{
    if (newValue != _lastDescriptionError) {
        _lastDescriptionError = newValue;
        qDebug() << "ReportTableModel::setLastDescriptionError: nuevo error " << newValue<<". emitiendo changed";
        Q_EMIT(lastDescriptionErrorChanged());
    }
}

void ReportTableModel::clearLastDescriptionError()
{
    setLastDescriptionError(DescriptionManagement::DESCERROR_NOERROR);
}

void ReportTableModel::aboutToEditModel()
{
    if (!_resetOngoing) {
        _resetOngoing = true;
        beginResetModel();
    }
}

void ReportTableModel::editModelFinished()
{
    if (_resetOngoing) {
        _resetOngoing = false;
        endResetModel();
    }
    Q_EMIT(hasReportsChanged());
}

