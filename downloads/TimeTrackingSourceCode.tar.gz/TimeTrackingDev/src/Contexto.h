/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 9 oct. 2018
**
****************************************************************************/

#ifndef CONTEXTO_H_
#define CONTEXTO_H_

#include <qobject.h>
#include <QDateTime>
#include "Reloj.h"

class TTSettings;
class QNetworkAccessManager;
class WorkOrdersViewModel;
class WorkOrderStore;
class TasksViewModel;
class TaskStore;
class TimeViewModel;
class TimeStore;
class ReportViewModel;
class ProjectsViewModel;
class ProjectStore;
class ClockingInViewModel;

class Contexto: public QObject {
    Q_OBJECT

    Q_PROPERTY(QString version READ version NOTIFY versionChanged)
    Q_PROPERTY(TTSettings* settings READ settings NOTIFY settingsChanged)
    Q_PROPERTY(Reloj* reloj READ reloj CONSTANT)
    Q_PROPERTY(QString infoTextForSplash READ infoTextForSplash NOTIFY infoTextForSplashChanged)
    Q_PROPERTY(bool splash READ splash NOTIFY splashChanged)

public:
    Contexto();
    virtual ~Contexto();

    void initialize();

    QString version() const;
    TTSettings *settings() const;
    Reloj* reloj();
    WorkOrdersViewModel *workOrdersViewModel() const;
    TasksViewModel *tasksViewModel() const;
    TimeViewModel *timeViewModel() const;
    ReportViewModel *reportViewModel() const;
    QString infoTextForSplash() const;
    bool splash() const;
    void setSplash(bool b);
    ProjectsViewModel *projectsViewModel() const;
    ClockingInViewModel *clockingInViewModel() const;
    Q_INVOKABLE void slotSplashLoaded();

public Q_SLOTS:
    qreal textWidth(const QString &text, const QFont &font) const;
    qreal textHeight(const QFont &font) const;
    bool fileExists(QString filePath) const;
    bool isFile(const QString &filePath) const;
    void setInfoTextForSplash(const QString &text);

Q_SIGNALS:
    void versionChanged();
    void settingsChanged();
    void infoTextForSplashChanged();
    void splashChanged();
    void splashLoaded();

private:
    void debugInfo() const;

    TTSettings *_settings;
    QNetworkAccessManager *_networkManager;
    WorkOrderStore *_workOrderStore;
    WorkOrdersViewModel *_workOrdersViewModel;
    TaskStore *_taskStore;
    TasksViewModel *_tasksViewModel;
    TimeViewModel *_timeViewModel;
    TimeStore *_timeStore;
    ReportViewModel *_reportViewModel;
    QString _infoText;
    bool _splash;
    ProjectsViewModel *_projectsViewModel;
    ProjectStore *_projectStore;
    ClockingInViewModel *_clockingInViewModel;
};

#endif /* CONTEXTO_H_ */
