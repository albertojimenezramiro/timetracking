/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 10 nov 2023
**
****************************************************************************/

#ifndef SRC_CLOCKINGIN_DAYMODEL_H_
#define SRC_CLOCKINGIN_DAYMODEL_H_

#include <QtGlobal>
#include <QDate>

class DayModel
{
    public:
        DayModel(const QDate &date);
        virtual ~DayModel();

        qint64 dayWorkDone() const;
        void setDayWorkDone(qint64 v);
        qint64 dayWorkExpected();
        void setDayWorkExpected(qint64 v);
        qint64 accumulatedDiffDone();
        void setAccumulatedDiffDone(qint64 v);
        QDate date() const;

    private:
        qint64 _dayWorkDone;
        qint64 _dayWorkExpected;
        qint64 _accumulatedDiffDone;
        QDate _date;
};

#endif /* SRC_CLOCKINGIN_DAYMODEL_H_ */
