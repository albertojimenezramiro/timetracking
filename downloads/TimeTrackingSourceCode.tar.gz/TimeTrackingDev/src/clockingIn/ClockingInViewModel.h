/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 10 nov 2023
**
****************************************************************************/

#ifndef SRC_CLOCKINGIN_CLOCKINGINVIEWMODEL_H_
#define SRC_CLOCKINGIN_CLOCKINGINVIEWMODEL_H_

#include <QObject>
#include <QDateTime>
#include <QString>
#include "../tiempo/TimeStore.h"

class TTSettings;
class MonthListModel;

class ClockingInViewModel : public QObject
{
    Q_OBJECT

    Q_PROPERTY(MonthListModel* monthListModel READ monthListModel CONSTANT)
    Q_PROPERTY(int monthSelectorValue READ monthSelectorValue WRITE setMonthSelectorValue NOTIFY monthSelectorValueChanged)
    Q_PROPERTY(bool isCurrentMonth READ isCurrentMonth NOTIFY isCurrentMonthChanged)

    public:
        ClockingInViewModel(QObject* parent, TimeStore *timeStore, TTSettings *settings);
        virtual ~ClockingInViewModel();

        void initialize();

        MonthListModel *monthListModel() const;
        int monthSelectorValue() const;
        void setMonthSelectorValue(int v);
        Q_INVOKABLE QString monthValueToText(int value) const;
        bool isCurrentMonth() const;

    Q_SIGNALS:
        void monthSelectorValueChanged();
        void isCurrentMonthChanged();

    private Q_SLOTS:
        void slotNotifications(TimeStore::TimeNotifications notification, qint64 entryId);
        void slotRecalculateClockingInData();

    private:
        TimeStore *_timeStore;
        MonthListModel *_monthListModel;
        TTSettings *_settings;
        int _monthSelectorValue;
        QDate _selectorReference;
};

#endif /* SRC_CLOCKINGIN_CLOCKINGINVIEWMODEL_H_ */
