/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 13 nov 2023
**
****************************************************************************/

#ifndef SRC_CLOCKINGIN_WORKINTERVAL_H_
#define SRC_CLOCKINGIN_WORKINTERVAL_H_

#include <QDateTime>

class WorkInterval
{
    public:
        WorkInterval(const QDateTime &start, bool startAutomatic, const QDateTime &end, bool endAutomatic);
        virtual ~WorkInterval();

        QDateTime start() const;
        bool isAutomaticStart() const;
        QDateTime end() const;
        bool isAutomaticEnd() const;
        bool isOpen() const;
        void setOpen(bool b);

    private:
        QDateTime _start, _end;
        bool _isAutomaticStart, _isAutomaticEnd;
        bool _isOpen;
};

#endif /* SRC_CLOCKINGIN_WORKINTERVAL_H_ */
