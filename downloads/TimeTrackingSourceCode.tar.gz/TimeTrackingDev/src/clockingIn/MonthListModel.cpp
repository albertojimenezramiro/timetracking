/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 10 nov 2023
**
****************************************************************************/

#include "MonthListModel.h"
#include "../tiempo/TimeEntry.h"
#include <QDebug>
#include "TTSettings.h"
#include "Reloj.h"
#include "../tiempo/TimeStore.h"
#include <QList>
#include <QDate>
#include "DayModel.h"
#include "Funciones.h"
#include "../tareas/Task.h"
#include "WorkInterval.h"
#include "IntervalModel.h"

MonthListModel::MonthListModel(QObject *parent, TimeStore *timeStore, TTSettings *settings) :
    QAbstractListModel(parent),
    _timeStore(timeStore),
    _settings(settings)
{
}

MonthListModel::~MonthListModel()
{
}

void MonthListModel::initialize()
{
}

int MonthListModel::rowCount(const QModelIndex &) const
{
    QDate d = _reference.date();
    d = d.addDays(d.daysInMonth());
    QDateTime endReference = QDateTime(d, _reference.time());
    QDateTime now = Reloj::currentDateTime();
    int numRows = 0;
    if (now >= _reference && now < endReference) {
        numRows = now.date().day();
    } else if (endReference <= now) {
        numRows = _reference.date().daysInMonth();
    }
    return numRows;
}

QVariant MonthListModel::data(const QModelIndex &modelIndex, int role) const
{
    int nrow = modelIndex.row();
    DayModel *day = _dayModels.value(nrow+1);
    if (role == CLOCKROLE_DATE) {
        return QVariant::fromValue(_reference.addDays(nrow).toString("ddd dd 'de' MMM"));
    } else if (role == CLOCKROLE_FREEDAY) {
        return QVariant::fromValue(day ? (day->dayWorkDone() == 0 && day->dayWorkExpected() == 0) : false);
    } else if (role == CLOCKROLE_WORKDAYNOTWORKED) {
        return QVariant::fromValue(day ? (day->dayWorkDone() == 0 && day->date() < Reloj::currentDate() && day->dayWorkExpected() > 0) : false);
    } else if (role == CLOCKROLE_WORKEXPECTED) {
        return QVariant::fromValue(day ? toSexagesimal(day->dayWorkExpected(), false) : "");
    } else if (role == CLOCKROLE_WORKDONE) {
        return QVariant::fromValue(day ? toSexagesimal(day->dayWorkDone(), false) : "");
    } else if (role == CLOCKROLE_DIFFDONE) {
        qint64 diff = day ? (day->dayWorkDone()-day->dayWorkExpected()) : 0;
        return QVariant::fromValue(day ? toSexagesimal(diff, false) : "");
    } else if (role == CLOCKROLE_DIFFDONESIGN) {
        int diff = 0;
        if (day) {
            if (day->dayWorkDone() > day->dayWorkExpected()) {
                diff = 1;
            } else if (day->dayWorkDone() < day->dayWorkExpected()) {
                diff = -1;
            }
        }
        return QVariant::fromValue(diff);
    } else if (role == CLOCKROLE_DIFFACCUMULATED) {
        return QVariant::fromValue(day ? toSexagesimal(day->accumulatedDiffDone(), false) : "");
    } else if (role == CLOCKROLE_DIFFACCUMULATEDSIGN) {
        int diff = 0;
        if (day) {
            if (day->accumulatedDiffDone() > 0) {
                diff = 1;
            } else if (day->accumulatedDiffDone() < 0) {
                diff = -1;
            }
        }
        return QVariant::fromValue(diff);
    } else if (role == CLOCKROLE_INTERVALMODEL) {
        return QVariant::fromValue(_intervalModels.value(nrow + 1));
    } else if (role == CLOCKROLE_NUMINTERVALS) {
        IntervalModel *model = _intervalModels.value(nrow + 1);
        return QVariant::fromValue(model ? model->rowCount(QModelIndex()) : 0);
    }

    return QVariant();
}

QHash<int, QByteArray> MonthListModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[CLOCKROLE_DATE] = "monthDate";
        roles[CLOCKROLE_FREEDAY] = "freeday";
        roles[CLOCKROLE_WORKDAYNOTWORKED] = "workdayFree";
        roles[CLOCKROLE_WORKEXPECTED] = "workExpected";
        roles[CLOCKROLE_WORKDONE] = "workDone";
        roles[CLOCKROLE_DIFFDONE] = "diffDone";
        roles[CLOCKROLE_DIFFDONESIGN] = "diffDoneSign";
        roles[CLOCKROLE_DIFFACCUMULATED] = "diffAccumulated";
        roles[CLOCKROLE_DIFFACCUMULATEDSIGN] = "diffAccumulatedSign";
        roles[CLOCKROLE_INTERVALMODEL] = "intervalModel";
        roles[CLOCKROLE_NUMINTERVALS] = "numIntervals";
    }
    return roles;
}

bool MonthListModel::canFetchMore(const QModelIndex &) const
{
    return false;
}

void MonthListModel::fetchMore(const QModelIndex &)
{
}


//=======================================================================
//=======================================================================
//=======================================================================

QDateTime MonthListModel::reference() const
{
    return _reference;
}

void MonthListModel::loadModel(const QDateTime &reference)
{
    qDebug() << "MonthListModel::loadModel: " << reference;
    beginResetModel();
    qDeleteAll(_dayModels);
    _dayModels.clear();
    for (auto model : _intervalModels) {
        model->clearModel(); // se deben destruir los intervalos, porque no se destruyen aquí
        model->deleteLater();
    }
    _intervalModels.clear();
    QDateTime beginRange = firstDayOfMonth(reference);
    QDateTime endRange = beginRange.addDays(beginRange.date().daysInMonth());
    QList<TimeEntry*> tmp = _timeStore->loadTimeRange(beginRange, endRange);
    qDebug() << "MonthListModel::loadModel: " << tmp.size() << " entradas de tiempo para el mes";
    _reference = beginRange;
    tmp = addAutomaticLimits(tmp);
    QList<WorkInterval*> workIntervals = createWorkIntervals(tmp, beginRange, endRange);
    parseWorkIntervals(workIntervals);
    calculateFixedData();
    endResetModel();
}

QList<TimeEntry*> MonthListModel::addAutomaticLimits(QList<TimeEntry*> entryList) const
{
    // dada una lista de muestras de tiempo de usuario, mete entre medias mas muestras de tiempo necesarias
    // para representar los límites automáticos de comienzo y final de jornada.
    QList<TimeEntry*> newList;
    QTime automaticBegin = _settings->comienzoJornada(),
          automaticEnd = _settings->finalJornada();
    TimeEntry *last = nullptr;
    // metemos una muestra con la hora actual, para que el bucle procese también el tiempo entre la última
    // muestra de la lista y el momento presente:
    entryList.append(new TimeEntry(-1, -1, Reloj::currentDateTime()));
    /*
     * Invariante del bucle:
     * - En cada vuelta se estudia y procesa el intervalo [last, entry). last y entry apuntarán a
     *   dos muestras originales de usuario consecutivas (salvo la primera vuelta, que last es null)
     *   y no se hará nada.
     *
     * - Al principio de la vuelta, Si last es una muestra de fin de tarea, se mete sin más. El intervalo
     *   [last, entry) no es de trabajo y no hay muestras automáticas que meter. Si last es una muestra
     *   de comienzo de tarea, se agrega last; si last y entry son de días distintos, entonces se procesa
     *   y agregan las muestras automáticas necesarias hasta entry.
     *
     * - Al final de la vuelta habremos metido en la nueva lista la muestra last y todas las automáticas
     *   necesarias hasta la muestra entry, pero esta no se habrá metido aún. Si no se requieren muestras
     *   automáticas se habrá metido solo last.
     *
     */
    for (auto entry : entryList) {
        qDebug() << "MonthListModel::addAutomaticLimits: entrada real " << entry->time()<<", task " << entry->taskId();
        if (last) {
            if (last->task()) {
                QDateTime lastTime = last->time();
                Task *lastTask = last->task();
                // intervalo trabajado desde last hasta entry. Ambas son muestras de usuario, así que
                // solo tenemos que comprobar límites automáticos si son de días distintos.
                if (lastTime.date() == entry->time().date()) {
                    newList.append(last);
                } else {
                    newList.append(last);
                    // comprobamos el final del primer día, el de last
                    bool useAutomaticBegin = false;
                    if (lastTime.time() <= automaticEnd) {
                        // metemos entrada con el límite automático de final
                        newList.append(new TimeEntry(-1, -1, QDateTime(lastTime.date(), automaticEnd)));
                        qDebug() << "MonthListModel::addAutomaticLimits: agregada entrada de límite de final " << lastTime.date();
                        useAutomaticBegin = true;
                    } else {
                        // si la muestra de usuario era posterior al límite de final, entonces la
                        // siguiente muestra será hasta el final natural del día, pero se sigue trabajando en la tarea
                        TimeEntry *m = new TimeEntry(-1, lastTask->id(), QDateTime(lastTime.date().addDays(1), QTime(0, 0, 0, 0)));
                        m->setTask(lastTask);
                        newList.append(m);
                        qDebug() << "MonthListModel::addAutomaticLimits: agregada entrada de final natural " << lastTime.date();
                    }
                    // en caso de que haya días intermedios:
                    // el final del último día intermedio depende de si la entrada dl último día fue
                    // antes o después del límite automático de comienzo.
                    bool useAutomaticEndPrelastDay = true;
                    if (entry->time().time() < automaticBegin) {
                        useAutomaticEndPrelastDay = false;
                    }
                    //bucle por los días intermedios del intervalo. Los días intermedios cuentan siempre desde
                    // el límite automático de comienzo hasta el límite automático de final, salvo el segundo día
                    // en el caso de que el intervalo haya comenzado más tarde del límite automático de final (el primer día)
                    QDate currDate = last->time().date().addDays(1);
                    while (currDate != entry->time().date()) {
                        // comprobamos si hay que meter el límite automático de comienzo
                        if (useAutomaticBegin) {
                            TimeEntry *m = new TimeEntry(-1, lastTask->id(), QDateTime(currDate, automaticBegin));
                            m->setTask(lastTask);
                            newList.append(m);
                            qDebug() << "MonthListModel::addAutomaticLimits: agregada entrada de limite de comienzo " << currDate;
                        }
                        useAutomaticBegin = true;
                        // y metemos el límite automático de final
                        if (currDate == entry->time().date().addDays(-1) && useAutomaticEndPrelastDay == false) {
                            //si es el penúltimo día, dependiendo de entry, podríamos tener que contar hasta el final natural del día
                            TimeEntry *te = new TimeEntry(-1, lastTask->id(), QDateTime(currDate.addDays(1), QTime(0, 0, 0, 0)));
                            te->setTask(lastTask);
                            newList.append(te);
                            qDebug() << "MonthListModel::addAutomaticLimits: agregada entrada de final natural " << currDate;
                            useAutomaticBegin = false;
                        } else {
                            // el caso normal, contamos solo hasta el límite de jornada
                            newList.append(new TimeEntry(-1, -1, QDateTime(currDate, automaticEnd)));
                            qDebug() << "MonthListModel::addAutomaticLimits: agregada entrada de limite de final " << currDate;
                        }
                        currDate = currDate.addDays(1);
                    }
                    // y ahora el día final, el de entry
                    if (useAutomaticBegin) {
                        TimeEntry *m = new TimeEntry(-1, lastTask->id(), QDateTime(currDate, automaticBegin));
                        m->setTask(lastTask);
                        newList.append(m);
                        qDebug() << "MonthListModel::addAutomaticLimits: agregada entrada de limite de comienzo " << currDate;
                    }
                    //newList.append(entry); esta no se mete hasta que no sea last
                }
            } else { // si last es terminación de tarea, lo agregamos sin más. No hay entradas virtuales que añadir en [last - entry]
                newList.append(last);
            }
        }
        last = entry;
    }
    // la última entrada de la lista no se ha metido. ahora no la metemos, porque es la que
    // la que nos inventamos al principio con el momento actual, pero que en realidad no existe
    //newList.append(entryList.value(entryList.size()-1));
    return newList;
}

QList<WorkInterval*> MonthListModel::createWorkIntervals(QList<TimeEntry*> entries, const QDateTime &beginRange, const QDateTime &endRange)
{
    QList<WorkInterval*> intervals;
    if (entries.size() > 1) {
        qDebug() << "MonthListModel::createWorkIntervals: entries " << entries.size() << "; reference " << _reference;
        int ind = 0;
        QDateTime beginInterval;
        bool startIsAutomatic = false;
        while (ind < entries.size()) {
            TimeEntry *te =  entries.value(ind);
            qDebug() << "MonthListModel::createWorkIntervals: timeEntry " << te->time() << ", task " << te->taskId() << " " << te->task();
            if (te->time() >= beginRange && te->time() <= endRange) {
                if (te->task() == nullptr) {
                    if (!beginInterval.isNull()) {
                        // si se empezó a contar un intervalo de trabajo y ahora se para de trabajar,
                        // entonces el intervalo ha terminado.
                        qDebug() << "MonthListModel::createWorkIntervals: sumamos intervalo de trabajo "
                                 << beginInterval << " -- " << te->time() << "; limites automaticos "
                                 << startIsAutomatic << " " << (te->id() == -1);
                        intervals.append(new WorkInterval(beginInterval, startIsAutomatic, te->time(), te->id() == -1));
                        beginInterval = QDateTime();
                        startIsAutomatic = false;
                    }
                } else {
                    // si se empieza tarea, si no había un intervalo lo comenzamos ahora. si ya lo había,
                    // simplemente sigue contándose.
                    if (beginInterval.isNull()) {
                        beginInterval = te->time();
                        startIsAutomatic = te->id() == -1;
                        qDebug() << "MonthListModel::createWorkIntervals: comenzamos intervalo " << beginInterval
                                 << (startIsAutomatic ? "limite automatico" : "");
                    } else if (te->time().time() == QTime(0, 0, 0, 0)) {
                        // si había un intervalo empezado y se empieza tarea justo en el límite del día natural,
                        // es una entrada virtual metida por el addAutomaticLimits. Se debe seguir contando,
                        // pero hacemos un intervalo para cada día:
                        qDebug() << "MonthListModel::createWorkIntervals: sumamos intervalo de trabajo "
                                 << beginInterval << " -- " << te->time() << "; limites automaticos "
                                 << startIsAutomatic << " " << (te->id() == -1);;
                        intervals.append(new WorkInterval(beginInterval, startIsAutomatic, te->time(), te->id() == -1));
                        beginInterval = te->time(); // dejamos el intervalo del siguiente día ya listo
                        startIsAutomatic = te->id() == -1;
                    }
                }
            }
            ind++;
        }
        if (beginInterval.isValid()) {
            // tenemos un último intervalo que está abierto. Seguramente sea el día actual.
            WorkInterval *last = new WorkInterval(beginInterval, startIsAutomatic, beginInterval, true);
            last->setOpen(true);
            intervals.append(last);
        }
    }
    return intervals;
}

void MonthListModel::parseWorkIntervals(QList<WorkInterval*> l)
{
    QList<WorkInterval*> intervals;
    int day = 0;
    for (auto interval : l) {
        addTimeToDayModel(interval->start(), interval->end());
        int currIntervalDay = interval->start().date().day();
        if (day == 0) {
            day = currIntervalDay;
        } else if (day != currIntervalDay) {
            IntervalModel *model = new IntervalModel(this);
            qDebug() << "MonthListModel::parseWorkIntervals: cargando IntervalModel de dia " << day << " con " << intervals.size() << " intervalos";
            model->loadModel(intervals);
            _intervalModels.insert(day, model);
            intervals.clear();
            day = currIntervalDay;
        }
        intervals.append(interval);
    }
    if (!intervals.isEmpty()) {
        // nos falta lo del último día
        IntervalModel *model = new IntervalModel(this);
        qDebug() << "MonthListModel::parseWorkIntervals: cargando IntervalModel del último dia " << day << " con " << intervals.size() << " intervalos";
        model->loadModel(intervals);
        _intervalModels.insert(day, model);
    }
}

void MonthListModel::addTimeToDayModel(const QDateTime &beginRange, const QDateTime &endRange)
{
    int numDay = beginRange.date().day();
    if (numDay >= 1) {
        DayModel *dayModel = _dayModels.value(numDay);
        if (dayModel == nullptr) {
            qDebug() << "MonthListModel::addTimeToDayModel: creando DayModel para " << beginRange.date();
            dayModel = new DayModel(beginRange.date());
            _dayModels.insert(numDay, dayModel);
        }
        qint64 msecs = beginRange.msecsTo(endRange);
        qDebug() << "MonthListModel::addTimeToDayModel: intervalo calculado " << beginRange << " -- "
                 << endRange << " de " << msecs << " msecs.";
        dayModel->setDayWorkDone(dayModel->dayWorkDone() + msecs);
    }
}

void MonthListModel::calculateFixedData()
{
    QVariantList horasTrabajo = _settings->horasTrabajo();
    int firstDay = _settings->firstDayOfWeek(),
        lastDay = _settings->lastDayOfWeek();
    qDebug() << "MonthListModel::calculateFixedData: "<<horasTrabajo<<", rango semana "<<firstDay<<", "<<lastDay;
    qint64 diffAccumulated = 0;
    int daysInMonth = _reference.date().daysInMonth();
    for (int ind = 1; ind <= daysInMonth; ind++) {
        DayModel *model = _dayModels.value(ind);
        if (model == nullptr) {
            QDate d = QDate(_reference.date().year(), _reference.date().month(), ind);
            model = new DayModel(d);
            _dayModels.insert(ind, model);
        }
        int indexDay = model->date().dayOfWeek() - 1;
        qDebug() << "MonthListModel::calculateFixedData: dia " << ind << ", indexDay " << indexDay;
        qreal hoursExpected = horasTrabajo.value(indexDay).toReal() / 10.0;

        if ( (firstDay <= lastDay && (model->date().dayOfWeek() < firstDay || model->date().dayOfWeek() > lastDay))
           ||(firstDay > lastDay && (model->date().dayOfWeek() > lastDay && model->date().dayOfWeek() < firstDay)) )
        {
            // día fuera del rango de semana laboral:
            // - semana normal (primer día < último día: martes -- jueves) y día antes del primero o después del último
            // - semana rara (primer día > último día: viernes -- lunes) y día entre el último y el primero
            hoursExpected = 0;
        }

        qint64 expected = hoursExpected * 60.0 * 60.0 * 1000.0;

        qDebug() << "MonthListModel::calculateFixedData: hoursExpected " << hoursExpected << ", " << toSexagesimal(expected, false);
        model->setDayWorkExpected(expected);
        qint64 diff = model->dayWorkDone() > 0 ? (model->dayWorkDone() - model->dayWorkExpected()) : 0; // si no se ha trabajado el día, no acumulamos diferencia por si es fiesta
        diffAccumulated += diff;
        qDebug() << "MonthListModel::calculateFixedData: diff del dia "<<diff << " " << toSexagesimal(diff, false)
                 << ". acumulado " << diffAccumulated << " " << toSexagesimal(diffAccumulated, false);
        model->setAccumulatedDiffDone(diffAccumulated);

    }
}

