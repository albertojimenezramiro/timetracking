/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 10 nov 2023
**
****************************************************************************/

#include "ClockingInViewModel.h"
#include <QDebug>
#include <qqml.h>
#include "TTSettings.h"
#include "MonthListModel.h"
#include "Reloj.h"

ClockingInViewModel::ClockingInViewModel(QObject* parent, TimeStore *timeStore, TTSettings *settings) :
    QObject(parent),
    _timeStore(timeStore),
    _settings(settings),
    _monthSelectorValue(0)
{
    qDebug() << "ClockingInViewModel::ClockingInViewModel";
    qmlRegisterUncreatableType<MonthListModel>("TimeTracking.models", 1, 0, "MonthListModel", "No se puede crear un MonthListModel");
    connect(_timeStore, &TimeStore::timeNotification, this, &ClockingInViewModel::slotNotifications, Qt::QueuedConnection);
    connect(Reloj::instance(), &Reloj::currentTimeChanged, this, &ClockingInViewModel::isCurrentMonthChanged);
    _monthListModel = new MonthListModel(this, timeStore, _settings);
    connect(_settings, &TTSettings::limitesJornadaChanged, this, &ClockingInViewModel::slotRecalculateClockingInData, Qt::QueuedConnection);
    connect(_settings, &TTSettings::horasTrabajoChanged, this, &ClockingInViewModel::slotRecalculateClockingInData, Qt::QueuedConnection);
    connect(_settings, &TTSettings::workingWeekRangeChanged, this, &ClockingInViewModel::slotRecalculateClockingInData, Qt::QueuedConnection);
}

ClockingInViewModel::~ClockingInViewModel()
{
    if (_monthListModel) {
        _monthListModel->deleteLater();
    }
}

void ClockingInViewModel::initialize()
{
    _monthListModel->initialize();
    QDateTime now = Reloj::currentDateTime();
    _monthListModel->loadModel(now);
    _selectorReference = _monthListModel->reference().date();
}


MonthListModel *ClockingInViewModel::monthListModel() const
{
    return _monthListModel;
}

int ClockingInViewModel::monthSelectorValue() const
{
    return _monthSelectorValue;
}

void ClockingInViewModel::setMonthSelectorValue(int v)
{
    if (v != _monthSelectorValue) {
        _monthSelectorValue = v;
        QDate newReference = _selectorReference.addMonths(v);
        _monthListModel->loadModel(QDateTime(newReference, QTime(0, 0, 0, 0)));
        Q_EMIT(isCurrentMonthChanged());
    }
}

QString ClockingInViewModel::monthValueToText(int value) const
{
    QString text = "";
    QDate newReference = _selectorReference.addMonths(value);
    text = newReference.toString("MMMM, yyyy");
    return text;
}

bool ClockingInViewModel::isCurrentMonth() const
{
    QDate ref = _selectorReference.addMonths(_monthSelectorValue);
    QDate now = Reloj::currentDate();
    return (ref.month() == now.month() && ref.year() == now.year());
}

///////////////////////
///                 ///
/// BUSINESS-LOGIC  ///
///                 ///
///////////////////////

void ClockingInViewModel::slotNotifications(TimeStore::TimeNotifications notification, qint64 entryId)
{
    Q_UNUSED(entryId);
    switch (notification) {
        case TimeStore::TIMENOTIF_NEWENTRY:
        case TimeStore::TIMENOTIF_UPDATEDATA:{
            // cualquier cambio en las entradas de tiempo requiere volver a calcular todo el fichaje del mes
            qDebug() << "ClockingInViewModel::slotNotifications: nueva entrada de tiempo...";
            slotRecalculateClockingInData();
            break;
        }
        default:
            break;
    }
}

void ClockingInViewModel::slotRecalculateClockingInData()
{
    qDebug() << "ClockingInViewModel::slotRecalculateClockingInData: recalculando fichaje";
    QDate newReference = _selectorReference.addMonths(_monthSelectorValue);
    _monthListModel->loadModel(QDateTime(newReference, QTime(0, 0, 0, 0)));
}

