/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 10 nov 2023
**
****************************************************************************/

#ifndef CLOCKINGIN_INTERVALMODEL_H_
#define CLOCKINGIN_INTERVALMODEL_H_

#include <qabstractitemmodel.h>

class WorkInterval;

class IntervalModel: public QAbstractListModel {
    Q_OBJECT

public:
    IntervalModel(QObject *parent);
    virtual ~IntervalModel();

    int rowCount(const QModelIndex& = QModelIndex()) const override;
    QVariant data(const QModelIndex &, int = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    bool canFetchMore(const QModelIndex &) const override;
    void fetchMore(const QModelIndex &) override;

    void loadModel(const QList<WorkInterval*> &intervals);
    void clearModel();

private:
    QList<WorkInterval*> _list;

    enum RoleEnum {
        INTERVALROLE_START = Qt::UserRole + 1,
        INTERVALROLE_END,
        INTERVALROLE_ISAUTOMATICSTART,
        INTERVALROLE_ISAUTOMATICEND,
        INTERVALROLE_DURATION,
        INTERVALROLE_ISOPEN
    };
};
Q_DECLARE_METATYPE(IntervalModel*);
#endif /* CLOCKINGIN_INTERVALMODEL_H_ */
