/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 10 nov 2023
**
****************************************************************************/

#ifndef CLOCKINGIN_MONTHLISTMODEL_H_
#define CLOCKINGIN_MONTHLISTMODEL_H_

#include <qabstractitemmodel.h>
#include <QDateTime>

class TTSettings;
class TimeStore;
class DayModel;
class TimeEntry;
class WorkInterval;
class IntervalModel;

class MonthListModel: public QAbstractListModel {
    Q_OBJECT

public:
    MonthListModel(QObject *parent, TimeStore* timeStore, TTSettings* settings);
    virtual ~MonthListModel();

    void initialize();

    int rowCount(const QModelIndex& = QModelIndex()) const override;
    QVariant data(const QModelIndex &, int = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    bool canFetchMore(const QModelIndex &) const override;
    void fetchMore(const QModelIndex &) override;

    void loadModel(const QDateTime &reference);
    QDateTime reference() const;

private:

    QList<TimeEntry*> addAutomaticLimits(QList<TimeEntry*> entryList) const;
    QList<WorkInterval*> createWorkIntervals(QList<TimeEntry*> entries, const QDateTime &beginRange, const QDateTime &endRange);
    void parseWorkIntervals(QList<WorkInterval*> l);
    void addTimeToDayModel(const QDateTime &beginRange, const QDateTime &endRange);
    void calculateFixedData();

    TimeStore *_timeStore;
    TTSettings *_settings;
    QDateTime _reference; // primer día del mes representado
    QMap<int, DayModel*> _dayModels; // día (1 -- 31) -> modelo
    QMap<int, IntervalModel*> _intervalModels; // día (1 -- 31) -> modelo

    enum RoleEnum {
        CLOCKROLE_DATE = Qt::UserRole + 1,
        CLOCKROLE_FREEDAY,
        CLOCKROLE_WORKDAYNOTWORKED,
        CLOCKROLE_WORKEXPECTED,
        CLOCKROLE_WORKDONE,
        CLOCKROLE_DIFFDONE,
        CLOCKROLE_DIFFDONESIGN,
        CLOCKROLE_DIFFACCUMULATED,
        CLOCKROLE_DIFFACCUMULATEDSIGN,
        CLOCKROLE_INTERVALMODEL,
        CLOCKROLE_NUMINTERVALS
    };
};
Q_DECLARE_METATYPE(MonthListModel*);
#endif /* CLOCKINGIN_MONTHLISTMODEL_H_ */
