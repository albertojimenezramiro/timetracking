/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 10 nov 2023
**
****************************************************************************/

#include "IntervalModel.h"
#include <QDebug>
#include <QList>
#include "WorkInterval.h"
#include "Funciones.h"

IntervalModel::IntervalModel(QObject *parent) :
    QAbstractListModel(parent)
{
}

IntervalModel::~IntervalModel()
{
}

int IntervalModel::rowCount(const QModelIndex &) const
{
    return _list.size();
}

QVariant IntervalModel::data(const QModelIndex &modelIndex, int role) const
{
    int nrow = modelIndex.row();
    WorkInterval *interval = _list.value(nrow);
    if (interval) {
        if (role == INTERVALROLE_START) {
            return QVariant::fromValue(interval->start().toString("HH:mm"));
        } else if (role == INTERVALROLE_ISAUTOMATICSTART) {
            return QVariant::fromValue(interval->isAutomaticStart());
        } else if (role == INTERVALROLE_END) {
            return QVariant::fromValue(interval->end().toString("HH:mm"));
        } else if (role == INTERVALROLE_ISAUTOMATICEND) {
            return QVariant::fromValue(interval->isAutomaticEnd());
        } else if (role == INTERVALROLE_DURATION) {
            qint64 msecs = interval->start().msecsTo(interval->end());
            return QVariant::fromValue(toSexagesimal(msecs, false));
        } else if (role == INTERVALROLE_ISOPEN) {
            return QVariant::fromValue(interval->isOpen());
        }
    }
    return QVariant();
}

QHash<int, QByteArray> IntervalModel::roleNames() const
{
    static QHash<int, QByteArray> roles;
    if (roles.isEmpty()) {
        roles[INTERVALROLE_START] = "start";
        roles[INTERVALROLE_ISAUTOMATICSTART] = "isAutomaticStart";
        roles[INTERVALROLE_END] = "end";
        roles[INTERVALROLE_ISAUTOMATICEND] = "isAutomaticEnd";
        roles[INTERVALROLE_DURATION] = "duration";
        roles[INTERVALROLE_ISOPEN] = "isOpen";
    }
    return roles;
}

bool IntervalModel::canFetchMore(const QModelIndex &) const
{
    return false;
}

void IntervalModel::fetchMore(const QModelIndex &)
{
}


//=======================================================================
//=======================================================================
//=======================================================================


void IntervalModel::loadModel(const QList<WorkInterval*> &intervals)
{
    qDebug() << "IntervalModel::loadModel";
    beginResetModel();
    qDeleteAll(_list);
    _list = intervals;
    endResetModel();
}

void IntervalModel::clearModel()
{
    qDebug() << "IntervalModel::clearModel";
    beginResetModel();
    qDeleteAll(_list);
    _list.clear();
    endResetModel();
}


