/****************************************************************************
**
** Copyright 2023-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 10 nov 2023
**
****************************************************************************/

#include "DayModel.h"

DayModel::DayModel(const QDate &date) :
_dayWorkDone(0),
_dayWorkExpected(0),
_accumulatedDiffDone(0),
_date(date)
{
}

DayModel::~DayModel()
{
}

qint64 DayModel::dayWorkDone() const
{
    return _dayWorkDone;
}
void DayModel::setDayWorkDone(qint64 v)
{
    _dayWorkDone = v;
}
qint64 DayModel::dayWorkExpected()
{
    return _dayWorkExpected;
}
void DayModel::setDayWorkExpected(qint64 v)
{
    _dayWorkExpected = v;
}
qint64 DayModel::accumulatedDiffDone()
{
    return _accumulatedDiffDone;
}
void DayModel::setAccumulatedDiffDone(qint64 v)
{
    _accumulatedDiffDone = v;
}
QDate DayModel::date() const
{
    return _date;
}
