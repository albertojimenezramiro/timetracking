/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 7 oct. 2018
**
****************************************************************************/

#ifndef APPLICATION_H_
#define APPLICATION_H_

#include <QString>
#include <QObject>
#include <QSqlDatabase>

class QQmlApplicationEngine;
class Contexto;
class DatabaseMaintenance;
class Features;

class Application : public QObject {

public:
    Application(const QString &userDataDir);
    virtual ~Application();

    void initializeApp();
    void createApp();
    Q_INVOKABLE void slotSplashLoaded();
    void checkUserData();

private Q_SLOTS:
    void slotDatabaseInitialized();

private:
    void initializeQmlEnvironment();;
    void checkUserBackup();
    void buildBasicObjects();



    QQmlApplicationEngine* _engine;
    Contexto *_contexto;
    DatabaseMaintenance *_databaseMaintenance;
    QString _userDataDirectory;
    Features *_features;

};

#endif /* APPLICATION_H_ */
