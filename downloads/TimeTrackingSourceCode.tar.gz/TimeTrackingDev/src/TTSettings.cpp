/****************************************************************************
**
** Copyright 2018-2024 Alberto Jiménez.
** Contact: https://albertojimenezramiro.github.io/timetracking/
**
** This file is part of TimeTracking.
**
** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.
**
** Created on: 17 nov 2018
**
****************************************************************************/

#include "TTSettings.h"
#include <QFile>
#include <QSettings>
#include <QDebug>
#include <QTime>
#include <QDir>
#include "Reloj.h"

QString TTSettings::_userDataDirectory = "";

const QString TTSettings::_oldPath = "data/settings.ini";
const QString TTSettings::_oldBackupPath = "data/settings%1.ini";

const QString TTSettings::_firstDayKey = "firstDay";
const QString TTSettings::_lastDayKey = "lastDay";
const QString TTSettings::_comienzoJornadaKey = "comienzoJornada";
const QString TTSettings::_finalJornadaKey = "finalJornada";
const QString TTSettings::_agruparReportesKey = "agruparReportes";
const QString TTSettings::_decimalesKey = "decimales";
const QString TTSettings::_descripcionesPathKey = "descripciones";
const QString TTSettings::_usuarioJiraKey = "usuarioJira";
const QString TTSettings::_tokenJiraKey = "tokenJira";
const QString TTSettings::_diasCierreTareasKey = "diasCierreTareas";
const QString TTSettings::_horasTrabajoKey = "horasTrabajo";
const QString TTSettings::_archivedWorkOrderThresholdKey = "archivedWorkOrderThreshold";
const QString TTSettings::_archivedProjectThresholdKey = "archivedProjectThreshold";
const QString TTSettings::_accumulatedProjectReportsThresholdKey = "accumulatedProjectReportsThreshold";
const QString TTSettings::_reportUnitKey = "reportUnit";
const QString TTSettings::_urlJiraKey = "urlJira";

QString TTSettings::filePath()
{
    QString filename = QDir::toNativeSeparators(_userDataDirectory + _oldPath);
    return filename;
}
QString TTSettings::backupPath()
{
    QString filename = QDir::toNativeSeparators(_userDataDirectory + _oldBackupPath);
    return filename;
}

TTSettings::TTSettings() :
    QObject(0)
{
    qDebug() << "TTSettings::TTSettings: user data dir " << _userDataDirectory;
    QString filename = filePath();
    qDebug() << "TTSettings::TTSettings: cargando settings desde " << filename;
    _settings = new QSettings(filename, QSettings::IniFormat);
    setDefaultSettings();
}

TTSettings::~TTSettings() {
    delete _settings;
}

void TTSettings::setDefaultSetting(const QString &key, const QVariant &defaultValue)
{
    if (!_settings->contains(key)) {
        _settings->setValue(key, defaultValue);
    }
}

void TTSettings::setDefaultSettings()
{
    setDefaultSetting(_firstDayKey, 1);
    setDefaultSetting(_lastDayKey, 5);
    setDefaultSetting(_comienzoJornadaKey, QTime(8, 0, 0, 0));
    setDefaultSetting(_finalJornadaKey, QTime(21, 0, 0, 0));
    setDefaultSetting(_agruparReportesKey, AGRUPAR_MIXTO);
    setDefaultSetting(_decimalesKey, 1);
    setDefaultSetting(_descripcionesPathKey, "");
    setDefaultSetting(_usuarioJiraKey, "");
    setDefaultSetting(_tokenJiraKey, "");
    setDefaultSetting(_diasCierreTareasKey, 365);
    QVariantList horasTr;
    for (int i = 0; i <= 6; i++) {
        horasTr << (i == 4 ? QVariant::fromValue(70) : QVariant::fromValue(85));
    }
    setDefaultSetting(_horasTrabajoKey, horasTr);
    setDefaultSetting(_archivedWorkOrderThresholdKey, 365);
    setDefaultSetting(_archivedProjectThresholdKey, 365);
    setDefaultSetting(_accumulatedProjectReportsThresholdKey, 365);
    setDefaultSetting(_reportUnitKey, REPORTUNIT_DECIMAL);
}

int TTSettings::firstDayOfWeek() const
{
    return _settings->value(_firstDayKey).toInt();
}

int TTSettings::lastDayOfWeek() const
{
    return _settings->value(_lastDayKey).toInt();
}

void TTSettings::setFirstDayOfWeek(int f)
{
    _settings->setValue(_firstDayKey, f);
    Q_EMIT(workingWeekRangeChanged());
}

void TTSettings::setLastDayOfWeek(int l)
{
    _settings->setValue(_lastDayKey, l);
    Q_EMIT(workingWeekRangeChanged());
}

QTime TTSettings::comienzoJornada() const
{
    return _settings->value(_comienzoJornadaKey).toTime();
}

QDateTime TTSettings::comienzoJornadaDate() const
{
    QDateTime d = Reloj::currentDateTime();
    d.setTime(comienzoJornada());
    return d;
}

void TTSettings::setComienzoJornada(QDateTime comienzo)
{
    _settings->setValue(_comienzoJornadaKey, comienzo.time());
    Q_EMIT(limitesJornadaChanged());
}

QTime TTSettings::finalJornada() const
{
    return _settings->value(_finalJornadaKey).toTime();
}

QDateTime TTSettings::finalJornadaDate() const
{
    QDateTime d = Reloj::currentDateTime();
    d.setTime(finalJornada());
    return d;
}

void TTSettings::setFinalJornada(QDateTime final)
{
    _settings->setValue(_finalJornadaKey, final.time());
    Q_EMIT(limitesJornadaChanged());
}

TTSettings::AgrupacionReportes TTSettings::agrupacionReportes() const
{
    return (AgrupacionReportes)_settings->value(_agruparReportesKey).toInt();
}

void TTSettings::setAgrupacionReportes(AgrupacionReportes group)
{
    _settings->setValue(_agruparReportesKey, group);
    Q_EMIT(agrupacionReportesChanged());
}

int TTSettings::decimales() const
{
    return _settings->value(_decimalesKey).toInt();
}

void TTSettings::setDecimales(int decimales)
{
    _settings->setValue(_decimalesKey, decimales);
    Q_EMIT(decimalesChanged());
}

QString TTSettings::descripcionesPath() const
{
    return _settings->value(_descripcionesPathKey).toString();
}

void TTSettings::setDescripcionesPath(QString path)
{
    _settings->setValue(_descripcionesPathKey, path);
    Q_EMIT(descripcionesPathChanged());
}

QString TTSettings::usuarioJira() const
{
    return _settings->value(_usuarioJiraKey).toString();
}

void TTSettings::setUsuarioJira(QString usuario)
{
    _settings->setValue(_usuarioJiraKey, usuario);
    Q_EMIT(usuarioJiraChanged());
}

QString TTSettings::tokenJira() const
{
    return _settings->value(_tokenJiraKey).toString();
}

void TTSettings::setTokenJira(QString token)
{
    _settings->setValue(_tokenJiraKey, token);
    Q_EMIT(tokenJiraChanged());
}

int TTSettings::diasCierreTareas() const
{
    return _settings->value(_diasCierreTareasKey).toInt();
}

void TTSettings::setDiasCierreTareas(const int dias)
{
    _settings->setValue(_diasCierreTareasKey, dias);
    Q_EMIT(diasCierreTareasChanged());
}

QVariantList TTSettings::horasTrabajo() const
{
    qDebug() << "horas " << _settings->value(_horasTrabajoKey).toList();
    return _settings->value(_horasTrabajoKey).toList();
}

void TTSettings::setHorasTrabajo(QVariantList horas)
{
    qDebug() << "setHoras "<<horas;
    _settings->setValue(_horasTrabajoKey, horas);
    Q_EMIT(horasTrabajoChanged());
}

int TTSettings::archivedWorkOrderThreshold() const
{
    return _settings->value(_archivedWorkOrderThresholdKey).toInt();
}

void TTSettings::setArchivedWorkOrderThreshold(int days)
{
    _settings->setValue(_archivedWorkOrderThresholdKey, days);
    Q_EMIT(archivedWorkOrderThresholdChanged());
}

int TTSettings::archivedProjectThreshold() const
{
    return _settings->value(_archivedProjectThresholdKey).toInt();
}

void TTSettings::setArchivedProjectThreshold(int days)
{
    _settings->setValue(_archivedProjectThresholdKey, days);
    Q_EMIT(archivedProjectThresholdChanged());
}

int TTSettings::accumulatedProjectReportsThreshold() const {
    return _settings->value(_accumulatedProjectReportsThresholdKey).toInt();
}

void TTSettings::setAccumulatedProjectReportsThreshold(int days)
{
    _settings->setValue(_accumulatedProjectReportsThresholdKey, days);
    Q_EMIT(accumulatedProjectReportsThresholdChanged());
}

TTSettings::ReportUnit TTSettings::reportUnit() const
{
    return (ReportUnit) _settings->value(_reportUnitKey).toInt();
}

void TTSettings::setReportUnit(ReportUnit newUnit)
{
    _settings->setValue(_reportUnitKey, newUnit);
    Q_EMIT(reportUnitChanged());
}

QString TTSettings::urlJira() const
{
    return _settings->value(_urlJiraKey).toString();
}

void TTSettings::setUrlJira(const QString &url)
{
    _settings->setValue(_urlJiraKey, url);
    Q_EMIT(urlJiraChanged());
}

