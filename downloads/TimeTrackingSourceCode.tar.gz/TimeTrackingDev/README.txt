DESCRIPTION

TimeTracking is a simple desktop graphical tool for Windows and Linux that allows you to register
and track your workday time. This is very useful when you have to deal with timesheets or analyze
how your workday time is expended.

With the report page, you can see a table with an aggregated view of how your time is expended in
different tasks. This is useful for finding time-consuming tasks and optimize that work. If you need
to bill your time, you will have accurate data for it.

If you group your tasks into projects, you can also see and compare the time expent in different
projects and analyze their profitability. This can be very helpful when dealing with new project
prospects and budgeting, as you can see how much time you expent in similar tasks or projects.

TimeTracking also presents you basic info about the clocking-in, based on the time registered for
different tasks. So, you can see how much time you worked each day of the month as well as the
working intervals during the day. All this info is presented in a table view.

As TimeTracking is a desktop application, your data will be safe into your own computer. No cloud 
based solutions are used here.


HISTORY

I had some obligations regarding timesheets and time reporting in the company I work for. Provided
that, sometimes, it was difficult to remember the time expent accurately, I decided to create this
tool.

The first version was very small, with a simple task creation system and time tracking. As time
passed, I implemented some improvements and new features like preferences or the clocking-in data.

Now, TimeTracking is basic for me each working day. I register every moment I start to work for
each task, or when I stop working. That way, I can report all my work week time every Friday with
accuracy and without having to remember anything.


AUTHOR

Alberto Jiménez - software enginer (https://es.linkedin.com/in/albertojimenezramiro)


LICENSE

I distribute TimeTracking as GPLv3 or later software:

** TimeTracking is free software: you can redistribute it and/or modify it
** under the terms of the GNU General Public License as published by the
** Free Software Foundation, either version 3 of the License, or
** (at your option) any later version.
**
** TimeTracking is distributed in the hope that it will be useful, but
** WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
** or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
** for more details.
**
** You should have received a copy of the GNU General Public License along
** with TimeTracking, in the file LICENSE included within in. If not,
** please see <https://www.gnu.org/licenses/>.

TimeTracking is built upon Qt Community Edition framework and libraries, that are licensed under 
the terms of LGPLv3 version. You should have received a copy of this license in the file 
"Qt license LGPLv3.txt".


COMPILING

TimeTracking is distributed already compiled and ready to be used, both for Windows and Linux
systems. But, as a GPLv3 project, the source code is also available, so you can modify and create your
own version, provided you comply with the Copyright and license terms.

I'm aware that TimeTracking can be compiled for MAC systems (some people did it). But, I've
never tested it for myself nor used it in a daily basis. So, I can't give any support for this.

You can see more details regarding how you can compile the project in the COMPILING.txt file.


CREDITS

Thanks to all of my company's teammates that helped me using the program, reporting issues and
suggesting feature changes or new features.


CONTACT / SUPPORT / FEEDBACK / DOCUMENTATION

You will find more info, downloads, documentation and contact form in the project web:

https://albertojimenezramiro.github.io/timetracking/index.html

